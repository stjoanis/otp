set role tluser;

-- since 1.9.20

ALTER TABLE tlbuilds ADD COLUMN commit_id VARCHAR(64) NULL;
ALTER TABLE tlbuilds ADD COLUMN tag VARCHAR(64) NULL;
ALTER TABLE tlbuilds ADD COLUMN branch VARCHAR(64) NULL;
ALTER TABLE tlbuilds ADD COLUMN release_candidate VARCHAR(100) NULL;
