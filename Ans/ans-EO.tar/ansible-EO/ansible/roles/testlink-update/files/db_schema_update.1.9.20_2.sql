set role tluser;

INSERT INTO tlrights (id,description) VALUES (56,'delete_frozen_tcversion');

ALTER TABLE tlusers ALTER COLUMN password TYPE VARCHAR(255);

ALTER TABLE tltestplan_platforms ADD COLUMN active INT2 NOT NULL DEFAULT '1';
ALTER TABLE tlplatforms ADD COLUMN enable_on_design INT2 NOT NULL DEFAULT '0';
ALTER TABLE tlplatforms ADD COLUMN enable_on_execution INT2 NOT NULL DEFAULT '1';

CREATE TABLE tlbaseline_l1l2_context (
  "id" BIGSERIAL NOT NULL , 
  "testplan_id" BIGINT NOT NULL DEFAULT '0' REFERENCES  tltestplans (id),
  "platform_id" BIGINT NOT NULL DEFAULT '0' REFERENCES  tlplatforms (id) ON DELETE CASCADE,
  "begin_exec_ts" timestamp NOT NULL,
  "end_exec_ts" timestamp NOT NULL,
  "creation_ts" timestamp NOT NULL DEFAULT now(),
  PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX tludx1 ON tlbaseline_l1l2_context ("testplan_id","platform_id","creation_ts");


CREATE TABLE tlbaseline_l1l2_details (
  "id" BIGSERIAL NOT NULL , 
  "context_id" BIGINT NOT NULL DEFAULT '0' REFERENCES  tlbaseline_l1l2_context (id),
  "top_tsuite_id" BIGINT NOT NULL DEFAULT '0'  REFERENCES  tltestsuites (id),
  "child_tsuite_id" BIGINT NOT NULL DEFAULT '0'  REFERENCES  tltestsuites (id),
  "status" char(1) DEFAULT NULL,
  "qty" INT NOT NULL DEFAULT '0',
  "total_tc" INT NOT NULL DEFAULT '0',
  PRIMARY KEY ("id")
) ;
CREATE UNIQUE INDEX tludx1 
ON tlbaseline_l1l2_details ("context_id","top_tsuite_id","child_tsuite_id","status");

CREATE OR REPLACE VIEW tltsuites_tree_depth_2 AS 
(
  SELECT TPRJ.prefix,
  NHTPRJ.name AS testproject_name,    
  NHTS_L1.name AS level1_name,
  NHTS_L2.name AS level2_name,
  NHTPRJ.id AS testproject_id, 
  NHTS_L1.id AS level1_id, 
  NHTS_L2.id AS level2_id 
  FROM tltestprojects TPRJ 
  JOIN tlnodes_hierarchy NHTPRJ 
  ON TPRJ.id = NHTPRJ.id
  LEFT OUTER JOIN tlnodes_hierarchy NHTS_L1 
  ON NHTS_L1.parent_id = NHTPRJ.id
  LEFT OUTER JOIN tlnodes_hierarchy NHTS_L2
  ON NHTS_L2.parent_id = NHTS_L1.id 
  WHERE NHTPRJ.node_type_id = 1 
  AND NHTS_L1.node_type_id = 2
  AND NHTS_L2.node_type_id = 2
);

CREATE OR REPLACE VIEW tlexec_by_date_time 
AS (
SELECT NHTPL.name AS testplan_name, 
TO_CHAR(E.execution_ts, 'YYYY-MM-DD') AS yyyy_mm_dd,
TO_CHAR(E.execution_ts, 'YYYY-MM') AS yyyy_mm,
TO_CHAR(E.execution_ts, 'HH24') AS hh,
TO_CHAR(E.execution_ts, 'HH24') AS hour,
E.* FROM tlexecutions E
JOIN tltestplans TPL on TPL.id=E.testplan_id
JOIN tlnodes_hierarchy NHTPL on NHTPL.id = TPL.id);

-- END
