#!/bin/bash

# ESJ 02/2020

#set -x

FILE=/var/tmp/check_sbocs_database.txt
# Nagios Exit Codes
OK=0
WARNING=1
CRITICAL=2
UNKNOWN=3

JOUR=$(date +"%w")
HEURE=$(date +"%H")

send_mail()
{
  subject="Alerte SBOCS BU-DSA"
  from="sbocs@c-s.fr"
#  recipients="emmanuel.saint-joanis@c-s.fr sbocs@c-s.fr philippe.desanois@c-s.fr christelle.gesset@c-s.fr"
recipients="sbocs@c-s.fr"
#  message="Base H2 corrompue\nVoir le fichier /var/tmp/check_sbocs_database.txt"
  mail="subject:$subject\nfrom:$from\nto:$recipients\n$message"
  echo -e $mail | /usr/sbin/sendmail -t -f sbocs@c-s.fr
}

if [ $JOUR -ge 1 -a $JOUR -le 5 ]
then
  if [ $HEURE -ge 7 -a $HEURE -le 19 ]
  then
    # Verification de l'age du fichier (superieur a 70 minutes)
    FRESH=$(( $(date +%s) - $(stat -L --format %Y $FILE) > (70*60) ))
    if [ "$FRESH" -eq 1 ]
    then
      echo CRITICAL: Le fichier est plus vieux que 60 minutes
      message="Le fichier de test H2 trop ancien\nVoir le fichier /var/tmp/check_sbocs_database.txt sur lpr-sbocs-admin-v.bu-dsa.si.c-s.fr"
      [ -f /var/tmp/check_sbocs_database.mail ] || ( echo sending mail ; send_mail ;touch /var/tmp/check_sbocs_database.mail )
      exit $CRITICAL
    fi
  fi
fi

# Teste si fichier plus grand que zero
if [ -s $FILE ]
then
  echo CRITICAL: La base H2 est corrompue
  RR=$(paste -s -d+ /var/tmp/check_sbocs_database.txt | sed "s/+/\\\n/g")
  message="Base H2 corrompue\nVoir le fichier /var/tmp/check_sbocs_database.txt sur lpr-sbocs-admin-v.bu-dsa.si.c-s.fr\n"$RR
  [ -f /var/tmp/check_sbocs_database.mail ] || ( echo sending mail ; send_mail ;touch /var/tmp/check_sbocs_database.mail )
  exit $CRITICAL
else
  echo OK: La base H2 est saine
  /bin/rm -f /var/tmp/check_sbocs_database.mail 2>/dev/null
  exit $OK
fi
