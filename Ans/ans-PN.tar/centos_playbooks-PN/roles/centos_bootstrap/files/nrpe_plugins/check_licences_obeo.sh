#!/bin/bash

# Destination /usr/lib64/nagios/plugins/check_licences-obeo.sh
# ESJ 2020-12-03

# Exemple de fichier JSON
#{
#  "version": "2.6.0.202007271228",
#  "status":{
#     "total": 9,
#     "free":4,
#     "used":
#            [
#         {"user":"52-54-00-01-E5-0C/C8-F7-50-6D-A4-8B","lastSeen":"01/12/2020 16:30:14"},
#         {"user":"DC-8B-28-AA-63-8D/B0-0C-D1-C5-BB-0F/02-50-41-00-00-01/DE-8B-28-AA-63-8D/DC-8B-28-AA-63-8E/42-15-C6-2C-41-FE","lastSeen":"01/12/2020 16:31:33"},
#         {"user":"5E-5F-67-B0-4F-A0/02-50-41-00-00-01/5C-5F-67-B0-4F-A4/5C-5F-67-B0-4F-A0/5C-5F-67-B0-4F-A1/10-62-E5-52-1F-B2/72-15-D2-33-E1-21","lastSeen":"01/12/2020 16:32:12"},
#         {"user":"5C-5F-67-BE-55-33/10-62-E5-51-B9-F4/5E-5F-67-BE-55-32/5C-5F-67-BE-55-32/02-50-41-00-00-01/32-15-96-F4-BD-18","lastSeen":"01/12/2020 16:24:53"},
#         {"user":"A0-2B-B8-30-AD-65/3C-A9-F4-98-89-84/02-50-41-00-00-01","lastSeen":"01/12/2020 16:31:06"}
#            ],
#     "errors":[]
#   }
#}

#set -x

send_mail()
{
  subject="Alerte SBOCS SCCOA Licences"
  from="sbocs@c-s.fr"
#  recipients="emmanuel.saint-joanis@c-s.fr sbocs@c-s.fr philippe.desanois@c-s.fr christelle.gesset@c-s.fr"
recipients="sbocs@c-s.fr"
#  message="Base H2 corrompue\nVoir le fichier /var/tmp/check_sbocs_database.txt"
  mail="subject:$subject\nfrom:$from\nto:$recipients\n$message"
  echo -e $mail | /usr/sbin/sendmail -t -f sbocs@c-s.fr
}

FILE=/var/tmp/json.txt

# Nagios Exit Codes
OK=0
WARNING=1
CRITICAL=2
UNKNOWN=3

# General check
# curl -s http://sbocs.si.c-s.fr:9998/usage/json

curl -s http://sbocs.si.c-s.fr:9998/status/json > /tmp/json
RES=$?

if [ ! $RES = 0 ]
then
  echo CRITICAL: pas de test possible du nombre de licences
  exit $CRITICAL
fi

RES=$(grep -c BadPaddingException /tmp/json)
if [ $RES = 1 ]
then
  message="\nCRITICAL: les fichiers de licences serveurs sont corompus  --  Verifier les fichiers dans /opt/obeo/etc/v11_3_licences/sbocs.si.c-s.fr"
  [ -f /var/tmp/check_licence.mail ] || ( send_mail ;touch /var/tmp/check_licence.mail )
  echo CRITICAL: les fichiers de licences serveurs sont corompus
  exit $CRITICAL
fi

TOTAL=$(awk '/total/ {print $NF}' /tmp/json | \grep -o "[[:digit:]]*")
FREE=$(awk '/free/ {print $NF}' /tmp/json | \grep -o "[[:digit:]]*")

if [ $FREE = 0 ]
then
  message="\nCRITICAL: Plus de licences Obeo sur un total de $TOTAL  --  Voir les fichiers dans /tmp/Json"
  [ -f /var/tmp/check_licence.mail ] || ( echo sending mail ; send_mail ;touch /var/tmp/check_licence.mail )

  echo CRITICAL: plus de licences Obeo sur un total de $TOTAL
  exit $CRITICAL
else
  if [ $FREE = 1 ]
  then
    /bin/rm -f /var/tmp/check_licence.mail
    echo WARNING: une seule licence Obeo disponible sur un total de $TOTAL
    exit $WARNING
  fi
  /bin/rm -f /var/tmp/check_licence.mail
  echo $FREE licences Obeo disponibles sur un total de $TOTAL
  exit $OK
fi
