#!/bin/bash
OK=0
CRITICAL=2

/bin/rm -f /tmp/testfile
# Compte invite
wget -qO /tmp/testfile "http://srv-etna.bu-dsa.si.c-s.fr/advitium/MainMyAdvitium.asp?MenuItem=Default&SystemId={A387FA11-F3E2-42D7-98A4-A2B5EE3256B8}&ResourceId={3716A4AA-DF8E-43CC-80C2-84550B8C25C4}&SessionId={695FD7CC-35E1-4286-8FA8-78FAC2C13C4F}&CallerName=&ConnectorType=&ConnectorAction=&TabId="

# Compte supervision
#wget -qO /tmp/testfile "http://srv-etna.si.c-s.fr/advitium/MainMyAdvitium.asp?MenuItem=Default&SystemId={A387FA11-F3E2-42D7-98A4-A2B5EE3256B8}&ResourceId={10043D6E-C1C5-4CDE-A100-2C817F28EB1B}&SessionId={7F99DB25-8E6A-472B-B189-383B7DCF4968}&CallerName=&ConnectorType=&ConnectorAction=&TabId="

#grep -m1 -c TESTBIDON/01A_F0404 /tmp/testfile >/dev/null 2>&1
grep -m1 -c "Votre session s'est terminée" /tmp/testfile >/dev/null 2>&1

RES=$?

if [ $RES == 0 ]
then
  echo OK: site Advitium disponible
  exit $OK
else
  echo CRITICAL: site Advitium non disponible
  exit $CRITICAL
fi