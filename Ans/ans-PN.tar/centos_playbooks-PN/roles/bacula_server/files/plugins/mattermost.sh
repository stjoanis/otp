#!/bin/bash

URL="https://chat.bu-dsa.si.c-s.fr/hooks/j8gz9bbisiym7pm7unwz5n3dko"

CLIENT="$1"  # %c
JOB="$2"     # %j
RESULT="$3"  # %e
LEVEL="$4"   # %l
ICON=""

OK=":white_check_mark:"
ERR=":sos:"


if [[ $RESULT == *"OK"* ]]; then
	EMOJI=$OK
else
    EMOJI=$ERR
fi

msg="{\"username\": \"$CLIENT\",\"icon_url\": \"$ICON\",\"text\": \"$EMOJI $JOB\n$LEVEL completed with status : $RESULT\"}"

/usr/bin/curl -k -X POST -H 'Content-type: application/json' --data "$msg" "$URL"


