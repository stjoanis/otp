Ansible de Bootstrap pour les serveurs CIaaS
============================================

## Résumé

Ce module Ansible permet de gérer les serveur CIaaS. Il contient notamment le rôle `centos_bootstrap` qui permet de réaliser la configuration initiale d'un serveur CIaaS. Il contient également le rôle `nagios_server` qui permet de déployer un serveur de supervision Nagios. Le module nrpe pour les clients Nagios est quant à lui déployé via la tâche `nagios` du rôle bootstrap.

## Prérequis

Ce module est conçu pour être exécuté depuis AWX, sur des CentOS 7 ou 8 minimal fraichement installés.

L'utilisation d'AWX requiert un accès SSH sur les serveurs concernés. De ce fait, les machines doivent être accessible par le réseau et leur serveur SSH doit être démarré.

L'interface réseau de l'hôte doit être préalablement configurée afin que la machine soit accessible depuis le réseau CS et qu'elle puisse accéder aux services du réseau. Pour ce faire, il est nécessaire que la machine possède une IP sur le réseau CS/BU-DSA, que les routes réseaux soient configurées et que le DNS soit paramétré.

**Note**: Il est préférable d'effectuer la configuration de l'interface réseau depuis le menu prévu à cet effet dans l'installateur de CentOS. Pour plus d'informations, consulter [la documentation](https://docs.centos.org/en-US/centos/install-guide/NetworkSpoke-x86/)

Par ailleurs, il faux déployer, sur les serveurs concernés, la clé SSH dédiée à l'administration des serveurs CIaaS, référencée dans le Keepass de l'équipe CIaaS. Il faut copier le contenu du fichier `id_rsa.pub` de l'entrée du Keepass, dans le fichier `/home/admin/.ssh/authorized_keys` de chaque serveur concerné.

Pour se faire, utiliser la commande suivante :
```bash
# Injecter la clé sur un serveur (méthode automatique)
ssh-copy-id -i <path/to/public_key> admin@'<host-ip>'
```

*Note* : L'utilisateur `admin` doit être le propriétaire du dossier `.ssh` et du fichier `authorized_keys`

La clé SSH privée doit être installée sur AWX et sélectionnée dans le modèle associé.

Pour plus d'information sur AWX et son utilisation, se référer à la documentation officielle : https://docs.ansible.com/ansible-tower/latest/html/userguide/index.html

## Architecture

### Role `bacula_server`

Ce rôle contient trois tâches rassemblées par unité de déploiement, une unité correspondant à un fichier YAML. Chaque unité de déploiement peut être exécutée indépendamment des autres en utilisant le tag associé. Les tags sont précisés ci-dessous entre crochets.

Le rôle `bacula_server` permet de configurer un serveur de sauvegarde Bacula.

+ install.yaml [bacula-install]
	* Ouvre les ports 9101, 9102, 9103 du Parefeu
	* Ajoute le dépôt Bacula
	* Installe Bacula et Mysql
	* Sécurise la DB Mysql et crée les tables pour Bacula
	* Crée les fichiers de configuration de Bacula
	* Lance le service bacula

+ clients.yaml [bacula-client]
	* Met à jour le fichier "schedule" si besoin
	* Crée les fichiers de filesets et filesets dynamiques
	* Crée les fichiers de jobs et de jobs dynamiques

+ baculum.yaml [bacula-baculum]
	* Ajoute le dépôt Baculum
	* Installe Baculum
	* Configure Baculum
	* Configure le serveur apache pour Baculum
	* Lance le serveur apache

### Role `centos_bootstrap`

Le rôle `centos_bootstrap` contient différentes tâches rassemblées par unité de déploiement, une unité correspondant à un fichier YAML. Chaque unité de déploiement peut être exécutée indépendamment des autres en utilisant le tag associé. Les tags sont précisés ci-dessous entre crochets.

Le rôle `centos_bootstrap` permet de configurer les serveurs CIaaS avec les paramètres classiques. Il se charge notamment de déployer la configuration propres à CS tel que le NTP, le proxy et les dépôts YUM/DNF, mais aussi propre à CIaaS comme l'authentification LDAP, le client Puppet et les droits utilisateurs.

Les différentes étapes effectuées par ce rôle sont exposées ci-dessous :

+ network.yaml [network]
	* Configure le proxy (si activé)
	* Ouvre les ports dans le parefeu (Firewalld)
	* Définie le hostname du serveur

+ yum.yaml [packets]
	* Configure les dépôts Yum (miroir CS)
	* Met à jour tous les paquets [update]
	* Installe des paquets utiles

+ chrony.yaml [time]
	* Installe et configure le client NTP
	* Synchronise le serveur sur le NTP master
	* Définit le fuseau horaire sur Paris

+ sssd.yaml [authent]
	* Installe les dépendances necessaires
	* Configure SSSD
	* Configure la pile PAM

+ bacula.yaml [bacula] (Optionnel)
	* Ouvre le port 9102 dans le Parefeu
	* Installe et configure le client Bacula

+ nagios.yaml [nagios] (Optionnel)
	* Ouvre le port 5666 dans le Parefeu
	* Installe le client NRPE [yum-nrpe]
	* Configure le client nrpe

+ node_exporter.yaml [node_exporter] (Optionnel)
	* Ouvre le port 9100
	* Crée le compte système node_exporter
	* Installe et configure node_exporter

+ security.yaml [security]
	* Configure les accès SSH [ssh-access]
	* Restreint l'accès SSH du compte admin [ssh-access]
	* Ajoute le certificat CIaaS au trustore
	* Définie les administrateurs [sudoers]
	* Configure le NOPASSWD pour admin [sudoers]
	* Désactive SELinux (si activé)
	* Désactive le compte root

### Role `nagios_server`

Ce rôle contient trois tâches rassemblées par unité de déploiement, une unité correspondant à un fichier YAML. Chaque unité de déploiement peut être exécutée indépendamment des autres en utilisant le tag associé. Les tags sont précisés ci-dessous entre crochets.

Le rôle `nagios_server` permet de configurer un serveur nagios de monitoring.

+ install.yaml [nagios-install]
	* Ouvre les ports 80 et 443 du Parefeu
	* Installe apache et nagios
	* Installe les plugins nagios par défaut
	* Configure les services apache et nagios et les lance

+ hosts.yaml [nagios-hosts]
	* Met à jour les plugins si besoin
	* Crée la configuration Nagios liée aux clients nrpe
	* Crée la configuration Nagios liée aux services déployés pour les clients nrpe

+ general_conf.yaml [nagios-conf]
	* Crée la configuration du serveur Nagios (timeperiods, resource...)


## Configuration

Ce module Ansible nécessite d'être configuré avant d'être exécuté. Il faut notamment spécifier les hôtes concernés par le déploiement Ansible en complétant l'inventaire défini dans le fichier [hosts.ini](hosts.ini) présent dans le dossier `ansible` de ce dépôt. De plus, il est nécessaire d'adapter les paramètres du déploiement rassemblés dans les fichiers des dossiers `host_vars/` et `group_vars`.

AWX utilise les configurations définis dans les fichiers présents dans les dossiers `ansible-roles/files` et `ansible-roles/templates`. Les paramètres de ces fichiers correspondent à l'utilisation standard d'un serveur CIaaS de production. Pour des déploiements spécifiques, il est conseillé de vérifier et d'adapter les configurations présentes dans ce dépôt afin que la configuration appliquée par AWX correspondent à ce qui est attendu.

### Inventaire : hosts.ini

Ce module utilise l'inventaire général des serveur CIaaS, disponible dans le dossier `ansible` de ce dépot : https://git.bu-dsa.si.c-s.fr/CIaaS/infra/src/branch/master/ansible/hosts.ini. Cet inventaire doit être complété afin de refléter la réalité des serveurs gérés par l'équipe CIaaS.

Le fichier d'inventaire `hosts.ini` permet de définir les serveurs de l'infrastructure CIaaS. Ce fichier doit être adaptés avant l'exécution du playbook.

Chaque serveur est défini par une ligne dans le fichier `hosts.ini`, commençant par le nom du serveur et dans laquelle est précisé la variable `ansible_host` qui contient l'entrée DNS de la machine qu'utilisera AWX pour se connecter en SSH sur l'hôte et ainsi exécuter les tâches. Seuls les hôtes définis dans ce fichier pourront être traités par AWX. Chaque hôte défini dans le fichier `hosts.ini` doit avoir un fichier du même nom dans le dossier `host_vars/`. Ce fichier doit contenir les variables spécifique de l'hôte, voir la partie "Paramètres".

Il est aussi possible de classer les hôtes dans des groupes en fonction de leur rôle ou de leurs caractéristiques. Ces groupes permettent d'exécuter des tâches spécifiques en fonction de la nature du serveur. Les serveurs sont répartis en différents groupes en fonction de s'ils sont virtuel (VM) ou physique, de leur appartenance à un projet ou au cluster Kubernetes. Les variables communes aux hôtes d'un groupe sont rassemblées dans le fichier de même nom que le groupe du dossier `group_vars/`, voir la partie "Paramètres".

Les options communes à tous les serveurs sont rassemblées dans le fichier `group_vars/all.yaml` et permettent notamment de définir l'utilisateur sous lequel va se connecter AWX et quel compte administrateur utiliser pour les taches qui nécessitent des permissions élevées. Voir la partie "Paramètres" pour plus d'information.

AWX se connecte en SSH, via le bastion `bastion.bu-dsa.si.c-s.fr`, aux hôtes grâce à la clé SSH d'administration de l'équipe CIaaS. Cette clé est disponible dans le Keepass de l'équipe CIaaS. Pour plus d'information, se référer à la partie "Prérequis".

### Paramètres de déploiement

Les paramètres de déploiement peuvent être défini à différents niveaux, qui sont par ordre du moins prioritaire au plus prioritaires :

- Commun à tous les hôtes : `group_vars/all.yaml`
- Commun à tous les hôtes d'un groupe : `group_vars/<groupname>.yaml`
- Spécifique à un hôte : `host_vars/<hostname>.yaml`

Ainsi, les variables définies dans un fichier `host_vars` écrase les précédente définition de cette même variable. Les paramètres de déploiement doivent donc être renseignés au bon niveau en fonction de leur porté et peuvent être surchargé pour un hôte spécifique (via `host_vars/`) ou un groupe données (via `group_vars/`).

Pour plus de détails sur la précédence appliqué par Ansible, ce référer à la [documentation](https://docs.ansible.com/ansible/latest/user_guide/playbooks_variables.html#understanding-variable-precedence)

#### Paramètres globaux : `group_vars/all.yaml`

| Paramètre                  | Description                                                           | Valeur par défaut                                                                                                            |
| -------------------------- | --------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| http_proxy                 | Proxy pour les requêtes HTTP                                          | `proxy1.si.c-s.fr:3128`                                                                                                      |
| https_proxy                | Proxy pour les requêtes HTTPS                                         | `proxy1.si.c-s.fr:3128`                                                                                                      |
| no_proxy                   | Liste des hôtes et IPs que le proxy doit ignorer                      | `127.0.0.1, localhost,.si.c-s.fr`                                                                                            |
| ldap_bind_pass             | Mot de passe de bind pour le Ldap                                     | `<changeme>`                                                                                                                 |
| users                      | Liste des utilisateurs autorisés à se connecter en SSH                | `ldevigne, vquemene, dclavier, edemaudu, admin`                                                                              |
| sudoers                    | Liste des administrateurs                                             | `ldevigne, vquemene, dclavier, edemaudu, admin`                                                                              |
| ansible_ssh_user           | Nom de l'utilisateur utiliser par AWX pour se connecter aux hôtes     | `admin`                                                                                                                      |
| ansible_become_user        | Nom du compte pour l’élévation de privilèges (sudo)                   | `root`                                                                                                                       |
| ansible_connection         | Type de connexion utilisée par AWX                                    | `ssh`                                                                                                                        |
| ansible_python_interpreter | Interpreteur Python que doit utiliser AWX pour l'exécution des taches | `/bin/python`                                                                                                                |
| ansible_ssh_common_args    | Argument complémentaire pour la connexion SSH (proxy via Bastion)     | -o ProxyCommand="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -W %h:%p -q admin@bastion.bu-dsa.si.c-s.fr" |
| node_exporter              | Indique si le node_exporter doit être installé ou non                 | `false`               |
| node_exporter_password     | Le mot de passe à utiliser pour chiffrer les communications node_exporter | `XXXXXXXX`        |
| node_exporter_version      | Version à utiliser pour l'installation du node_exporter               | `1.12`                  |


Paramètres `group_vars/nagios-client.yaml` :

| Paramètre             | Description                                                       | Exemple de valeur                                             |
|-----------------------| ----------------------------------------------------------------- | --------------------------------------------------------------|
| nrpe_allowed_hosts    | Liste des hôtes autorisés à intérroger le client NRPE             | `127.0.0.1,172.25.54.11,nagios.bu-dsa.si.c-s.fr,172.25.52.23` |

Paramètres `group_vars/nagios-server.yaml`:

| Paramètre             | Description                                                       | Exemple de valeur                      |
|-----------------------| ----------------------------------------------------------------- | ---------------------------------------|
| hosts                 | Liste des clients Nagios                                          | `groups['nagios-client']`               |
| nagios_admin          | Utilisateur de la WebUI Nagios          							| `nagiosadmin`							 |
| nagios_admin_password | Mot de passe de l'utilisateur de la WebUI Nagios         			| `<changeme>`                   |



Paramètres `group_vars/nagios-client.yaml` :

| Paramètre             | Description                                                       | Exemple de valeur                                             |
|-----------------------| ----------------------------------------------------------------- | --------------------------------------------------------------|
| nrpe_allowed_hosts    | Liste des hôtes autorisés à intérroger le client NRPE             | `127.0.0.1,172.25.52.17,lpr-nagios-01v.bu-dsa.si.c-s.fr`      |


Paramètres `group_vars/nagios-server.yaml` :

| Paramètre             | Description                                                       | Exemple de valeur                      |
|-----------------------| ----------------------------------------------------------------- | ---------------------------------------|
| nagios_hosts          | Liste des clients Nagios                                          | `groups['nagios-client']`              |
| nagios_admin          | Utilisateur de la WebUI Nagios          							| `nagiosadmin`							 |
| nagios_admin_password | Mot de passe de l'utilisateur de la WebUI Nagios         			| `<changeme>`                   		 |

Paramètres `group_vars/bacula-client.yaml` :

| Paramètre             | Description                                                       | Exemple de valeur                      |
|-----------------------| ----------------------------------------------------------------- | ---------------------------------------|
| bacula_server         | IP ou DNS du serveur Bacula                                       | `lpr-backup-01v.bu-dsa.si.c-s.fr`      |
| bacula_password       | Mot de passe à utiliser pour contacter le serveur bacula		    | `<changeme>`						     |


Paramètres `group_vars/bacula-server.yaml` :

| Paramètre             | Description                                                       | Exemple de valeur                      |
|-----------------------| ----------------------------------------------------------------- | ---------------------------------------|
| bacula_hosts          | Liste des clients Bacula                                          | `groups['bacula-client']`              |
| mysql_root_password   | Mot de passe de l'utilisateur root pour la db mysql				| `<changeme>`						     |
| bacula_mysql_password | Mot de passe de l'utilisateur bacula pour la db mysql				| `<changeme>`						     |
| bacula_storage_host   | IP ou DNS du serveur de stockage Bacula						    | `srv-infra.bu-dsa.si.c-s.fr`           |
| baculum_admin_pass    | Mot de passe de l'utilisateur admin de la WebUI Baculum         	| `<changeme>`                   		 |
| baculum_admin_users   | Liste des utilisateurs autorisés à se connecter sur Baculum      	| `ldevigne, vquemene, sboulet, dclavier`|


#### Paramètres spécifique d'hôte

Les paramètres suivants sont propres à chaque hôte et doivent être défini pour chacun des serveurs dans le fichier `/host_vars/<hostname>.yaml` qui lui est associé :

| Paramètre       | Description                                                       | Exemple de valeur                      |
| --------------- | ----------------------------------------------------------------- | -------------------------------------- |
| proxy           | True pour activer le proxy, False sinon (/etc/profile.d)          | `true`                                 |
| centos          | Verison majeure de CentOS                                         | `7`                                    |
| hostname        | Nom de l'hôte considéré                                           | `<name>.bu-dsa.si.c-s.fr`              |
| secure          | True pour effectuer les tâches de durcissement et de sécurisation | `true`                                 |
| disable_selinux | True pour désactiver SELinux de manière permanente, False sinon   | `false`                                |

Afin de rendre plus simple et plus rapide la configuration du module, certains paramètres, plus ou moins fixes dans le temps, ont été implémentés en dur dans les taches du module. C'est notamment le cas de l'adresse du miroir CS, des ports ouverts pour Nagios et Bacula ou encore du serveur NTP de référence. A l'avenir, ces valeurs pourront être paramétrisées et être incluses dans les paramètres de déploiement.


Paramètres spécifiques au client Nagios :

Les services à déployer sont à définir dans les variables de l'hôte. Une description succinte des services est disponible dans `procedures/Nagios/plugins-Nagios.md`.

Paramètres spécifiques au client Bacula :

| Paramètre             | Description                                                       	| Exemple de valeur                      |
|-----------------------|-----------------------------------------------------------------------|----------------------------------------|
| bacula_backup         | True pour configurer un backup sur bacula   							| `true`                                 |
| bacula_fileset | Fileset selectionné pour la sauvegarde bacula         	            | `Common`                               |
| bacula_schedule		| Planning de sauvegarde sélectionné                	                | `weekly`								 |
| bacula_restore        | True pour configurer une tâche de restauration sur bacula   			| `true`                                 |
| bacula_runbefore      | Script à lancer avant la sauvegarde		                     		| `None`                        		 |
| bacula_runafter       | Script à lancer après la sauvegarde		                     		| `None`                                 |
| bacula_service_save   | Service dont la sauvegarde doit être déclarée dynamiquement à bacula  | `None`								 |
| bacula_specific_job   | Backup spécifique pour un client bacula							    | `None`								 |

Des exemples de ces quatre derniers paramètres sont présents dans `group_vars/bacula-client.yaml`.

## Utilisation

Une fois l'inventaire configuré et les paramètres adaptés au déploiement, le playbook doit être lancé depuis AWX en utilisant le modèle "CentOS Bootstrap".

Au lancement du modèle, il faut renseigner, dans le champ `Limite`, le ou les hôtes concernés par l’exécution du modèle.

Le playbook prend environs 10 minutes pour exécuter toutes les tâches. La plus longue tâches étant la mise à jour des paquets via YUM/DNF.

Notez que si une action échoue (fail) le reste des actions prévues pour l’hôte ne sont pas réalisées, sauf si l'échec est ignoré. Toutes les actions doivent être "OK" ou "Changed" à la fin du script afin de garantir que chaque serveur a bien été configuré.

Ce rôle respecte le principe d'idempotence. De ce fait, il est possible de l'exécuter plusieurs fois, le résultat sur les serveurs sera sensiblement le même.

### Tags

Le module réalise plusieurs groupes d'actions indépendantes à la suite. Cependant, il est possible d'exécuter directement un groupe de taches et uniquement celui-ci.

Pour permettre cela, chaque fichier de tâche possède un tag (ou "balise de saut") renseigné entre crochets dans la partie "Architecture" de ce document. Ce tag permet de restreindre l'exécution du playbook à un ensemble restreint de taches. Dans ce cas, au lancement du modèle dans AWX, il faut compléter le champ `Balise de saut` en spécifiant le ou les tags souhaités.

## Bugs connus

### Rôle `centos_bootstrap`

La synchronisation temporelle du serveur NTP et des clients NTP n'est pas immédiate. Cela peut prendre plusieurs minutes avant que la machine soit synchronisée et donc à la bonne heure.

L'initialisation du client Puppet n'est pas idempotente. De ce fait, les erreurs de cette tache sont ignorées.

## Auteurs et Contributeurs
Ce module a été rédigé par Denis CLAVIER et William RUFFINE.
