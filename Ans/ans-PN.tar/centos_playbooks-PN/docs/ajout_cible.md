# Préparation de la cible

* Rendre l'hôte concerné accessible par le réseau.
    - Configurer son interface réseau
    - Configurer le serveur DNS

* Injecter la clé SSH d'administration CIaaS (cf : Keepass) dans les clés acceptées par l'utilisateur `admin`.

```bash
ssh-copy-id -i <path/to/public_key> admin@'<ip>'
```

* Le compte `admin` doit avoir les droits 'sudo' et le mot de passe du compte `admin` doit correspondre à la valeur de la variable `ansible_become_pass`.

# Modification du playbook Ansible

## Récupération du playbook

* Se rendre sur la page `https://gerrit.bu-dsa.si.c-s.fr/admin/repos/ciaas/centos_playbooks`, cloner le dépôt via la commande indiquée dans "Clone with commit-msg hook".

## Ajout de la cible

* Ajouter la cible dans `hosts.ini` (suivre la nomenclature `<nom_court>   ansible_host=<adresse_dns>`). L'ajouter dans un groupe parmi `[virtual]`, `[physical]` ou `[sccoa]`
    - Si la cible est un client Nagios, l'ajouter au groupe `[nagios-client]`
    - Si la cible est un client Bacula, l'ajouter au groupe `[bacula-client]`

* Créer le fichier `<nom_court>.yaml` dans le dossier `host_vars`.

* S'inspirer des autres fichiers du dossier `host_vars` pour remplir les variables `centos`, `proxy`,`hostname`,  `secure`, `disable_selinux` (si nécessaire, copier-coller un autre fichier et l'adapter).

## Configuration Nagios
### Configuration des checks par défaut

Par défaut, huit checks sont déployés : (`check_conntrack`, `check_cpu`, `check_disk`, `check_ping`, `check_load`, `check_ntp_time`, `check_ram` et `check_swap`).

Si l'on souhaite désactiver un de ces checks (par exemple, `check_xxx`), il faut ajouter :

```yaml
check_xxx: false
```

dans le fichier `<nom_court>.yaml`.

### Ajout d'un check sur une cible

* Si le check n'est pas présent dans le fichier `groups_vars/nagios-client.yaml`, se référer au document `procedures/nagios/plugins_Nagios.md` du dépôt.

* Si le check est présent dans le fichier :
    - copier le nom du check (`check_xxx`)
    - le coller dans le fichier `host_vars/<nom_court>.yaml` et lui donner la valeur true. (`check_xxx: true`)

**Attention :** Dans ce deuxième cas, il ne faut surtout pas modifier le fichier `group_vars/nagios-client.yaml`.

**Remarque :** Si une commande `check_service_xxx` est définie, la variable `check_service` doit également avoir la valeur `true` dans les variables d'hôte.

La liste des checks possibles est présente en annexe de ce document.

## Configuration Bacula

Par défaut, une sauvegarde utilisant le fileset "Common" (le dossier `/etc`), et le schedule "weekly" est configurée, si la cible est dans le groupe `[bacula-client]`.

* Modifier le fichier `<nom_court>.yaml` pour ajouter une sauvegarde, ou modifier la sauvegarde par défaut.

Trois types de sauvegardes sont possibles :

 - les sauvegardes système
 - les sauvegardes dynamiques
 - les sauvegardes additionnels

Les configurations de ces trois sauvegardes se font **dans le fichier `<nom_court>.yaml`**

### Configuration d'une sauvegarde système

Il est possible de modifier les paramètres de sauvegarde par défaut via les variables suivantes :

 - `bacula_save : [true/false]` Indique si une sauvegarde système doit être configurée
 - `bacula_backup_fileset : [Common/system/...]` Le fileset à utiliser
 - `bacula_schedule : [weekly/monthly/weekly-2nd/...]` Le schedule à utiliser
 - `bacula_restore: [true/false]` : Si une tâche de restauration doit être définie

Les valeurs par défaut pour ces variables sont indiquées dans le fichier `groups_vars/bacula-client.yaml`.

Deux variables optionnelles peuvent être ajoutées dans le cas où elles sont définies :

 - `bacula_runbefore : [myscript.sh/...]` Script à exécuter sur le client avant la sauvegarde
 - `bacula_runafter : [myscript.sh/...]` Script à exécuter sur le client après la sauvegarde

**Remarque:** Les listes des filesets et schedule sont disponibles en Annexes de ce fichier

### Configuration d'une sauvegarde dynamique

Les sauvegardes dynamiques utilisent des filesets spécifiques à un service. Les filesets liés à ces sauvegardes dynamiques doivent être directement définis dans les variables de l'hôte Ansible.

Un exemple de sauvegarde dynamique est donnée dans le fichier `group_vars/bacula_client.yaml`.

### Configuration d'une sauvegarde additionnelle

Les sauvegarde additionnelle sont généralement dédies à des fichiers spécifiques (par exemple, la sauvegarde du NAS).

Un exemple de sauvegarde additionnelle est donnée dans le fichier `group_vars/bacula_client.yaml`.

# Ajout des modifications sur Gerrit

* Une fois le playbook modifié, vérifier les documents modifiés avec les commandes `git status` et `git diff`.

* Pousser les changements sur gerrit :

```bash
git add <fichier(s) modifies>
git commit -m "<Message du commit>"
git push origin HEAD:refs/for/master
```

**Remarque** : Pour toute modification supplémentaire sur gerrit, il faudra remplacer la commande `git commit -m "<Message du commit>` par `git commit --amend`.

* Sur Gerrit : vérifier les modifications, les faire relire à un pair, puis accepter ces modifications (submit).

# Déploiement sur AWX

* Se rendre sur le serveur de déploiment AWX (https://awx.bu-dsa.si.c-s.fr), et se connecter via ses identifiants LDAP

* Se rendre dans l'onglet "Projets" et mettre à jour le projet `centos_playbooks`.

* Se rendre dans l'onglet "Modèles", et cliquer sur la fusée du modèle suivant :

* **Si la cible doit être boostrapée :**
    * Lancer le modèle `Infra - Bootstrap CentOS` avec les options suivantes :
        - limite : `<nom_court>`
        - balise de tâche : champ vide
        - balise de saut : champ vide

* **Si la cible n'a pas à être boostrapée :**
    * Pour pousser la configuration Nagios, lancer le modèle `Infra - Synchronisation Nagios` avec les options suivantes :
        - limite : `lpr-nagios-01v,<nom_court>`
        - balises de tâche : `nagios nagios-host`
        - balises de saut : `firewall yum_nrpe`

    * Pour pousser la configuration Bacula, lancer le modèle `Infra - Synchronisation Bacula` avec les options suivantes :
        - limite : `lpr-backup-01v,<nom_court>`
        - balises de tâche : `bacula bacula-client`
        - balises de saut : `firewall yum_nrpe`

* Lancer le playbook.

Si la procédure s'est bien déroulée, toutes les actions devraient être "OK" ou "Changed" (vert ou orange) à la fin de l'exécution du playbook.

**Remarque** :

* La balise de saut `firewall` garantit que le firewall ne sera pas rafraichi.

* Dans le cas où on ajoute seulement un client Nagios, et que le check ajouté est indiqué comme "server-side only", (le playbook ne peut le configurer que côté serveur), il n'est pas nécessaire d'ajouter le serveur à superviser dans les limites du playbook. Les trois champs sont alors :

    - limite : `lpr-nagios-01v`
    - balises de tâche : `nagios-host`
    - balises de saut : un champ vide

* Si la cible est déjà dans les clients du serveur Bacula, il n'est pas nécessaire de l'ajouter dans les limites du playbook pour modifier la configuration de sa sauvegarde. Les trois champs sont alors :

    * limite : `lpr-backup-01v`
    * balises de tâche : `bacula-client`
    * balises de saut : un champ vide


# Décommissionnement de la cible

Pour retirer la cible de la liste des clients Bacula et Nagios,il faut:

* Supprimer toutes les lignes relatives à la cible dans le fichier `hosts.ini`.
* Supprimer le fichier `<nom_court>.yaml`
* Pousser les modifications sur gerrit et les accepter
* Sur awx, synchroniser le projet, puis lancer les tâches suivants :
    * `Infra - Synchronisation Bacula`
        - limite : `lpr-backup-01v`
        - balises de tâche : `bacula-client`
        - balises de saut : un champ vide

    * `Infra - Synchronisation Nagios` avec les options :
        - limite : `lpr-nagios-01v`
        - balises de tâche : `nagios-host`
        - balises de saut : un champ vide


# Annexes

## Nagios
### Détails des commandes

Toutes ces commandes sont définies par défaut sur le serveur. Cependant, elles ne sont pas nécessairement liées à un service. L'utilisateur est fortement incité à consulter le fichier `commands_vars.yaml` avant d'utiliser une commande.

| Commande                  | Plugin             | Description
| --------------------------|--------------------|-------------------------------------------------------------------------------------------|
| check_certif              | check_certif       | Vérifie si les certificats ssl indiqués dans /etc/check_certif.conf sont à jour           |
| check_dns                 | check_dns          | Obtient l'adresse IP locale                                                               |
| check_dns_addr            | check_dns          | Obtient l'adresse IP de l'hôte/domaine à interroger                                       |
| check_http_url            | check_http         | Vérifie l'accès via HTTP à l'adresse donnée                                               |
| check_ldap                | check_ldap         | Vérifie la connexion au ldap                                                              |
| check_nginx               | check_nginx        | Vérifie le status de du service nginx                                                     |
| check_nrpe	            | check_nrpe         | Permet de réaliser des commandes sur les clients nrpe                                     |
| check_ommemory            | check_omreport     | Vérifie la mémoire physique restante sur la machine                                       |
| check_ping_addr           | check_ping         | Ping une adresse IP spécifique depuis le serveur nagios                                   |
| check_proxy               | check_tcp          | Vérifie l'accès à l'hôte via un port spécifié                                             |

Les commandes suivantes sont les commandes nrpe déployées sur les clients Nagios. Elles sont définies dans le fichier `/roles/nagios_server/vars/command_vars.yaml` sous la forme check_nrpe_xxx et dans le fichier `roles/centos_bootstrap/vars/nrpe_commands.yaml` sous la forme donnée ci-dessous.

| Commande nrpe             | Plugin             | Description                                                                               |
| --------------------------|--------------------|-------------------------------------------------------------------------------------------|
| check_conntrack           | check_conntrack    | Vérifie l'état des connexions réseau                                                      |
| check_cpu                 | check_cpu          | Vérifie l'utilisation courante du cpu                                                     |
| check_disk                | check_disk         | Vérifie l'espace mémoire restant sur la machine                                           |
| check_hpsa                | check_hpsa         | Vérifie le HP Smart Array via hpacucli                                                    |
| check_http                | check_http         | Vérifie l'accès via HTTP à l'hôte                                                         |
| check_load                | check_load         | Teste la charge système actuelle                                                          |
| check_megaraid_sas        | check_megaraid_sas | Vérifie le statut des volumes attachés au contrôlleur LSI Megaraid SAS                    |
| check_memcached           | check_memcached    | Vérifie l'état de la mémoire cache partagée via memcached                                 |
| check_mountpoints         | check_mountpoints  | Vérifie si les systèmes de fichiers spécifiés sont bien montés                            |
| check_mptsas              | check_mpt_sas      | Vérifie l'état des contrôleurs raid via lsiutils                                          |
| check_ntp_time            | check_ntp_time     | Vérifie l'écart du temps entre le serveur ntp et l'hôte                                   |
| check_procs               | check_procs        | Vérifie si les processus sont dans les bornes attendues (selon leur nombre et leur état)  |
| check_ram                 | check_ram          | Vérifie l'utilisation courante de la ram                                                  |
| check_service             | check_service.sh   | Commande inutile par elle-même, mais permet l'installation du plugin check_service.sh     |
| check_service_elastic     | check_service.sh   | Vérifie l'état du service elasticsearch                                                   |
| check_service_gerrit      | check_service.sh   | Vérifie l'état du service gerrit                                                          |
| check_service_jenkins     | check_service.sh   | Vérifie l'état du service jenkins                                                         |
| check_service_kibana      | check_service.sh   | Vérifie l'état du service kibana                                                          |
| check_service_klocwork    | check_service.sh   | Vérifie l'état du service klocwork                                                        |
| check_service_mattermost  | check_service.sh   | Vérifie l'état du service mattermost                                                      |
| check_service_obeolic     | check_service.sh   | Vérifie l'état du service obeo-license-server                                             |
| check_service_obeoserver  | check_service.sh   | Vérifie l'état du service service-odts.sh                                                 |
| check_service_postgres    | check_service.sh   | Vérifie l'état du service postgresql                                                      |
| check_service_sonar       | check_service.sh   | Vérifie l'état du service sonar                                                           |
| check_swap                | check_swap         | Vérifie le pourcentage du swap utilisé                                                    |
| check_total_procs         | check_procs        | Vérifie le nombre de total de processus en cours                                          |
| check_users               | check_users        | Vérifie le nombre d'utilisateurs connectés sur la machine                                 |
| check_zombie_procs        | check_procs        | Vérifie le nombre de processus qui ont l'état 'zombie'                                    |

### Commandes spécifiques omreport
Le plugin omreport permet de vérifier l'état matériel des serveurs Dell. Toutes les commandes omxxx sont définies sous la forme "check_nrpe_omxxx" côté serveur Nagios et sous la forme "check_xxx" côté client Nagios.

| Commande                  | Option            | Description                                                                                   |
| --------------------------|-------------------|-----------------------------------------------------------------------------------------------|
| check_ombatteries         | --only batteries  | Vérifie l'état de la batterie                                                                 |
| check_omcpu               | --only cpu        | Vérifie le taux d'occupation du cpu                                                           |
| check_omfans              | --only fans       | Vérifie l'état des ventilateurs                                                               |
| check_ommemory            | --only memory     | Vérifie la mémoire physique restante sur la machine et l'état physique des modules mémoires   |
| check_ompower             | --only power      | Vérifie la capacité des alimentations électriques                                             |
| check_omtemp              | --only temp       | Vérifie la température du matériel                                                            |
| check_omvoltage           | --only voltage    | Vérifie le voltage                                                                            |

### Commandes spécifiques mysql

Toutes ces commandes sont définies sous la forme "check_nrpe_mysql_health_mode" côté serveur et "check_mysql_health_mode" côté client. Les descriptions sont prises directement de la documentation du plugin check_mysql_health.

| Mode                     | Description                                                                                                        |
|--------------------------|--------------------------------------------------------------------------------------------------------------------|
| bufferpool-hitrate       | InnoDB buffer pool hitrate                                                                                         |
| bufferpool-wait-free     | InnoDB buffer pool waits for clean page available                                                                  |
| connection-time          | Time to connect to the server                                                                                      |
| index-usage              | Usage of indices                                                                                                   |
| keycache-hitrate         | MyISAM key cache hitrate                                                                                           |
| log-waits                | InnoDB log waits because of a too small log buffer                                                                 |
| open-files               | Percent of opened files                                                                                            |
| qcache-hitrate           | Query cache hitrate                                                                                                |
| qcache-lowmem-prunes     | Query cache entries pruned because of low memory                                                                   |
| slave-io-running         | Slave io running: Yes                                                                                              |
| slave-lag                | Seconds behind master                                                                                              |
| slave-sql-running        | Slave sql running: Yes                                                                                             |
| slow-queries             | Slow queries                                                                                                       |
| table-lock-contention    | Table lock contention                                                                                              |
| tablecache-hitrate       | Table cache hitrate                                                                                                |
| threads-connected        | Number of currently open connections                                                                               |
| threadcache-hitrate      | Hit rate of the thread-cache                                                                                       |
| tmp-disk-tables          | Percent of temp tables created on disk                                                                             |
| uptime                   | Time the server is running                                                                                         |

### Commandes spécifiques postgresql

Toutes ces commandes sont définies sous la forme "check_nrpe_postgres_action" côté serveur, et "check_postgres_action" côté client. Les descriptions sont prises directement de la documentation du plugin check_postgres.pl

| Action                     | Description                                                                                                      |
|----------------------------|------------------------------------------------------------------------------------------------------------------|
| archive_ready              | Check the number of WAL files ready in the pg_xlog/archive_status (option inutile pour Centos8)                  |
| autovac_freeze             | Checks how close databases are to autovacuum_freeze_max_age                                                      |
| backends                   | Number of connections, compared to max_connections                                                               |
| connection                 | Simple connection check                                                                                          |
| database_size              | Report if a database is too big                                                                                  |
| disabled_triggers          | Check if any triggers are disabled                                                                               |
| disk_space                 | Checks space of local disks Postgres is using                                                                    |
| fsm_pages                  | Checks percentage of pages used in free space map                                                                |
| fsm_relations              | Checks percentage of relations used in free space map                                                            |
| last_analyze               | Check the maximum time in seconds since any one table has been analyzed                                          |
| last_autoanalyze           | Check the maximum time in seconds since any one table has been autoanalyzed                                      |
| last_autovacuum            | Check the maximum time in seconds since any one table has been autovacuumed                                      |
| last_vacuum                | Check the maximum time in seconds since any one table has been vacuumed                                          |
| listener                   | Checks for specific listeners                                                                                    |
| locks                      | Checks the number of locks                                                                                       |
| logfile                    | Checks that the logfile is being written to correctly                                                            |
| new_version_cp             | Checks if a newer version of check_postgres.pl is available                                                      |
| new_version_pg             | Checks if a newer version of Postgres is available                                                               |
| prepared_txns              | Checks number and age of prepared transactions                                                                   |
| query_time                 | Checks the maximum running time of current queries                                                               |
| same_schema                | Verify that two databases have the exact same tables, columns, etc.                                              |
| sequence                   | Checks remaining calls left in sequences                                                                         |
| settings_checksum          | Check that no settings have changed since the last check                                                         |
| table_size                 | Checks the size of tables only                                                                                   |
| timesync                   | Compare database time to local system time                                                                       |
| txn_idle                   | Checks the maximum "idle in transaction" time                                                                    |
| txn_time                   | Checks the maximum open transaction time                                                                         |
| txn_wraparound             | See how close databases are getting to transaction ID wraparound                                                 |
| version                    | Check for proper Postgres version                                                                                |
| wal_files                  | Check the number of WAL files in the pg_xlog directory                                                           |

## Bacula

### Fileset

+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
|      FileSet      |                               Include                                                   |                        Exclude                            |
+===================+=========================================================================================+===========================================================+
| Common            |- /etc                                                                                   |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| system            |- /etc                                                                                   |                                                           |
|                   |- /usr/local/backup.d                                                                    |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| default           |- /etc                                                                                   |- /var/log                                                 |
|                   |- /var                                                                                   |- /var/lib/kvm                                             |
|                   |- /home                                                                                  |- /var/lib/libvirt                                         |
|                   |- /srv                                                                                   |                                                           |
|                   |- /tmp/backup                                                                            |                                                           |
|                   |- /opt                                                                                   |                                                           |
|                   |- /root                                                                                  |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| Common-srvinfra   |- /etc                                                                                   |                                                           |
|                   |- /images/data-vm                                                                        |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| VM-srsa-vms       |- /var/lib/kvm/pool1                                                                     | - /var/lib/kvm/pool1/nobackup                             |
|                   |- /var/lib/kvm/pool2                                                                     | - /var/lib/kvm/pool2/isos                                 |
|                   |                                                                                         | - /var/lib/kvm/pool2/nobackup                             |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| VM-hyp02          | - /export                                                                               |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| VM-infra          |- /images/vm-webplanif_sda.qcow2                                                         |- /images/isos                                             |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| gobniou           |- /etc                                                                                   |- /export/projet/stock                                     |
|                   |- /var                                                                                   |- /var/log                                                 |
|                   | - /home                                                                                 |- /var/lib/kvm                                             |
|                   | - /root                                                                                 |- /var/lib/libvirt                                         |
|                   | - /backupsys/home-plus                                                                  |                                                           |
|                   | - /export/home                                                                          |                                                           |
|                   | - /export/projet                                                                        |                                                           |
|                   | - /backupsys/Annual-backup                                                              |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| nas_on_srv-infra  |- /mnt/nas/NVCSINT/Outils_CMoIP_INST                                                     | - /var/log                                                |
|                   |- /mnt/nas/LIVRAISONS                                                                    | - /var/lib/kvm                                            |
|                   |- /mnt/nas/LIVRAISONS_INTEGRATION                                                        | - /var/lib/libvirt                                        |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| obeo              |- /etc                                                                                   | - /var/log                                                |
|                   |- /var                                                                                   | - /var/lib/kvm                                            |
|                   |- /home                                                                                  | - /var/lib/libvirt                                        |
|                   |- /srv                                                                                   |                                                           |
|                   |- /tmp/backup                                                                            |                                                           |
|                   |- /opt                                                                                   |                                                           |
|                   |- /opt/obeo                                                                              |                                                           |
|                   |- /var/lib/h2                                                                            |                                                           |
|                   |- /var/lib/h2backup                                                                      |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| srv-filer         |- /etc                                                                                   | - /var/log                                                |
|                   |- /var                                                                                   | - /var/lib/kvm                                            |
|                   |- /home                                                                                  | - /var/lib/libvirt                                        |
|                   |- /srv                                                                                   |                                                           |
|                   |- /opt                                                                                   |                                                           |
|                   |- /share                                                                                 |                                                           |                                                    |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| windows           |- c:/                                                                                    | - c:/temp/                                                |
|                   |- d:/                                                                                    | - c:/windows                                              |
|                   |- e:/                                                                                    |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+
| Catalog           |- /var/spool/bacula/bacula.sql                                                           |                                                           |
+-------------------+-----------------------------------------------------------------------------------------+-----------------------------------------------------------+

### Schedule

+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| Schedule               | Description                                                                                                              |
+========================+==========================================================================================================================+
| Default                | Full sun at 2:05\                                                                                                        |
|                        | Incremental mon-sat at 2:05                                                                                              |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| WeeklyCycleAfterBackup | Full sun-sat at 06:10                                                                                                    |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| monthly                | Full 1st saturday at 02:00                                                                                               |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| weekly                 | Incremental  monday-friday at 21:15\                                                                                     |
|                        | Differential 2nd-5th saturday at 02:00\                                                                                  |
|                        | Full 1st saturday at 02:00                                                                                               |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| weekly-2nd             | Incremental  monday-friday at 22:00\                                                                                     |
|                        | Differential 1st,3rd,4th,5th saturday at 03:00\                                                                          |
|                        | Full 2st saturday at 02:00                                                                                               |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| weekly-3rd             | Incremental  monday-friday at 22:00\                                                                                     |
|                        | Differential 1st,2rd,4th,5th saturday at 03:00\                                                                          |
|                        | Full 3rd saturday at 02:00                                                                                               |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| weekly_temp            | Full 1st-5th saturday at 02:00                                                                                           |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| monthly-2nd-Mardi      | Full 2nd tuesday at 02:00                                                                                                |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
| Disable                |                                                                                                                          |
+------------------------+--------------------------------------------------------------------------------------------------------------------------+
