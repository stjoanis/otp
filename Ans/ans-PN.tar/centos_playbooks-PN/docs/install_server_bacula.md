# Introduction

Ce document décrit la procédure à suivre pour la primo-installation d'un serveur Bacula avec Ansible. L'utilisateur est fortement conseillé de consulter le playbook Ansible `centos_playbooks`, et le dossier `procedures` compris dans le dépôt avant de suivre cette procédure.

# Préparation du serveur

* Rendre l'hôte concerné accessible par le réseau.
    - Configurer son interface réseau
    - Configurer le serveur DNS

* Injecter la clé SSH d'administration CIaaS (cf : Keepass) dans les clés acceptées par l'utilisateur `admin`.

```bash
ssh-copy-id -i <path/to/public_key> admin@'<ip>'
```

* Le compte `admin` doit avoir les droits 'sudo' et le mot de passe du compte `admin` doit correspondre à la valeur de la variable `ansible_become_pass`.

# Modification du playbook Ansible

## Récupération du playbook

* Se rendre sur la page `https://gerrit.bu-dsa.si.c-s.fr/admin/repos/ciaas/centos_playbooks`, cloner le dépôt via la commande indiquée dans "Clone with commit-msg hook".

## Ajout de la cible

* Ajouter la cible dans `hosts.ini` (suivre la nomenclature `<nom_court>   ansible_host=<adresse_dns>`). L'ajouter dans un groupe parmi `[virtual]`, `[physical]` ou `[sccoa]`, **ET** l'ajouter dans les groupes `[bacula-server]` et `[bacula-client]`

* Créer le fichier `<nom_court>.yaml` dans le dossier `host_vars`.

* S'inspirer des autres fichiers du dossier `host_vars` pour remplir les variables `centos`, `proxy`,`hostname`,  `secure`, `disable_selinux` (si nécessaire, copier-coller un autre fichier et l'adapter).

## Configuration des identifiants Bacula

* Dans le fichier `group_vars/bacula_server.yaml`, remplir les champs :

    - `mysql_root_password` (mot de passe root de la db mysql)
    - `bacula_mysql_password` (mot de passe bacula pour la db bacula)
    - `baculum_admin_pass` (mot de passe du compte admin créé par défaut)

    Il est conseillé de mettre des mots de passe aléatoire et de les stocker dans le keepass

* Dans le même fichier, indiquer les utilisateurs autorisés à s'authentifier sur Baculum dans la liste `baculum_users`.

## Mot de passe bacula-fd et bacula-sd

* Dans le fichier `group_vars/bacula-server.yaml`, remplir le champ `bacula_storage_host` avec l'adresse du `bacula-sd`.

* Dans le fichier `group_vars/bacula-client`, indiquer dans le champ `bacula_server` l'adresse du nouveau serveur bacula, et indiquer dans le champ `bacula_password` le mot de passe à utiliser pour contacter les clients Bacula.

**Remarque** : Le même mot de passe est utilisé pour contacter tous les bacula-fd et le bacula-sd.

## Configuration des clients

Toutes les cibles du groupe `[bacula-client]` seront ajoutées comme clients Bacula dans la configuration du nouveau serveur.

Pour ajouter des cibles dans ce groupe, veuillez consulter le document d'ajout de cible.

# Ajout des modifications sur Gerrit

* Une fois le playbook modifié, vérifier les documents modifiés avec les commandes `git status` et `git diff`.

* Pousser les changements sur gerrit :

```bash
git add <fichier(s) modifies>
git commit -m "<Message du commit>"
git push origin HEAD:refs/for/master
```

**Remarque** : Pour toute modification supplémentaire sur gerrit, il faudra remplacer la commande `git commit -m "<Message du commit>` par `git commit --amend`.

* Sur Gerrit : vérifier les modifications, les faire relire à un pair, puis accepter ces modifications (submit).

# Déploiement sur AWX

* Se rendre sur le serveur de déploiment AWX (https://awx.bu-dsa.si.c-s.fr), et se connecter via ses identifiants LDAP

* Se rendre dans l'onglet "Projets" et mettre à jour le projet `centos_playbooks`.

* Se rendre dans l'onglet "Modèles", et cliquer sur la fusée du modèle suivant :

* **Si la cible doit être boostrapée :**
    * Lancer le modèle `Infra - Bootstrap CentOS` avec les options suivantes :
        - limite : `<nom_de_la_cible>`
        - balise de tâche : champ vide
        - balise de saut : champ vide

* **Si la cible n'a pas à être boostrapée :**
    * Lancer le modèle `Infra - Bootstrap CentOS` avec les options suivantes :
        - limite : `<nom_de_la_cible>`
        - balises de tâche : `bacula-install bacula-client bacula-baculum`
        - balises de saut : champ vide

* Dans le champ des variables supplémentaires, indiquer les valeurs des variables suivantes :

```yaml
mysql_root_password: <Change_Me>
bacula_mysql_password: <Change_Me>
baculum_admin_pass: <Change_Me>
```

* Lancer le playbook.

Si la procédure s'est bien déroulée, toutes les actions devraient être "OK" ou "Changed" (vert ou orange) à la fin de l'exécution du playbook.

**Remarque :** Pour modifier la configuration des clients Bacula, se référer au document d'ajout d'une cible.

# Post-installation

* Ajouter les variables suivantes dans les variables Ansible du serveur :

```yaml
yum_nrpe: false
update: false
bacula_mysql_secure: false
```
Ces variables garantissent l'omnipotence de la configuration du serveur Bacula lors des ajouts des clients.

* Si le serveur Bacula doit également être supervisé :
    - dans le fichier `hosts.ini`, ajouter le serveur au groupe `[nagios-client]`
    - dans les variables Ansible du serveur, ajouter les valeurs
        - `check_service: true`
        - `check_service_bacula: true`
    - Se référer à la documentation d'ajout d'une cible pour l'exécution du playbook


# Annexes

## Problèmes connus

### Bacula

* Si le `bacula-sd` ne parvient pas à contacter le robot de sauvegarde :

    - ajouter l'utilisateur bacula au groupe tape

* Si l'exécution du playbook envoie une erreur après que le mot de passe mysql ait été changé, il faut relancer le playbook en ajoutant lors de l'exécution la variable `bacula_mysql_secure: false`. Cette variable permet de sauter les tâches de configuration de la base de données.

### Baculum

* Si l'onglet Volumes indique une erreur liée à la `timezone` :
    - Ouvrir le fichier `/usr/share/baculum/htdocs/protected/API/Class/VolumeManager.php`
    - Au début de la fonction `setWhenExpire`, ajouter la ligne `date_default_timezone_set('Europe/Paris)`.

* Si le site indique qu'il a atteint sa limite de mémoire :
    - Modifier le fichier `/etc/php.ini` pour augmenter la valeur de `memory_limit`
    - Dans les settings de l'IHM Baculum, diminuer le nombre de jobs à afficher

* Pour la configuration du LDAP, baculum utilise la variable `ldap_bind_pass`. Si cette variable n'est pas configurée lors de l'installation de baculum, la tâche renvoie une erreur, ou un mauvais mot de passe est fourni. Il faut alors relancer la tâche `bacula_baculum` en fournissant lors de l'exécution la variable `ldap_bind_pass: <mot_de_passe_de_bind>`.