# Introduction

Ce document décrit la procédure à suivre pour la primo-installation d'un serveur Nagios avec Ansible. L'utilisateur est fortement conseillé de consulter le playbook Ansible `centos_playbooks`, et le dossier `procedures` compris dans le dépôt avant de suivre cette procédure.

# Préparation du serveur

* Rendre l'hôte concerné accessible par le réseau.
    - Configurer son interface réseau
    - Configurer le serveur DNS

* Injecter la clé SSH d'administration CIaaS (cf : Keepass) dans les clés acceptées par l'utilisateur `admin`.

```bash
ssh-copy-id -i <path/to/public_key> admin@'<ip>'
```

* Le compte `admin` doit avoir les droits 'sudo' et le mot de passe du compte `admin` doit correspondre à la valeur de la variable `ansible_become_pass`.

# Modification du playbook Ansible

## Récupération du playbook

* Se rendre sur la page `https://gerrit.bu-dsa.si.c-s.fr/admin/repos/ciaas/centos_playbooks`, cloner le dépôt via la commande indiquée dans "Clone with commit-msg hook".

## Ajout de la cible

* Ajouter la cible dans `hosts.ini` (suivre la nomenclature `<nom_court>   ansible_host=<adresse_dns>`). L'ajouter dans un groupe parmi `[virtual]`, `[physical]` ou `[sccoa]`, **ET** l'ajouter dans les groupes `[nagios-server]` et `[nagios-client]`

* Créer le fichier `<nom_court>.yaml` dans le dossier `host_vars`.

* S'inspirer des autres fichiers du dossier `host_vars` pour remplir les variables `centos`, `proxy`,`hostname`,  `secure`, `disable_selinux` (si nécessaire, copier-coller un autre fichier et l'adapter).

## Configuration Nagios

Pour la configuration des checks, veuillez consulter le document d'ajout d'une cible.

Pour la configuraiton du serveur, remplir la variable `nagios_admin_password` avec un mot de passe et la stocker dans le Keepass. Ce mot de passe est utilisé pour se connecter à Nagios en cas de panne du LDAP.

# Ajout des modifications sur Gerrit

* Une fois le playbook modifié, vérifier les documents modifiés avec les commandes `git status` et `git diff`.

* Pousser les changements sur gerrit :

```bash
git add <fichier(s) modifies>
git commit -m "<Message du commit>"
git push origin HEAD:refs/for/master
```

**Remarque** : Pour toute modification supplémentaire sur gerrit, il faudra remplacer la commande `git commit -m "<Message du commit>` par `git commit --amend`.

* Sur Gerrit : vérifier les modifications, les faire relire à un pair, puis accepter ces modifications (submit).

# Déploiement sur AWX

* Se rendre sur le serveur de déploiment AWX (https://awx.bu-dsa.si.c-s.fr), et se connecter via ses identifiants LDAP

* Se rendre dans l'onglet "Projets" et mettre à jour le projet `Bootstrap CentOS CIaaS`.

* Se rendre dans l'onglet "Modèles", et cliquer sur la fusée liée au modèle `Bootstrap CentOS CIaaS`.

* **Si la cible doit être boostrapée :**
    * Lancer le modèle `Infra - Bootstrap CentOS` avec les options suivantes :
        - limite : `<nom_de_la_cible>`
        - balise de tâche : champ vide
        - balise de saut : champ vide

* **Si la cible n'a pas à être boostrapée :**
    * Lancer le modèle `Infra - Bootstrap CentOS` avec les options suivantes :
        - limite : `<nom_de_la_cible>`
        - balises de tâche : `nagios-install nagios-host nagios-conf`
        - balises de saut : champ vide

* Lancer le playbook.

Si la procédure s'est bien déroulée, toutes les actions devraient être "OK" ou "Changed" (vert ou orange) à la fin de l'exécution du playbook.

**Remarque :** Pour modifier la configuration des clients Nagios, se référer au document d'ajout d'une cible.