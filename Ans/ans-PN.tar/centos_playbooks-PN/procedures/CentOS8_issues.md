CentOS 8 : Problèmes connus
===========================

## Controller RAID non reconnu

### Symptômes

Les disques du serveur ne sont pas reconnus par l'installateur de CentOS 8. De ce fait, il est impossible d'installer CentOS 8 car il est impossible de sélectionner un support pour l'OS.

### Résumé

Dans la version 8 de son OS, Red Hat a pris la décision de retirer de nombreux pilotes logiciel et notamment les pilotes des vieux controllers RAID, devenus obsolètes. Ce nettoyage concerne un grand nombre de matériel encore utilisé en entreprise tel que les controllers RAID LSI Megaraid SAS 2008 utilisé par certains serveurs Dell de l'équipe CIaaS. L'absence de ces pilotes empêche CentOS 8 de détecter les disques du serveur, il est alors impossible de les sélectionner dans l'installateur Anaconda et donc de procéder à l'installation de CentOS 8.

### Solution

Pour installer CentOS 8, il est alors nécessaire d'installer manuellement le pilote du controller RAID avant le lancement de l'installateur. Pour ce faire, il faut récupérer le pilote adéquat sur le dépôt suivant https://elrepo.org/linux/dud/el8/x86_64/.

Pour identifier le pilote recherché, il faut relever la référence du controller RAID, via la commande `lspci` dans un shell de l'installateur (ctrl + F2 après le boot de l'installateur), puis rechercher cette référence dans la page suivante : http://elrepo.org/tiki/DeviceIDs

Par exemple, pour Dagonet, la commande `lspci -nn` donne la référence suivante :
```
03:00.0 RAID bus controller [0104]: Broadcom / LSI MegaRAID SAS 2008 [Falcon] [1000:0073] (rev 03)
```

Puis en recherchant cette référence (1000:0073) sur ElRepo, on constate que le pilote necessaire est le `megaraid_sas.ko`. De ce fait, le pilote à télécharger est le fichier `dd-megaraid_sas-*.elrepo.iso`.

Une fois récupéré, le pilote doit être placé à la racine d'une clé USB, distincte de la clé d'installation de CentOS 8.

Brancher alors les deux clés sur le serveur à installer et booter sur la clé CentOS 8. Dans le menu Grub de l'installateur, presser `<TAB>` et rajouter, en fin de ligne, l'option de boot `inst.dd` puis lancer le boot avec la touche `<Entrée>`.

Pendant la séquence de démarrage, l'installateur demande de choisir le périphérique contenant le pilote, puis le fichier du pilote en lui même. Une fois sélectionné, l'installateur installe le driver et poursuit la séquence de démarrage.

Suite à cette procédure, les disques devraient être tous visibles dans la section dédiée de l'installateur Anaconda. Il est alors possible de sélectionner le disque souhaité et de le partitionner pour l'installation de CentOS 8.

Une fois l'installation terminée, redémarrer le serveur et retirer les deux clés afin de booter sur le CentOS 8 fraichement installé.

### Ressources

Les sites suivant traitent du problèmes et de sa solution :

- https://gainanov.pro/eng-blog/linux/rhel8-install-to-dell-raid/
- https://elrepo.org/linux/dud/el8/x86_64/
- https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html/performing_an_advanced_rhel_installation/updating-drivers-during-installation_installing-rhel-as-an-experienced-user#performing-an-assisted-driver-update_updating-drivers-during-installation
