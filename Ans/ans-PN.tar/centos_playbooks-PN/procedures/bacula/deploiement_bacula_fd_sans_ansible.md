# Configuration d'un client bacula-fd sans ansible

## Installation de bacula-fd

Si bacula-fd n'est pas déjà installé sur la machine cliente, l'installer:

```bash
yum install -y bacula-client
```

Changer le nom du file daemon :

```bash
sed -i -e 's/bacula-fd/{{host_address}}-fd/' /etc/bacula/bacula-fd.conf
```

## Ajout du nouveau serveur bacula

Ajouter le bacula director lié au nouveau serveur bacula :

```bash
cat <<EOT >>/etc/bacula/bacula-fd.conf
Director {
    Name     = lpr-backup-01v.bu-dsa.si.c-s.fr-dir
    Password = "secret"
}
EOT
```