Installation du Bacula Director CIaaS via Ansible
=================================================

## Rôle bacula_server

Le rôle bacula-server contient trois tâches : `install.yaml`, `clients.yaml` et `bacula.yaml`. Ces trois tâches dépendent de templates, de variables et de fichiers définis dans le rôle. L'achitecture globale du rôle est ainsi :
- `install.yaml`
   * Dépendances fichiers :
      - `plugins/`
      - `jobdefs.conf`
      - `schedule.conf`
   * Dépendances templates :
      - `bacula-dir.j2`
      - `bacula-fd.j2`
      - `bacula-sd.j2`
      - `bconsole.j2`
      - `conf.d/pools.j2`
      - `conf.d/storage.j2`
- `clients.yaml`
   * Dépendances templates :
      - `conf.d/client.j2`
      - `conf.d/dynamic-fileset.j2`
      - `conf.d/fileset.j2`
      - `conf.d/dynamic-job.j2`
      - `conf.d/job.j2`
   * Dépendances variables :
      - `fileset.yaml`
      - variables des clients bacula
- `baculum.yaml`
   * Dépendances templates :
      - `api.conf.j2`
      - `web-hosts.conf.j2`
      - `web-settings.conf.j2`
      - `web-users.conf.j2`

Les paragraphes suivants décrivent les tâches plus en détail.

## Installation du bacula-director [rôle bacula_server]

Le rôle bacula-server installe et configure un serveur bacula sur les machines du groupe bacula-server. Les clients (`bacula_hosts`) sont définis dans les variables du groupe bacula-server. L'installation et la configuration sont réalisées en deux phases :

### L'installation [bacula-install]

L'installation est réalisée par la tâche `install.yaml`.\
Celle-ci ouvre les trois ports relatifs respectivement aux daemons `bacula-sd`, `bacula-fd` et `bacula-dir`. Elle ajoute le dépôt de la version `9.6.7` de Bacula et l'installe, de même que `mysql-server`.\
La tâche crée ensuite la base de données relative à Bacula, puis sécurise le serveur MySQL. La tâche configure les trois daemons `bacula-fd`, `bacula-sd` et `bacula-dir` ainsi que l'application `bconsole`, puis elle crée les fichiers nécessaires à la configuration du `bacula-dir`.\
Les fichiers `jobdefs.conf`, `schedule.conf` et `pools.conf` sont définis uniquement dans cette tâche.\
Les fichiers `client.conf`, `job.conf`, `fileset.conf`, `dynamic-job.conf`, `dynamic-fileset.conf` sont créés vide lors de l'exécution de cette tâche.

Enfin, la tâche crée des liens symboliques vers les exécutables `bacula-dir`, `bacula-fd` et `bconsole`, puis démarre les services `bacula-dir` et `bacula-fd`.

**Remarque** : le service `bacula-sd` est configuré lors de l'installation, mais n'est pas utilisé par la suite. Le serveur Bacula fait appel à un serveur de stockage externe.

### Définition des clients bacula [bacula-client]

Les clients, les ensemble de fichiers (`filesets`) ainsi que les tâches de sauvegarde (`jobs`) sont configurées dans la tâche `clients.yaml`.\
Cette tâche configure les fichiers `client.conf`, `fileset.conf`, `job.conf`, `dynamic-fileset.conf` et `dynamic-job.conf`.
- `client.conf`\
Ce fichier utilise la variable `hostname` définie dans les variables de l'hôte ansible, ainsi que la variable `bacula_password`, définie dans les variables du groupe ansible `bacula-client`. Il définit les clients Bacula et le mot de passe à utiliser pour joindre leur `file daemon`.

- `fileset.conf`\
Ce fichier utilise les variables définies dans le fichier `fileset.yaml`. Il définit des ensembles de fichiers (`filesets`) qui doivent être sauvegardés lors des tâches de sauvegardes.

- `job.conf`\
Ce fichier utilise la variable `hostname` définie dans les variables de l'hôte ansible, ainsi que les variables `bacula_fileset`, `bacula_runbefore`, `bacula_schedule` et, si elle est définie, `bacula_priority` définies par défaut dans les variables du groupe `bacula-client`. Dans le cas où le dictionnaire `bacula_specific_job` est défini dans les variables d'hôtes, il est également utilisé.\
Ce fichier définit les tâches de sauvegarde et de restauration qui doivent être réalisés pour chaque client.

- `dynamic-fileset.conf`\
Ce fichier utilise la variable `hostname` et le dictionnaire `bacula_service_save` défini dans les variables de l'hôte ansible.\

- `dynamic-job.conf`\
Ce fichier utilise la variable `hostname` et le dictionnaire `bacula_service_save` défini dans les variables de l'hôte ansible. Ce fichier configure des sauvegardes spécifiques qui utilisent les filesets définis dans `dynamic-fileset.conf`, et les plugins `ciaas_before.sh` et `ciaas_after.sh` afin de réaliser des sauvegardes des services définis dans `bacula_service_save`.

**Remarque** : Par défaut, Bacula configure une sauvegarde journalière du dossier `/etc`, et une tâche de restauration pour chaque client. Ces paramètres sont déclarés dans les variables du groupe `bacula-client` et peuvent être modifiées dans les variables de l'hôte ansible.

### Mise en place de baculum [bacula-baculum]

Baculum permet d'avoir une interface web pour administrer Bacula. Il permet de lancer des tâches, et d'avoir un suivi clair des tâches en cours, passées et programmées.

La tâche `baculum.yaml` ouvre le port 80 (utilisé pour la redirection) et 443 (utilisé par l'interface web Baculum), ajoute les dépôts Baculum et installe l'api baculum et l'interface web baculum. La tâche configure ensuite apache, l'api et l'interface web puis démarre le service apache.
 - Baculum utilise le dossier `/tmp` pour du stockage temporaire. Si plus aucune place n'est libre dans ce dossier, Baculum n'est pas utilisable.

À la fin de ces trois tâches, le serveur bacula est installé et il est possible de le superviser depuis l'interface web `localhost:443`.