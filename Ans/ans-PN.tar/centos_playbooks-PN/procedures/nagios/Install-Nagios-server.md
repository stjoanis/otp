Installation du serveur Nagios CIaaS via Ansible
=================================================

## Rôle nagios_sever

Le rôle nagios-server installe et configure un serveur nagios sur les machines du groupe nagios-server. Les clients (`hosts`) sont définis dans les variables du groupe nagios-server. L'installation et la configuration sont réalisées en trois phases :

## L'installation [nagios-install]

L'installation est réalisée par la tâche `install.yaml`.\
Celle-ci ouvre les ports http et https pour avoir accès au Nagios Web Dashboard. Elle installe Nagios et des dépendances (telles que des plugins apache, ou python2-pip). Puis elle installe des plugins nrpe. Une partie des plugins est installée via yum, les autres plugins sont définis dans le dossier `files/plugins`. Enfin, la tâche configure le service apache pour l'interface web Nagios, à l'aide des fichiers `httpd.conf.j2`, `httpd-redirect.php.j2` et `httpd-nagios.conf.j2`, et lance les services apache et nagios.

**Remarque** : le compte administrateur `nagiosadmin` est défini dans les variables du groupe nagios-server.

## Configuration générale du serveur Nagios [nagios-conf]

Les fichiers de configuration sont définis par la tâche `general_conf.yaml`. Si cette tâche n'est pas lancée, le serveur utlisera les valeurs par défaut pour Nagios.\
Le module configure les fichiers suivants :
 - `resource.cfg`
 - `nagios.cfg`
 - `cgi.cfg`
 - `contacts.cfg`
 - `commands.cfg`
 - `timeperiods.cfg`

Les variables de chaque fichier et leurs fonctions sont définies dans le dossier `vars` sous le nom `nom_du_fichier_vars.yaml`.

**Remarque** : le fichier `commands.cfg` utilisent les variables des clients nagios pour configurer les commandes httpd.

## Définitions des hôtes et services [nagios-host]

Les hôtes, les groupes hôtes ainsi que les services sont définis via le fichier `hosts.yaml`.\
Cette tâche crée un dossier `/etc/nagios/objects/nagios_cfg`, contenant les fichiers `nagios_hosts.cfg`, `nagios_hostgroups.cfg`, `nagios_services.cfg`, définissant respectivement les hôtes nagios, les groupes hôtes et les services à lancer. Ces trois fichiers sont réalisés à partir de templates définis dans le dossier `templates`.
- `nagios_hosts.cfg`\
Ce fichier utilise la variable `hostname` définie dans les variables de l'hôte ansible. Il définit ainsi un hôte pour chaque serveur client.
- `nagios_hostgroups.cfg`\
Ce fichier utilise des variables définies dans `hostgroup_vars.yaml` et les `nagios_hostgroups` définis dans les hôtes ansible. Il définit les hostgroups nagios. Si un hôte nagios a un `nagios_hostgroup` défini et que celui-ci est également défini dans `hostgroup_vars.yaml`, le hostgroup est ajouté au fichier `nagios_hostgroups.cfg`.
- `nagios_services.cfg`\
Ce fichier utilise des variables définies dans `service_vars.yaml` et des variables définies dans les hôtes ansible clients. Il définit les services pour chaque hôte. Pour qu'un service soit défini, il doit réunir deux conditions :
   * il doit être défini dans `service_vars.yaml`
   * le nom du service ("check_xxx") doit avoir pour valeur true dans les variables du client.
Les variables utilisées vis-à-vis de l'hôte sont notamment les options de notifications, et les "check_xxx".

**Remarque** : la définition des services prend également en compte les options de notifications définies dans les variables du client.

À la fin de ces trois tâches, le serveur Nagios est fonctionnel et prend en compte les services définis dans chaque client.