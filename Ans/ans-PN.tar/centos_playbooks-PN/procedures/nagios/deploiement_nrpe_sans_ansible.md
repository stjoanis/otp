# Configuration d'un client nrpe sans ansible

## Configuration nrpe

* Si cela est possible, mettre à jour nrpe.

```bash
sudo yum update -y nrpe
```

* Ajouter le serveur `lpr-nagios-01v.bu-dsa.si.c-s.fr` dans la liste des `allowed_hosts` dans le fichier de configuration nrpe.

```bash
sed -i -e '/allowed_hosts/ s/$/,172.25.54.23,lpr-nagios-01v.bu-dsa.si.c-s.fr/' /etc/nagios/nrpe.cfg
```

* Relancer le service nrpe

```bash
systemctl restart nrpe
```

## Les plugins généraux

### Les plugins à installer via yum

* Vérifier que les plugins `check_load`, `check_ntp_time`, `check_disk`, `check_swap`, `check_users`, `check_procs` et `check_http` sont installés.

```bash
yum install -y nagios-plugins nagios-plugins-load nagios-plugins-ntp nagios-plugins-perl nagios-plugins-disk nagios-plugins-swap nagios-plugins-users nagios-plugins-procs nagios-plugins-http
```

### Les plugins à installer manuellement

* S'ils n'y sont pas présents, copier les plugins `check_conntrack`, `check_cpu` et `check_ram` présents sur ce dépôt dans le dossier `/usr/lib64/nagios/plugins/`.

```bash
cp roles/centos_bootstrap/files/nrpe_plugins/{check_conntrack,check_cpu,check_ram} /usr/lib64/nagios/plugins/
```

## Les plugins et commandes spécifiques

Les plugins et commandes décrits dans les paragraphes suivants doivent être installés/créés sur besoin.

### Le plugin mysql_health

#### Installation du plugin
Le paquet permettant d'installer mysql_health est stocké sur Nexus.

* Télécharger le paquet dans le dossier `/tmp`.

```bash
wget https://nexus.bu-dsa.si.c-s.fr/repository/public_rpm/noarch/nagios-plugins-mysql_health-2.2.1-1.el7.noarch.rpm -P /tmp/
```

* Installer le paquet

```bash
yum localinstall -y /tmp/nagios-plugins-mysql_health-2.2.1-1.el7.noarch.rpm
```

#### Modification des commandes

Les commandes attendues sont de la forme `check_mysql_health_{this-mode}` contrairement à la forme précédente `check_mysql_health_{this_mode}`.

* Ajouter les commandes nécessaires :

```bash
cp /etc/nrpe.d/nrpe-check_mysql_{this_mode} /etc/nrpe.d/nrpe-check_mysql_{this-mode}
sed -i -e 's/{this_mode}/{this-mode}/' etc/nrpe.d/nrpe-check_mysql_{this-mode}
```

### Le plugin check_postgres

#### Installation du plugin

* Copier le plugin postgres présent dans ce dépôt, dans le dossier `/usr/lib64/nagios/plugins/`.

```bash
cp roles/centos_bootstrap/files/nrpe_plugins/check_postgres.pl /usr/lib64/nagios/plugins/check_postgres
```

### Commandes liées au plugin

Les commandes n'ont pas besoin d'être modifiées.

### Les autres plugins

Le dossier roles/centos_bootstrap/files/nrpe_plugins contient les plugins :
 - check_certif
 - check_conntrack
 - check_cpu
 - check_dir_status
 - check_file_ages_in_dir
 - check_hpsa
 - check_megaraid_sas
 - check_memcached
 - check_mountpoints
 - check_mptsas
 - check_omreport
 - check_postgres.pl
 - check_ram
 - check_service
 - check_xcache

Pour les utiliser, il faut les copier dans le dossier `/usr/lib64/nagios/plugins`, créer une commande associée dans `/etc/nrpe.d/` et prévenir l'équipe CIaaS de la nouvelle commande à exécuter.

## Fin de procédure

**Remarque** : ne pas oublier de redémarrer nrpe une fois les modifications terminées.
