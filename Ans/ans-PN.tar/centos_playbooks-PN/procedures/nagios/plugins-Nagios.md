Plugins du serveur Nagios CIaaS
===============================

Ce document est découpé en deux parties : l'ajout d'un plugin personnalisé et la descriptions des plugins et commandes déjà définies.

## Ajout d'un plugin personnalisé
### Côté serveur

L'ajout d'un plugin au serveur se déroule en trois étapes :
 - ajouter le plugin dans le dossier `files/plugins` du rôle `nagios_server`.
 - définir une commande liée au plugin.
 - définir un service lié à cette commande.

Ces deux dernières étapes seront détaillés dans les paragraphes suivants.

### Côté client

L'ajout d'un plugin "check_xxx" à un client se déroule en six étapes étapes :
 - ajouter le plugin dans le dossier `files/nrpe_plugins` du rôle `centos_bootstrap`.
 - ajouter le plugin dans les variables `nrpe_plugins.yaml` dans le rôle `centos_bootstrap`.
 - ajouter la valeur `check_xxx: false` dans les variables du groupe `nagios-client` et `check_xxx: true` dans les variables de tous les clients sur lesquels on souhaite installer le plugin.
 - définir la commande liée au plugin dans les variables `nrpe_commands.yaml` du rôle `centos_bootstrap`.
 - lier cette commande à une commande dans les variables `commands_vars.yaml` du rôle `nagios_server`.
 - définir un service liée à cette commande.

Ces trois dernières étapes seront détaillées dans les paragraphes suivants.

## Ajout d'une commande
### Commande nrpe

Les commandes nrpe sont définies dans le fichier `nrpe_commands`. Elles sont défines par trois éléments :
 - le nom de la commande (appelé command)
 - le nom du plugin à utiliser (celui-ci doit être présent dans le dossier `/usr/lib64/nagios/plugins/`)
 - les arguments à utiliser lors de l'exécution du plugin

Le dernier élément, le "tag", détermine si la commande doit être configurée sur le client. Si l'on souhaite que la commande soit présente sur le client, il faut que la valeur "check_xxx" soit `true` dans les variables du client.

Une fois la commande définie pour le client, il faut la lier à une commande sur le serveur.

### Commande serveur

Les commandes serveurs sont nécessaires afin de définir les services. Ces commandes sont définies dans le fichier `command_vars.yaml` via deux éléments :
 - le nom de la commande (appelé name). Dans le cas d'une commande serveur liée à une commande nrpe, il est conseillé d'utiliser le format "check_nrpe_xxx".
 - la ligne d'exécution liée à la commande. Dans le cas d'une commande `nrpe`, la ligne d'exécution doit s'écrire sous sous la forme `"{{ nrpe + ' check_xxx' }}"`.

Une fois la commande définie, il faut la lier à un service.

## Ajout d'un service

Les services déterminent ce qui est surveillé par le serveur nagios. Ils sont définis dans le fichier `services_vars.yaml` du rôle `nagios_server`, via trois éléments :
 - le nom du service, généralement "check_xxx".
 - la commande liée au service
 - la description du service (le nom qui apparaîtra sur l'interface web)

Le dernier élément, le tag, sert à déterminer si le service doit être défini pour un hôte ansible. Si la variable "check_xxx" est `true` pour cet hôte, alors le service est défini.

## Détails des commandes

Toutes ces commandes sont définies par défaut sur le serveur. Cependant, elles ne sont pas nécessairement liées à un service. L'utilisateur est fortement incité à consulter le fichier `commands_vars.yaml` avant d'utiliser une commande.

| Commande                  | Plugin             | Description
| --------------------------|--------------------|-------------------------------------------------------------------------------------------|
| check_certif              | check_certif       | Vérifie si les certificats ssl présents dans check_certif.conf sont à jour                |
| check_dns                 | check_dns          | Obtient l'adresse IP locale                                                               |
| check_dns_addr            | check_dns          | Obtient l'adresse IP de l'hôte/domaine à interroger                                       |
| check_http_url            | check_http         | Vérifie l'accès via HTTP à l'adresse donnée                                               |
| check_ldap                | check_ldap         | Vérifie la connexion au ldap                                                              |
| check_nginx               | check_nginx        | Vérifie le status de du service nginx                                                     |
| check_nrpe	            | check_nrpe         | Permet de réaliser des commandes sur les clients nrpe                                     |
| check_ommemory            | check_omreport     | Vérifie la mémoire physique restante sur la machine                                       |
| check_ping_addr           | check_ping         | Ping une adresse IP spécifique depuis le serveur nagios                                   |
| check_proxy               | check_tcp          | Vérifie l'accès à l'hôte via un port spécifié                                             |

Les commandes suivantes sont les commandes nrpe. Elles sont définies dans le fichier `commandes.yaml` sous la forme check_nrpe_xxx.

| Commande nrpe             | Plugin                 | Description                                                                               |
| --------------------------|------------------------|-------------------------------------------------------------------------------------------|
| check_advitium            | check_advitium         | Vérifie que le site Advitium est toujours disponible                                      |
| check_conntrack           | check_conntrack        | Vérifie l'état des connexions réseau                                                      |
| check_cpu                 | check_cpu              | Vérifie l'utilisation courante du cpu                                                     |
| check_disk                | check_disk             | Vérifie l'espace mémoire restant sur la machine                                           |
| check_hpsa                | check_hpsa             | Vérifie le HP Smart Array via hpacucli                                                    |
| check_http                | check_http             | Vérifie l'accès via HTTP à l'hôte                                                         |
| check_licenses_obeo       | check_licenses_obeo.sh | Vérifie l'état des licenses Obeo                                                          |
| check_load                | check_load             | Teste la charge système actuelle                                                          |
| check_megaraid_sas        | check_megaraid_sas     | Vérifie le statut des volumes attachés au contrôlleur LSI Megaraid SAS                    |
| check_memcached           | check_memcached        | Vérifie l'état de la mémoire cache partagée via memcached                                 |
| check_mountpoints         | check_mountpoints      | Vérifie si les systèmes de fichiers spécifiés sont bien montés                            |
| check_mptsas              | check_mpt_sas          | Vérifie l'état des contrôleurs raid via lsiutils                                          |
| check_ntp_time            | check_ntp_time         | Vérifie l'écart du temps entre le serveur ntp et l'hôte                                   |
| check_procs               | check_procs            | Vérifie si les processus sont dans les bornes attendues (selon leur nombre et leur état)  |
| check_ram                 | check_ram              | Vérifie l'utilisation courante de la ram                                                  |
| check_service             | check_service.sh       | Commande inutile par elle-même, mais permet l'installation du plugin check_service.sh     |
| check_service_bacula      | check_service.sh       | Vérifie l'état du service bacula                                                          |
| check_service_elastic     | check_service.sh       | Vérifie l'état du service elasticsearch                                                   |
| check_service_gerrit      | check_service.sh       | Vérifie l'état du service gerrit                                                          |
| check_service_H2          | check_service_H2.sh    | Vérifie l'état de la base Obeo H2                                                         |
| check_service_jenkins     | check_service.sh       | Vérifie l'état du service jenkins                                                         |
| check_service_kibana      | check_service.sh       | Vérifie l'état du service kibana                                                          |
| check_service_klocwork    | check_service.sh       | Vérifie l'état du service klocwork                                                        |
| check_service_mattermost  | check_service.sh       | Vérifie l'état du service mattermost                                                      |
| check_service_postgres    | check_service.sh       | Vérifie l'état du service postgresql                                                      |
| check_service_sonar       | check_service.sh       | Vérifie l'état du service sonar                                                           |
| check_swap                | check_swap             | Vérifie le pourcentage du swap utilisé                                                    |
| check_total_procs         | check_procs            | Vérifie le nombre de total de processus en cours                                          |
| check_users               | check_users            | Vérifie le nombre d'utilisateurs connectés sur la machine                                 |
| check_zombie_procs        | check_procs            | Vérifie le nombre de processus qui ont l'état 'zombie'                                    |

### Commandes spécifiques omreport
Le plugin omreport permet de vérifier l'état matériel des serveurs Dell. Toutes les commandes omxxx sont définies côté serveur sous la forme "check_nrpe_omxxx".

| Commande                  | Option            | Description                                                                                   |
| --------------------------|-------------------|-----------------------------------------------------------------------------------------------|
| check_ombatteries         | --only batteries  | Vérifie l'état de la batterie                                                                 |
| check_omcpu               | --only cpu        | Vérifie le taux d'occupation du cpu                                                           |
| check_omfans              | --only fans       | Vérifie l'état des ventilateurs                                                               |
| check_ommemory            | --only memory     | Vérifie la mémoire physique restante sur la machine et l'état physique des modules mémoires   |
| check_ompower             | --only power      | Vérifie la capacité des alimentations électriques                                             |
| check_omtemp              | --only temp       | Vérifie la température du matériel                                                            |
| check_omvoltage           | --only voltage    | Vérifie le voltage                                                                            |

### Commandes spécifiques mysql_health

Toutes ces commandes sont définies côté serveur sous la forme "check_nrpe_mysql_health_mode". Les descriptions sont prises directement de la documentation du plugin check_mysql_health.

| Mode                     | Description                                                                                                        |
|--------------------------|--------------------------------------------------------------------------------------------------------------------|
| bufferpool-hitrate       | InnoDB buffer pool hitrate                                                                                         |
| bufferpool-wait-free     | InnoDB buffer pool waits for clean page available                                                                  |
| connection-time          | Time to connect to the server                                                                                      |
| index-usage              | Usage of indices                                                                                                   |
| keycache-hitrate         | MyISAM key cache hitrate                                                                                           |
| log-waits                | InnoDB log waits because of a too small log buffer                                                                 |
| open-files               | Percent of opened files                                                                                            |
| qcache-hitrate           | Query cache hitrate                                                                                                |
| qcache-lowmem-prunes     | Query cache entries pruned because of low memory                                                                   |
| slave-io-running         | Slave io running: Yes                                                                                              |
| slave-lag                | Seconds behind master                                                                                              |
| slave-sql-running        | Slave sql running: Yes                                                                                             |
| slow-queries             | Slow queries                                                                                                       |
| table-lock-contention    | Table lock contention                                                                                              |
| tablecache-hitrate       | Table cache hitrate                                                                                                |
| threads-connected        | Number of currently open connections                                                                               |
| threadcache-hitrate      | Hit rate of the thread-cache                                                                                       |
| tmp-disk-tables          | Percent of temp tables created on disk                                                                             |
| uptime                   | Time the server is running                                                                                         |

### Commandes spécifiques postgresql

Toutes ces commandes sont définies côté serveur sous la forme "check_nrpe_postgres_action". Les descriptions sont prises directement de la documentation du plugin check_postgres.pl

| Action                     | Description                                                                                                      |
|----------------------------|------------------------------------------------------------------------------------------------------------------|
| archive_ready              | Check the number of WAL files ready in the pg_xlog/archive_status (option inutile pour Centos8)                  |
| autovac_freeze             | Checks how close databases are to autovacuum_freeze_max_age                                                      |
| backends                   | Number of connections, compared to max_connections                                                               |
| connection                 | Simple connection check                                                                                          |
| database_size              | Report if a database is too big                                                                                  |
| disabled_triggers          | Check if any triggers are disabled                                                                               |
| disk_space                 | Checks space of local disks Postgres is using                                                                    |
| fsm_pages                  | Checks percentage of pages used in free space map                                                                |
| fsm_relations              | Checks percentage of relations used in free space map                                                            |
| last_analyze               | Check the maximum time in seconds since any one table has been analyzed                                          |
| last_autoanalyze           | Check the maximum time in seconds since any one table has been autoanalyzed                                      |
| last_autovacuum            | Check the maximum time in seconds since any one table has been autovacuumed                                      |
| last_vacuum                | Check the maximum time in seconds since any one table has been vacuumed                                          |
| listener                   | Checks for specific listeners                                                                                    |
| locks                      | Checks the number of locks                                                                                       |
| logfile                    | Checks that the logfile is being written to correctly                                                            |
| new_version_cp             | Checks if a newer version of check_postgres.pl is available                                                      |
| new_version_pg             | Checks if a newer version of Postgres is available                                                               |
| prepared_txns              | Checks number and age of prepared transactions                                                                   |
| query_time                 | Checks the maximum running time of current queries                                                               |
| same_schema                | Verify that two databases have the exact same tables, columns, etc.                                              |
| sequence                   | Checks remaining calls left in sequences                                                                         |
| settings_checksum          | Check that no settings have changed since the last check                                                         |
| table_size                 | Checks the size of tables only                                                                                   |
| timesync                   | Compare database time to local system time                                                                       |
| txn_idle                   | Checks the maximum "idle in transaction" time                                                                    |
| txn_time                   | Checks the maximum open transaction time                                                                         |
| txn_wraparound             | See how close databases are getting to transaction ID wraparound                                                 |
| version                    | Check for proper Postgres version                                                                                |
| wal_files                  | Check the number of WAL files in the pg_xlog directory                                                           |

## Commandes spécifiques server-side only

Les commandes suivantes sont présentes dans les variables nagios-client, mais ne sont pas ajoutables sur de nouveaux hôtes. C'est par exemple le cas de `check_drivesize`. Les vérifications peuvent toutefois être ajoutées côté serveur si la configuration côté client a été faite.

 - check_mysql (mantis)
 - check_mysqldump (mantis)
 - check_kvm (gobniou-lps)
 - check_drivesize (srv-carl)
 - check_memory (srv-carl)
 - check_process (srv-carl)
 - check_uptime (srv-carl)