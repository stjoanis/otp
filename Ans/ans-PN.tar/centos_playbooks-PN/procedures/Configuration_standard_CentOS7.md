Configuration standard - Serveur CIaaS
======================================

## Introduction

Ce document décrit les différentes configurations nécessaires lors de l'installation d'une nouvelle machine de production sous CentOS 7 dans la cible CIaaS.

Ce document explicite notamment la configuration des points suivants :
	- Réseau : IP statique, Gateway, route, DNS ...
	- Nom de la machine
	- Configuration des dépots miroir CS pour YUM
	- NTP : Synchronisation temporelle
	- Puppet : Pour l'installation de la supervision (Nagios) et de la sauvegarde (Bacula)
	- Authentifictaion LDAP
	- Sécurité des accès
	- Gestion des privilèges (sudoers)

## Ansible - CIaaS Bootstrap

Mise à part la configuration réseau, les opérations de configuration décrites dans ce document peuvent être effectuées automatiquement par le module Ansible CIaaS Bootstrap. Pour plus de détails, consulter le dépot Git associé : https://git.bu-dsa.si.c-s.fr/CIaas/ci/src/branch/master/ciaas_bootstrap

## Configuration

Les configurations suivantes sont définies pour CentOS 7. Toutefois, il est possible de les adapter et de les réutiliser pour d'autre système d'exploitation.

La totalité des configurations suivantes necessitent les droits 'root' pour être appliquées.

### Réseau

Tout d'abord il est necessaire de configurer le réseau afin de rendre la machine accessible via SSH et pour lui permettre d'atteindre les autres serveurs tel que le dépot de paquets.

Pour ce faire, il faut éditer le fichier `/etc/sysconfig/network-scripts/ifcfg-eth0` comme suit en remplaçant 'XX' par la valeur adéquate :
```
TYPE=Ethernet
BOOTPROTO=none
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=no
IPV6_AUTOCONF=no
IPV6_DEFROUTE=no
IPV6_PEERDNS=no
IPV6_PEERROUTES=no
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=eth0
DEVICE=eth0
ONBOOT=yes
DNS1=192.168.25.232
DNS2=192.168.25.127
DOMAIN=si.c-s.fr
ZONE=public
IPADDR=172.25.54.XX
PREFIX=26
GATEWAY=172.25.54.1
```
Note : L'interface WAN est supposé être `eth0`. Si l'interface WAN se nomme autrement, il faut éditer le fichier `ifcfg-<nom de l'interface>`

Redémarrer ensuite le service réseau, pour appliquer les modifications :
```bash
systemctl restart network
```

Tester ensuite la connectivité en tentant de ping un serveur du réseau CS :
```bash
ping <server>.bu-dsa.si.c-s.fr
```

### Nom de la Machine

Le nom de la machine doit être défini dans le fichier `/etc/hostname`. Editer le fichier et remplacer son contenu par la ligne suivante :
```
<server-name>.bu-dsa.si.c-s.fr
```
Où <server-name> doit être remplacé par le nom de la machine, par exemple Gareth.

Le nom de la machine sera pris en compte lors du prochain rédémarrage de la machine.

### Dépots Miroir CS

Il existe un serveur interne à CS qui fait office de miroir de paquets pour les principales distributions linux. Puisque ce serveur est sur le réseau interne de CS, il est bien plus rapide d'y télécharger les paquets d'autant qu'il n'y a pas besoin de passer par le proxy pour y accèder. De ce fait, il est fortement recommandé d'utiliser le miroir CS (miroir.si.c-s.fr) pour l'installation de paquet par YUM.

Il faut donc configurer les dépots YUM pour pointer sur le miroir CS. Pour ce faire, sauvegarder les fichiers `.repo` du dossier `/etc/yum.repos.d`:
```bash
cd /etc/yum.repos.d
mkdir backup
mv *.repo backup/
```

Puis ajouter le fichier `/etc/yum.repos.d/miroir-CS.repo` avec le contenue suivant :
```
[base]
name=CentOS-$releasever - Base
baseurl=http://miroir.si.c-s.fr/centos/$releasever/os/x86_64/
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-$releasever
enabled=1

[update]
name=CentOS-$releasever - Updates
baseurl=http://miroir.si.c-s.fr/centos/$releasever/updates/x86_64/
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-$releasever
enabled=1

[epel]
name=Epel
baseurl=http://miroir.si.c-s.fr/epel/$releasever/x86_64/
gpgcheck=0
enabled=1

[ius]
name=IUS
baseurl=http://miroir.si.c-s.fr/misc/ius/stable/CentOS/$releasever/$basearch/
gpgcheck=1
enabled=1
gpgkey=http://miroir.si.c-s.fr/misc/ius/IUS-COMMUNITY-GPG-KEY

[extras]
name=epel $releasever $basearch
baseurl=http://miroir.si.c-s.fr/centos/$releasever/extras/$basearch/
enabled=0
gpgcheck=1
```

Enfin, mettre à jour les dépots afin de resynchroniser YUM avec les nouveaux dépots :
```bash
yum update
```
Les paquets installer avec YUM seront à présent récupérés sur le miroir CS.

### NTP

Il est souhaitable que le serveur soit toujours à l'heure afin que les actions et les logs soit correctement datée. Il faut donc installer et configurer le serveur NTP de la machine.

Pour installer NTP, utiliser la commande suivante :
```bash
yum install ntp
```

Editer ensuite le fichier `/etc/ntp.conf` pour commenter les serveurs par défaut et y ajouter la ligne suivante :
```
# Use public servers from the pool.ntp.org project.
# Please consider joining the pool (http://www.pool.ntp.org/join.html).

#server 0.centos.pool.ntp.org iburst
#server 1.centos.pool.ntp.org iburst
#server 2.centos.pool.ntp.org iburst
#server 3.centos.pool.ntp.org iburst

server jupiter1.si.c-s.fr iburst
```

Stopper et désactiver le service Chronyd avant de lancer et d'activer au démarrage le service NTP :
```bash
systemctl stop chronyd
systemctl disable chronyd

systemctl start ntpd
systemctl enable ntpd
```

La synchronisation du temps avec le serveur NTP CS peut prendre plusieurs minutes. Pour vérifier le status de l'horloge système, utiliser la commande suivante :
```bash
ntpq -p
```

### Nagios

Une machine en production doit être supervisé afin de s'assurer de son bon fonctionnement.

L'équipe Infra utilise pour cela un serveur Nagios qui collecte, à travers l'agent NRPE, des données sur l'état de la machine et remonte des alertes auprès d'une interface centralisé, ainsi que sur Mattermost.

L'agent NRPE est déployé via Puppet par l'équipe Infra. Toutefois, il est necessaire d'ouvrir le port `5666`  de la machine afin de permettre à NRPE et à Nagios de communiquer. Pour ouvrir le port '5666', on utilise l'outil `firewall-cmd` :
```bash
firewall-cmd --permanent --add-port=5666/tcp
```

L'installation et la configuration du module NRPE sont à la charge de l'équipe Infra via l'outil Puppet.

### Bacula

Les données d'un serveur en production doivent être sauvegardées régulièrement afin de limiter la perte de données.

L'équipe Infra utilise l'outil Bacula pour effectuer des sauvegardes quatidienne des données importantes. Bacula éxécute toutes les nuits un script bash de sauvegarde présent sur la machine. Ce script crée une archive de toutes les données importante, puis Bacula récupère cette archive et la sauvegarde sur les serveurs de l'équipe Infra.

Bacula est installé et configuré par l'équipe Infra, via Puppet. Cependant, il est necessaire d'ouvrir le port `9102`  de la machine afin de permettre à Bacula de s'y connecter. Pour ouvrir le port '9102', on utilise l'outil `firewall-cmd` :
```bash
firewall-cmd --permanent --add-port=9102/tcp
```

Par ailleurs, le script de sauvegarde utilisé par Bacula doit être installé et configuré sur la machine. Ce script se trouve dans le dépot Git 'CIaaS/Backup' dans le dossier `backup.d`. Récupérer le script adéquate et le placé dans `/usr/local/backup.d/` avec les permissions adaptées :
```bash
cp ciaas_bck_gitea.sh /usr/local/backup.d/ciaas_bck_<service>.sh
chown root:root /usr/local/backup.d/ciaas_bck_<service>.sh
chmod 644 /usr/local/backup.d/ciaas_bck_<service>.sh
```

Avant la mise en production de la machine, il est important d'essayer la sauvegarde via Bacula, afin de s'assurer de son bon fonctionnement.

### Identification LDAP

Afin d'avoir un meilleur suivi des actions effectuées sur le serveur, il faut configurer l'accès SSH via les comptes LDAP. Pour ce faire, installer le paquet suivant :
```bash
yum install nss-pam-ldapd
```

Puis adapter les fichiers de configuration `/etc/nslcd.conf`, `/etc/nsswitch.conf`, `/etc/pam.d/password-auth` et `/etc/pam.d/system-auth` comme suit :
```
#/etc/nslcd.conf

uri ldap://ldap.bu-dsa.si.c-s.fr
base ou=People,ou=DSA,o=CS
base   group  ou=Groups,ou=Local,o=CS
base   passwd ou=People,ou=DSA,o=CS
base   shadow ou=People,ou=DSA,o=CS
filter passwd (objectClass=person)
filter group (objectClass=groupOfNames)
map passwd uid uid
map passwd uidNumber employeenumber
map passwd gidNumber "1000"
map passwd gecos "${gecos:-$cn}"
map passwd homeDirectory "/home/$uid"
map passwd loginShell "/bin/bash"
```
```
#/etc/nsswitch.conf

passwd:     files sss ldap
shadow:     files sss ldap
group:      files sss ldap
#initgroups: files sss

hosts:      files dns myhostname

bootparams: nisplus [NOTFOUND=return] files

ethers:     files
netmasks:   files
networks:   files
protocols:  files
rpc:        files
services:   files sss

netgroup:   nisplus sss ldap

publickey:  nisplus

automount:  files nisplus sss ldap
aliases:    files nisplus

```
```
#/etc/pam.d/password-auth et /etc/pam.d/system-auth

#%PAM-1.0
# This file is auto-generated.
# User changes will be destroyed the next time authconfig is run.
auth        required      pam_env.so
auth        required      pam_faildelay.so delay=2000000
auth        sufficient    pam_unix.so nullok try_first_pass
auth        sufficient    pam_ldap.so
auth        requisite     pam_succeed_if.so uid >= 1000 quiet_success
auth        required      pam_deny.so

account     required      pam_unix.so
account     sufficient    pam_localuser.so
account     sufficient    pam_succeed_if.so uid < 1000 quiet
account     required      pam_permit.so

password    requisite     pam_pwquality.so try_first_pass local_users_only retry=3 authtok_type=
password    sufficient    pam_unix.so sha512 shadow nullok try_first_pass use_authtok


password    required      pam_deny.so

session     optional      pam_keyinit.so revoke
session     required      pam_mkhomedir.so skel=/etc/skel/ umask=0022
session     required      pam_limits.so
-session     optional      pam_systemd.so
session     [success=1 default=ignore] pam_succeed_if.so service in crond quiet use_uid
session     required      pam_unix.so
```

Redémarrer le service nslcd et l'activer au démarrage :
```bash
systemctl restart nslcd
systemctl enable nscld
```

Suite à cela, les utilisateurs du LDAP CS peuvent se connecter sur à la machine. Pour en faire des administrateurs, il suffit d'ajouter l'utilisateur concerné au groupe `wheel` comme exposé ci-dessous.

## Sécurité

Les machines en production sont particulièrement sensibles puisqu'elles participent à la productivité des équipes et qu'elles sont exposées sur le réseau. De ce fait, il est primordiale de sécuriser les serveurs en production, en limitant notamment les accès SSH à la machine et en appliquant le principe de moindre privilège.

De ce fait, les comptes par défaut 'root' et 'admin' doivent être durcis et les droits root ne doivent être fournit qu'aux administrateurs. Par précaution, il est préférable de limiter l'accès SSH au serveur qu'aux utilisateurs explicitement autorisés.

Les configurations suivantes visent à sécuriser la machine en réduisant la surface d'attaque possible.

### Comptes root et admin

Une fois la machine installé, il est impératif de désactiver le compte root (`/sbin/nologin` pour root dans `/etc/passwd`) et de changer le mot de passe du compte admin (exécuter `passwd admin` sur la VM).

Le compte root doit aussi être interdit de se connecter via SSH : `PermitRooLogin=no` dans le fichier `/etc/ssh/sshd.conf`. Redémarrer le service sshd pour prendre en compte la modification.
```bash
systemctl restart sshd
```

### Administrateurs

Les administrateurs de la machine doivent être ajoutés dans le groupe 'wheel' afin de devenir sudoer.

Pour ce faire, éditer le fichier `/etc/group` et ajouter la liste des utilisateurs administrateurs séparés par une virgule. Par exemple :
```
wheel:x:10:admin,ldevigne,vquemene,dclavier,esaint-j,scabrimo
```

La prise en compte est immédiate et ne necessite aucune action supplémentaire. Pour retirer les droits root à un utilisateur, il faut retirer son nom de la liste précédente.

### Restriction des accès

Afin de limiter les accès SSH au serveur, définir les utilisateurs autorisés à se connecter dans le fichier `/etc/ssh/sshd_config`. Il suffit de lister les utilisateurs autorisés dans le paramètres `AllowUsers`, comme suit :
```
AllowUsers ldevigne vquemene dclavier esaint-j scabrimo admin
```

Redémarrer le service sshd pour prendre en compte la modification.
```bash
systemctl restart sshd
```

A présent seul les utilisateurs listés dans le fichier `/etc/ssh/sshd_config` peuvent se connecter en SSH à la machine.

### Certificat CIaaS

Il est souhaitable d'ajouter le certificat TLS de l'équipe CIaaS dans le trustore de la machine afin d'éviter les erreurs de communication en HTTPS entre les différents service de CIaaS.

Pour ce faire, récupérer le certificat CIaaS depuis le portail de l'équipe, puis l'ajouter aux fichiers `/etc/pki/tls/certs/ca-bundle.trust.crt` et `/etc/pki/tls/certs/ca-bundle.crt` :
```bash
cd /home/admin
curl -k  https://ci.bu-dsa.si.c-s.fr/acr.pem --output acr.pem
cat /home/admin/acr.pem /etc/pki/tls/certs/ca-bundle.trust.crt
cat /home/admin/acr.pem /etc/pki/tls/certs/ca-bundle.crt
```

Le certificat est pris en compte immédiatement.

### SELinux

SELinux est un outil de sécurité très puissant, activé par défaut sur CentOS 7. Malheuresement il est particulièrement compliqué à prendre en main et à utiliser. Par défaut, il est assez restrictif et peut être la cause de plusieurs erreurs sur la machine.

Dans la mesure du possible, il est conseillé de laisser SELinux activer. Toutefois, dans certains cas il peut être necessaire de le désactiver. Pour cela, utiliser la commande suivante :
```bash
setenforce 0
```

La commande précédente n'est pas persistente, de ce fait SELinux se réactivera au prochain redémarrage de la machine. Pour désactiver SELinux de manière persistente, éfiter le fichier `/etc/selinux/config` et adapter la ligne suivante :
```
SELINUX=disabled
```

SELinux sera ainsi désactivé au prochain redémarrage de la machine.

## Auteurs et Contributeurs
Ce document a été rédigé par Denis CLAVIER
