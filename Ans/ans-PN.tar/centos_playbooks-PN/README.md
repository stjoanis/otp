Playbook bootstrap pour les serveurs CIaaS
==========================================

## Préliminaires

Avant d'exécuter le playbook de bootstrap, il est nécessaire que les actions suivantes soit réalisées.

### Mise à jour de l'inventaire

* Ajouter l'hôte concerné à l'inventaire en complétant le fichier `hosts.ini`. Ne pas oublier de le renseigner dans les groupes auxquels il appartient.

* Créer et compléter le fichier `host_vars` associé à l'hôte concerné. Les variables attendues sont décrites dans le fichier [Details.md](https://git.bu-dsa.si.c-s.fr/CIaaS/infra/src/branch/master/ansible/Details.md)

* Pousser les changements sur Gerrit, puis les accepter et les merger sur Git.

Pour ajouter l'hôte comme client Nagios:

* ajouter le client au groupe `[nagios-client]` dans l'inventaire ansible. Le client sera alors ajouté dans la liste des clients du serveur nagios à la prochaine exécution de la tâche `hosts.yaml`

* définir les checks souhaités dans les variables de l'hôte ansible. Par défaut, huit commandes (`check_conntrack`, `check_cpu`, `check_disk`, `check_ping`, `check_load`, `check_ntp_time`, `check_ram` et `check_swap`) sont installées. Toute autre commande doit être spécifiée dans les variables de l'hôte. La liste complète des commandes se trouve dans `nagios-client.yaml`. Une description plus précise des plugins et commandes est disponible dans le document [plugins-Nagios.md](procedures/nagios/plugins-Nagios.md).

Pour ajouter l'hôte comme client Bacula :

* ajouter le client au groupe `[bacula-client]` dans l'inventaire ansible. Le client sera alors ajouté dans la liste des clients du serveur bacula à la prochaine exécution de la tâche `clients.yaml`.

* définir les paramètres de sauvegarde souhaitées pour l'hôte. Par défaut, bacula crée une tâche de sauvegarde et une tâche de restauration pour chaque hôte. La sauvegarde par défaut copie les fichiers présents dans `/etc` en suivant le planning `weekly`. Ces paramètres de sauvegarde ainsi que les paramètres pour des sauvegardes spécifiques ou des sauvegardes dynamiques doivent être précisés dans les variables de l'hôte ansible.

### Préparation de l'hôte

* Rendre l'hôte concerné accessible par le réseau. Pour ce faire, le serveur doit être raccordé au réseau BU-DSA et son interface réseau doit être configurée. De même, les serveurs DNS doivent être configurés.

**Note**: Il est préférable d'effectuer la configuration de l'interface réseau depuis le menu prévu à cet effet dans l'installateur de CentOS. Pour plus d'informations, consulter [la documentation](https://docs.centos.org/en-US/centos/install-guide/NetworkSpoke-x86/)

* S'assurer que le serveur SSH de l'hôte concerné est démarré et injecter la clé SSH d'administration CIaaS (cf : Keepass) dans les clés acceptées par l'utilisateur `admin`.

```bash
ssh-copy-id -i <path/to/public_key> admin@'<ip>'
```

* Le compte `admin` doit avoir les droits 'sudo' et le mot de passe du compte `admin` doit correspondre à la valeur de la variable `ansible_become_pass`.

## Exécution du bootstrap

Une fois les étapes préliminaires effectuées, le playbook de bootstrap peut être lancé depuis AWX.

Pour ce faire, se connecter à AWX et lancer le modèle `CentOS Bootstrap CIaaS` dans le menu `Modèles`. Dans le champ `limite`, préciser l'hôte concerné par le déploiement puis renseigner le mot de passe du compte de bind LDAP, avant d'exécuter le modèle.

**Si un client Nagios a été ajouté**, il faut ajouter l'hôte `nagios` dans le champ limite et s'assurer que la tâche `nagios-host` du rôle `nagios-server` soit exécutée.

**Si un client Bacula a été ajouté**, il faut ajouter l'hôte `bacula` dans le champ limite et s'assurer que la tâche `bacula-client` du rôle `bacula-server` soit exécutée.

Le playbook prend environs 10 minutes pour exécuter toutes les tâches. La plus longue tâche étant la mise à jour des paquets via YUM/DNF.

Toutes les actions doivent être "OK" ou "Changed" à la fin du script afin de garantir que le serveur considéré a bien été bootstrapé.

## Post-installation

### Changement du mot de passe admin

Une fois le playbook déployé sans erreur, il est nécessaire de modifier le mot de passe du compte `admin`. Ce dernier doit être sauvegardé dans une entrée du Keepass CIaaS.

Pour générer un mot de passe pour le compte `admin`, utiliser la commande suivante :

```bash
openssl rand -base64 12
```

Puis, en se connectant en SSH au serveur concerné, depuis le compte root, changer le mot de passe du compte `admin` avec :

```bash
ssh <uid>@<server>
sudo -s
passwd admin
```

Enfin, vérifier la bonne prise en compte du mot de passe, en se connectant au compte `admin` depuis un compte utilisateur.

```bash
su - admin
```

## Résumé de la procédure d'ajout d'un client Nagios

![](deploiement_nagios.png)

## Procédure détaillée

La procédure détaillée d'utilisation de ce module est exposée dans le document [Details.md](Details.md). S'y référer pour plus d'informations sur le module de bootstrap.

Une documentation plus complète du module Nagios est présente dans le dossier [procedures](procedures/nagios/).
