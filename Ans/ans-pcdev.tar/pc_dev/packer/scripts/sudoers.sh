#!/bin/env bash

echo "admin   ALL=(ALL)   NOPASSWD: ALL" >> /etc/sudoers.d/vagrant
chmod 0440 /etc/sudoers.d/vagrant
