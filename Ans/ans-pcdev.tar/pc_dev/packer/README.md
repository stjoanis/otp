# Packer

Ce document décrit comment installer et utiliser [Packer](https://www.packer.io) pour générer une image `qcow2` et une `box` [Vagrant](https://www.vagrantup.com/) à partir d'une image `ISO` Fedora et du `Kickstart` des PCs de dev.


## Installation

Configurer le dépôt Copr Hashicorp :
```
$ sudo dnf copr enable boeroboy/hashicorp
```

Note : À l'avenir, on pourra utiliser [le dépôt officiel](https://www.hashicorp.com/blog/announcing-the-hashicorp-linux-repository/) à la place :

```
$ sudo dnf config-manager --add-repo https://rpm.releases.hashicorp.com/fedora/hashicorp.repo
```

Installer le paquet :
```
$ sudo dnf -y install packer
```


## Préparation

Modifier le type de disque dans le Kickstart :
```
sed -i 's/=nvme0n1/=vda/g' kickstart/pcdev.ks
```


## Génération

**Se positionner dans le sous-répertoire `packer`.**

Pour lancer la génération à partir de l'image ISO par défaut (une netinstall Fedora 32) :
```
$ packer build config.json
```

Pour lancer la génération à partir d'une image ISO particulière (le checksum est optionnel et son format est détecté automatiquement) :
```
$ packer build -var 'url=http://miroir.si.c-s.fr/fedora/linux/releases/32/Everything/x86_64/iso/Fedora-Everything-netinst-x86_64-32-1.6.iso' -var 'checksum=7ce4bb4b3e77e2b0c74e5aa3478eef1c26104a7040701f9de3d3a2cb06f6b05d' config.json
```

On obtient en sortie 2 fichiers dans le sous-répertoire `output` :
- `pcdev.qcow2` ;
- `pcdev.box`.


## Débogage

Pour activer les messages de debug de `Packer` , positionner la variable `PACKER_LOG` à 1. Exemple :
```
$ PACKER_LOG=1 packer build config.json
```


## GUI

Pour afficher l'interface graphique de la VM pendant le build, changer la valeur de l'option `headless` à `false` dans la section `builders` du fichier `config.json`

```json
"builders": [
    {
        [...]
        "headless": false,
        [...]
    }
],
```
