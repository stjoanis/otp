# Introduction
## Objet du document

Ce document constitue le dossier d’architecture de la mise en place des postes de développement pour les équipes de développement de la BU D&S. Il a pour finalité de décrire et de détailler les différentes caractéristiques fonctionnelles et techniques de cette mise en place.

Il précise en particulier :

* l’architecture fonctionnelle
* l’architecture technique de production
* le déploiement
* l’administration

## Rappel des objectifs

A la date de création de ce document, les équipes de développement possèdent un poste DSI avec Windows Seven et VirtualBox. VirtualBox permet aux développeurs d'avoir des machines virtuelles de type Linux, et ces machines constituent leur principal outil de travail.
Or Windows Seven est en fin de vie, et VirtualBox ne sera plus installé avec la migration vers Windows 10. En effet, l'utilisation des "Guest add-ons" d'Oracle / VirtualBox est désormais soumise à licence payante en contexte entreprise.

L'objectif est donc de proposer aux équipes de développement un environnement alternatif, et qui soit proche des systèmes cibles sur lesquels ils travaillent. La mise à disposition des outils Microsoft (notamment la suite MS-office) est proposée via l'accès distant (rdesktop) à un serveur Terminal Windows (TSE : Terminal Server Edition).

La composition de l'environnement proposé est la suivante :

* un système GNU/Linux natif sur le poste (sans double boot);
* une suite d'outils usuels pré-installés et configurés (environnement de bureau, navigateur web, etc);
* une suite d'outils propres aux développeurs;
* l'accès à un serveur Terminal Windows, en rdesktop;
* la conservation de l'accès aux services CS : csnet, imprimante, annuaire, etc;
* une gestion de sauvegarde des postes;
* une gestion des mises à jour.


## Documents de référence

| Réf  | Libellés                                    |
|------|---------------------------------------------|
| DR01 | SI SCCOA - Dossier d'intégration oVirt.docx |
Table: Documents de références

## Terminologie

### Définitions

| Terme                        | Définition |
|------------------------------|------------|
| Ansible                      | Plate-forme logicielle libre pour la configuration et la gestion des ordinateurs. Elle combine le déploiement de logiciels multi-nœuds, l'exécution des tâches ad-hoc, et la gestion de configuration. Elle gère les différents nœuds à travers SSH et ne nécessite l'installation d'aucun logiciel supplémentaire sur ceux-ci. |
| Ansible Tower (AWX)          | API, service Web et console Web conçue pour rendre Ansible plus facilement utilisable par les équipes informatiques. C'est une console centrale de gestion des tâches d'automatisation. AWX est la version Open-Source. |
| Bastion central              | Machine qui héberge notamment AWX. |
| Kickstart                    | Outil d'automatisation de l'installation et configuration du poste de développement. |
| Poste de développement (PCD) | Poste physique fourni par la DSI, PC portable ou fixe, et dédié à un utilisateur identifié. |
| rdesktop                     | Logiciel client libre pour le service RDP. Il permet d'accéder à un environnement applicatif Windows à partir du poste de développement. |
Table: Définitions

### Sigles et acronymes

| Acronyme | Signification               |
|----------|-----------------------------|
| AWX      | Ansible WorX                |
| CIFS     | Common Internet File System |
| NFS      | Network File System         |
| PCD      | PC de Développement         |
| TSE      | Terminal Server Edition     |
Table: Sigles et acronymes


<div style="page-break-after: always"></div>
# Présentation de l'architecture

## Architecture fonctionnelle

### Schéma d'architecture fonctionnelle

* Voici l'architecture fonctionnelle avec l'écosystème du PCD :

![Architecture fonctionnelle](img/sch_fonctionnel.png)

### Description de l'architecture fonctionnelle

Les postes de développement (PCD) sont déployés depuis un bastion central via AWX.

* Le PCD doit avoir accès aux services suivants :
  - Annuaire LDAP
  - Impression
  - Machine virtuelle Windows 10 déportée
  - Services CIaaS, espaces projets
  - Internet
  - Accès au VPN CS
  - CSNet ainsi que les services CS : répertoires partagés, forge, etc

* Le bastion central possède les rôles suivants :
  - héberge un clone du dépôt git comprenant la documentation, kickstart, et playbooks Ansible pour faire le déploiement des PCD,
  - accès au PCD, en SSH avec le compte `admin`,
  - administration des PCD à distance : déploiement de mises à jour, évolutions, etc
  - le tout au travers d'un interface web avec **AWX**, la version Open-Source d’Ansible Tower (outil d’orchestration de playbooks Ansible, fournissant de la ségrégation de rôles, de la centralisation de logs et du REST API).

Le service Windows 10 déporté est hébergé sur une VM serveur TSE.
**Remarque :** Non mis en place à date du 20/10/2020, en discussion avec la DSI.

## Architecture Technique

### Schéma

TODO

### Flux applicatifs

| Vers \ De | PCD        | Bastion   |
|-----------|------------|-----------|
| LDAP      | TCP (389)  | TCP (389) |
| RDP       | TCP (3389) | NA        |
| SSH       | TCP (22)   | TCP (22)  |
Table: Flux applicatifs

### Postes de développement

Le poste de développement est proposé sur la base d'un système d'exploitation Fedora Workstation. A ce système est ajouté plusieurs logiciels communément utilisés par les développeurs : outils de développement, d'analyse, navigateur, etc.

* Voici la liste des outils préinstallés sur le poste (exemple pour Fedora 31) :

| Produit             | Description |
|---------------------|-------------|
| Fedora              | Système d'exploitation |
| Gnome               | Environnement de bureau |
| Atom                | Éditeur de texte |
| Audacity            | Édition audio |
| Draw.io             | Équivalent de Visio |
| Eclipse             | Environnement de développement logiciel |
| Haveged             | Générateur d'entropie |
| K9S                 | Client Kubernetes |
| Kubectl             | Client Kubernetes |
| LibreOffice         | Suite bureautique |
| Libvirt             | Bibliothèque, API, daemon, et outils de gestion de la virtualisation |
| Meld                | Visual diff and merge tool targeted at developers |
| Mozilla Firefox     | Navigateur web |
| Mozilla Thunderbird | Client mails |
| Podman (Docker)     | Conteneurisation |
| QT Creator          | Environnement de développement orienté C++ |
| Rdesktop            | Outil de connexion de bureau à distance (Windows) |
| Screen              | Multiplexeur de terminaux |
| Tixeo client        | Clien pour l'outil de visioconférence Tixeo |
| Wireshark           | Analyseur de paquets |
Table: Liste outils PCD

* En particulier pour Gnome, les extensions et paquets suivants sont installés :

| Produit              | Type      | Description                   |
|----------------------|-----------|-------------------------------|
| ArcMenu              | Extension | Équivalent du start menu sous Windows |
| Dash-to-panel        | Extension | Dock proche de celui de Windows |
| Ding (Desktop Icons) | Extension | Icônes sur le bureau |
| Gnome Tweaks         | Paquet    | Outil permettant de personnaliser Gnome |
| Tray Icons Reloaded  | Extension | Équivalent du systray sous Windows |
Table: Liste extensions Gnome

### Serveur Windows déporté

L'accès à un environnement Windows 10 est proposé au travers d'une connexion distante rdesktop (RDP).

L'utilisateur s'y connecte avec son identifiant CSNet, les logiciels suivants doivent être proposés :

* Microsoft Office :
  - Bureautique
  - Visio (fonction de l'utilisateur, les licences étant décomptées par utilisateur)
  - Project (fonction de l'utilisateur, les licences étant décomptées par utilisateur)
* Reqtify

**Remarque :** Non mis en place à date du 11/09/2020

### Réseau

Le PCD obtient son adresse IP via le protocole DHCP

Le nom d'hôte "**hostname**" est basé sur le numéro du poste tel que fournit par la DSI, ce numéro doit être repris (ex : PO11333), ou à défaut le numéro de série si le PC est projet.

### Services communs utilisés

Les postes de développement doivent pouvoir accéder aux services suivants :

* répertoires partagés CS
* espaces projets, services CIaaS
* impression
* annuaire
* synchronisation temps (chrony)
* Internet
* miroir de dépôts
* mails (Thunderbird + Lightning)
* VPN : GlobalProtect ou OpenConnect

### Sécurisation des postes

* L'accès au BIOS de la machine doit être protégé par un mot de passe (géré par la DSI).

* Le compte "**admin**" de la machine doit être protégé par un mot de passe fort, sauvegardé dans un Keepass.

* L'accès direct en local aux comptes "**root**" des postes doit être désactivé.

* L'accès à distance (SSH) du compte root doit être interdit.

* Seuls les utilisateurs du groupe "**wheel**" doivent pouvoir obtenir des droits d'administration, l'utilisateur du PCD doit faire partie de ce groupe.

* L'utilisateur doit utiliser des mots de passe forts, ils sont dictés par la politique mise en place sur l'annuaire, soit :
  - minimum 8 caractères
  - 1 minuscule, 1 majuscule, 1 caractère spécial, 1 chiffre

* Les utilisateurs suivants doivent être ajoutés aux sudoers :
  - **root**
  - **admin**, pour accès aux administrateurs, depuis les postes d'administration
  - l'utilisateur à qui est dédié le poste (via son **uid** issu de l'annuaire BU-DSA)

* Le poste est connecté à l'annuaire LDAP de la BU-DSA afin de permettre l'authentification des utilisateurs sur le poste de développement. Le cache des credentials est géré par le service **sssd**, ainsi, si le poste est déconnecté du réseau, ou si l'annuaire est indisponible, l'utilisateur pourra continuer d'utiliser le poste en hors-ligne.

### Politique de sauvegarde et de restauration

* Seuls le répertoire utilisateur `/home/$USER`, et le répertoire `/data` pourront être sauvegardés en cas de demande de restauration complète du système.

* Si une réinstallation était nécessaire, la procédure est la suivante :
  - sauvegarde des répertoires `/home/$USER` et `/data`,
  - redescente du kickstart et redéploiement de la configuration (via Ansible),
  - restauration des répertoires `/home/$USER` et `/data`.
  ==> La restauration des configurations supplémentaires de l'utilisateur sont à la charge de l'utilisateur.

### Politique de mise à jour du poste

* Le système d'exploitation est basé sur Fedora Workstation, tous les six mois une nouvelle version sort, et celle-ci est maintenue treize mois.

* Les paquets pourront ainsi être mis à jour au fil de l'eau pendant toute la durée de vie de la version en cours. Une mise à jour plus conséquente sera faite lors de la sortie d'une nouvelle version.


<div style="page-break-after: always"></div>
# Déploiement

## Déploiement Kickstart

* Les outils de déploiements sont hébergés sur le dépôt GIT **ciaas/pc_dev** :
```
git clone "ssh://<username>@gerrit.bu-dsa.si.c-s.fr:29418/ciaas/pc_dev"
```

* L'outil d'installation des PCD est "**Kickstart**", il s'agit d'un outil d'automatisation d'installation pour les systèmes Linux de type RedHat. Les paramètres d'installation sont décrits dans un fichier Kickstart.

* L'outil Kickstart permet de générer l'iso qui contient le système d'exploitation avec sa configuration de base :
  - locales (clavier, langue, zone de temps)
  - partitionnement
  - utilisateurs root et admin
  - activation accès SSH

* L'outil de personnalisation et de configuration du PCD est "**Ansible**", il permet d'écrire et d'exécuter des tâches de configuration et d'administration. Ces tâches sont décrites dans un fichier YAML, appelé "playbook" Ansible. Le serveur Ansible est hébergé sur le bastion central.

* Les playbooks configurent la machine et installent les éléments spécifiques au PCD :
  - dépots et paquets de base
  - connexion à l'annuaire
  - configuration de l'impression
  - durcissements : compte root, compte d'administration, accès SSH
  - configuration de l'environnement de bureau
  - etc.

* Le déploiement est fait au moyen d'un clé USB bootable.

## Etapes du déploiement

* Voici concrètement comment s'articule le déploiement :

![Schéma de déploiement](img/sch_deploiement.png)

* Etape **(1)** : Un iso de Fedora, et un fichier kickstart sont déposés sur une clé USB bootable grâce à l'outil "Ventoy". La clé USB sert de support de déploiement du système d'exploitation sur le PCD.
* Etape **(2)** : Fedora est déployé sur le PCD en natif ou en double boot.
* Etape **(3)** : Une fois le système installé, la partie personnalisation et configuration du poste est déployée au travers de playbooks Ansible depuis AWX (outil d'orchestration de playbooks Ansible).

## BIOS

Un mot de passe BIOS doit être mis en place. La procédure exacte dépend de la carte mère de la machine, version, année, etc. La configuration du mot de passe doit être faite manuellement sur chaque machine.

## Partitionnement

* Le partitionnement des PCD est le suivant :

| Point de montage | Type | Taille                   |
|------------------|------|--------------------------|
| /boot/efi        | ext4 | 500Mo                    |
| /boot            | ext4 | 500Mo                    |
| swap             | NA   | 8Go                      |
| / (root)         | ext4 | 100Go                    |
| /home            | ext4 | > 300Go (place restante) |
| /data            | ext4 | 100Go                    |
Table: Partitionnement

## Paramétrages logiciels

* Un paramétrage générique minimum est fait au travers des playbooks Ansible pour les outils de base (Firefox, Thunderbird, Mattermost, etc). La personnalisation est à la charge des utilisateurs.
