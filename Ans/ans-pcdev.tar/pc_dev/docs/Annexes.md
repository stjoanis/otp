# Annexes

## Latitude 5420, résolution port Ethernet inactif

### Exposé du problème

Sur les DELL Latitude 5420, le module e1000e qui gère le port Ethernet ne charge pas correctement.
Le message d'erreur au lancement du PC est le suivant :

```
$ dmesg | grep e1000e
[2.725621] e1000e: Intel(R) PRO/1000 Network Driver
[2.725626] e1000e: Copyright(c) 1999 - 2015 Intel Corporation.
[2.726210] e1000e 0000:00:1f.6: Interrupt Throttling Rate (ints/sec) set to dynamic conservative mode
[2.858209] e1000e 0000:00:1f.6: The NVM Checksum Is Not Valid
[2.892210] e1000e: probe of 0000:00:1f.6 failed with error -5
```

D'après le site de Dell : Ethernet specifications, model numbers :

- Intel I219-LM
- Intel I219-V

Source:
[Caractéristiques Dell Latitude 5420](https://www.dell.com/support/manuals/fr-fr/latitude-5420-laptop/5420_sp14_setupspecs/communications?guid=guid-1e7f729c-4721-4c06-ac00-b80838f296c5&lang=fr-fr)

Plus spécifiquement, la commande suivante permet de voir que l'interface Ethernet existe,
qu'il s'agit du modèle `I219-LM`, et qu'elle à l'état `UNCLAIMED` :

```
lshw -c network
  *-network:1 UNCLAIMED
       description: Ethernet controller
       product: Ethernet Connection (13) I219-LM
       vendor: Intel Corporation
       physical id: 1f.6
       bus info: pci@0000:00:1f.6
       version: 20
       width: 32 bits
       clock: 33MHz
       capabilities: pm msi bus_master cap_list
       configuration: latency=0
       resources: memory:a2300000-a231ffff
```

### Résolution

Les derniers drivers d'Intel (v3.8.4) ne compilent pas avec les kernels récents.
Il faut donc récupérer ceux disponibles sur sourceforge (v3.8.7) ici :
https://sourceforge.net/projects/e1000/files/e1000e%20historic%20archive/

* Après récupération de l'archive `e1000e-3.8.7.tar.gz`, décompresser :

```
tar -zxvf e1000e-3.8.7.tar.gz
```

* Editer le fichier `e1000e-3.8.7/e1000e.spec`, et à la ligne `Requires:`, remplacer `fileutils` par `coreutils`

* Editer le fichier `e1000e-3.8.7/src/net.c` et,

  - dans le bloc de Checksum NVM suivant,

  ```
    for (i = 0;; i++) {
        if (e1000_validate_nvm_checksum(&adapter->hw) >= 0)
            break;
        if (i == 2) {
            dev_err(pci_dev_to_dev(pdev),
                "The NVM Checksum Is Not Valid\n");
            err = -EIO;
            goto err_eeprom;
        }
    }
  ```

  - modifier la première ligne comme suit :

  ```
    for (i = 0; false; i++) {
  ```

* Reconstruire l'archive :

```
tar -zcvf e1000e-3.8.7.tar.gz e1000e-3.8.7/
```

* Générer un rpm à partir de la nouvelle archive :

```
rpmbuild -tb e1000e-3.8.7.tar.gz
```

**NB :**
En pré-requis du rpm-bluid, il faudra installer les paquets suivants : `rpmdevtools yum-utils kernel-devel`, puis redémarrer la machine.
Par défaut, le rpm sera généré à cet emplacement : `/root/rpmbuild/RPMS/x86_64/e1000e-3.8.7.x86_64.rpm`

* Installer :

```
dnf install e1000e-3.8.7.x86_64.rpm
```

* Désinstaller / réinstaller le module kernel

```
rmmod e1000e
modprobe e1000e
dracut -v -f
```

Brancher un cable réseau directement sur l'interface Ethernet du PC, la connexion devrait s'établir sur l'interface ayant pour nom `enp0s31f6`.
