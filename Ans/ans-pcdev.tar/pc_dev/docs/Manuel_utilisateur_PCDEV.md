# Présentation

Ce document a pour objectif de présenter le PC de développement au nouvel utilisateur.

Il précise en particulier :

* la charte d'utilisation
* le système d'authentification en place
* les outils mis à disposition
* les rôles de l'équipe DevOps et de la DSI/PAC

# Charte d'utilisation

La charte d'utilisation des PC de développement vient en complément de la charte d'utilisation du système d'information de CS GROUP.

**Charte CS GROUP**, aller sur :

* My.CSGROUP.eu > DOCUMENTS > RESSOURCES HUMAINES > Règlement intérieur et Annexes
* **Annexe au règlement intérieur relative à l'utilisation du système d'information de CS SI**

**Charte PCDEV**, l'utilisateur s'engage à respecter la politique de sécurité mise en place sur le poste, à savoir :

* l'ouverture d'une session sur la machine est conditionnée à une authentification LDAP qui ne doit pas être contournée par l'utilisation d'un compte local ;
* le compte **root** est désactivé de manière à empêcher toute ouverture de session graphique ou SSH. Il demeure toutefois accessible au moyen de la commande `sudo` ;
* le compte **admin** est utilisé par l'équipe DevOps pour les opérations d'administration et ne doit pas être modifié ;
* SELinux doit être activé au minimum en mode `permissive` ;
* le serveur SSH doit rester démarré (`active (running)`) ;
* les montées de version majeure de la distribution sont assurées par l'équipe DevOps, ainsi que les mises à jour de sécurité. L'utilisateur est libre d'installer ou non les mises à jour correctives (se reporter au chapitre [Mises à jour](#mises-a-jour) de la documentation d'utilisation des PC de développement).

Enfin, il est demandé de **ne pas personnaliser le matériel avec des autocollants** (exigence DSI/PAC).

# Système d'authentification

L'authentification au PCDEV s’appuie sur l'annuaire LDAP de la BU Défense, lui-même synchronisé avec l'annuaire CS GROUP.

Il existe néanmoins un utilisateur local **admin** dédié aux opérations de maintenance par l'équipe DevOps. Comme indiqué dans la charte, cet utilisateur ne doit pas être modifié.

L'utilisateur peut passer **root** sur son poste, pour ce faire exécuter :

```
sudo -s
```

Les services suivants utilisent le mot de passe du domaine Windows :

* impression
* accès au serveur Windows DVI
* montage des répertoires du domaine (Projets, Echange...)

Les autres services utilisent le même mot de passe que pour l'accès CSNet.

![pcdev_authentification](img/pcdev_authentification.png)

## Authentification sur le domaine Windows

### Changer le mot de passe

Le mot de passe du domaine Windows peut être changé de deux manières :

* soit en passant par le lien https://domainpassword.idsi0.si.c-s.fr/
* soit en ligne de commande :

```
$ smbpasswd -r idsi0.si.c-s.fr -U <username>
Old SMB password:
New SMB password:
Retype new SMB password:
Password changed for user <username>
```

### Utilisation avec l'impression

Ce mot de passe est utilisé pour l'impression, et peut être enregistré par l'utilisateur pour ne pas avoir à le renseigner à chaque impression.
**Cependant, il est dans ce cas enregistré en clair**, ce mode est déconseillé et n'est donc pas configuré par défaut sur un PCDEV.

Néanmoins, voici la procédure si l'utilisateur souhaite le faire :

* passer **root** :

```
sudo -s
```

* stopper le service cups :

```
systemctl stop cups
```

* éditer le fichier `/etc/cups/printers.conf`
* changer la ligne `DeviceURI ***` comme suit, en adaptant le `LOGIN` et `PASSWORD` par celui du domaine Windows :

```
DeviceURI smb://LOGIN:PASSWORD@idsi0.si.c-s.fr/vm-natuna.idsi0.si.c-s.fr/MFP-PLESSIS
```

* Redémarrer le service cups :

```
systemctl start cups
```

### Montage des répertoires du domaine Windows

Un script `cs_mount.sh` (situé dans `/usr/local/bin`) permet d'initier le montage des répertoires du domaine Windows situés sur le serveur bali, et qui est géré par la DSI.

Il concerne le montage des répertoires suivants :

* `//vm-bali2.idsi0.si.c-s.fr/EchangeCS` : espace d'échange entre utilisateurs CS GROUP, purgé 1 fois par semaine le WE
* `//vm-bali2.idsi0.si.c-s.fr/projets$` : espace des répertoires projets
* `//vm-bali2.idsi0.si.c-s.fr/Services$` : espace des services CS GROUP
* `//vm-bali2.idsi0.si.c-s.fr/<username>` : espace propre à l'utilisateur

Il peut être exécuté via la commande `cs_mount.sh` sous le nom de l'utilisateur, il est entièrement guidé en mode fenêtré.

Le mot de passe demandé est celui du domaine Windows, il est **enregistré en clair** dans `/home/$USER/.cifs-credentials`, en mode "_read,write_" pour l'utilisateur (`0600`).

**Remarque :** Il n'est pas recommandé d'enregistrer ce mot de passe, mais l'utilisateur devrait alors utiliser des droits **root** pour monter les répertoires et pouvoir y lire, écrire, modifier les fichiers.

Ce mot de passe peut être mis à jour via le script `cs_mount.sh`, ou bien manuellement :

* ouvrir le fichier `/home/$USER/.cifs-credentials`,
* éditer la ligne `password=` et mettre à jour le mot de passe

## Authentification sur le PCDEV

Comme indiqué plus haut, l'authentification est branchée sur l'annuaire CS GROUP.

Le mot de passe de connexion au PCDEV se change donc directement depuis la fiche CSNet de l'utilisateur.

# Connexion au VPN

Des informations plus détaillées sur la configuration et les différentes méthodes de connexion au VPN sont disponibles sur le Wiki :
https://git.bu-dsa.si.c-s.fr/CIaaS/tools/wiki/Wiki-PCDEV#vpn-cs

L'utilisateur devra avoir préalablement fait une demande d'accès VPN auprès du PAC (Point d’Accueil Clients) :
https://my.csgroup.eu/index.php/fr/services/help-desk.html

Le serveur VPN est pré-configuré, voici la procédure pour s'y connecter :

* dans le systray (en bas à droite, à côté de l'horloge), cliquer l'icône du réseau
* aller sur **VPN désactivé**, puis sur **Se connecter**
* cliquer sur **Connect**
* au message d'alerte sur le certificat, déplier _▶ I really know what I am doing_
* cliquer sur **Connect anyway**
* renseigner le `Username` et `Password`, puis cliquer sur **Login**
* choisir une **GATEWAY** puis recliquer sur **Connect**

* **Remarque :**
Si une erreur "512" apparaît au login malgré des identifiants corrects, le plus simple est de réinitialiser le mot de passe :
  - se connecter sur CSNet
  - aller dans **Annuaire** > **Ma fiche**
  - cliquer sur le lien **RAZ Password VPN**

Le mot de passe sera alors réinitialisé avec le mot de passe CSNet de l'utilisateur.

# Outils mis à disposition

## Mattermost

Mattermost est un logiciel open source de communication collaborative.
Il constitue une interface unifiée de messagerie entre les utilisateurs et les applications, et permet à ce titre la mise en place d'un workflow "ChatOps".

### Le canal PCDEV

Le canal **PCDEV** est dans la section **BU-DSA** de Mattermost, il permet d'obtenir du support pour toute question concernant les PCDEV.

Il sert aussi à diffuser les annonces de l'équipe DevOps sur ces PCs, par exemple :

* annonce du déploiement d'une mise à jour
* annonce de la campagne de mise à niveau du système (passage à la version supérieure de Fedora)

### Ajouter un serveur

Par défaut, seul le serveur de la BU Défense est configuré, il est possible d'en ajouter d'autres.

* Aller dans "File" > "Sign in to Another Server" :
  + Server Display Name : Mon tchat
  + Server URL : https://catwoman.domain.fr
  + cliquer sur `Add` pour valider

## Firefox

Le navigateur Firefox est configuré pour se lancer sur un profil personnalisé.

Sous ce profil, sont pré-configurés :

* le proxy CS GROUP
* le lancement avec page d'accueil de CSNet et de l'équipe DevOps
* des marques pages en "Barre personnelle"

Les marques pages regroupés dans **CS** concernent tous les services CS GROUP :

* CSNet
* My.CSGROUP
* Odin : renseignement des jours de télétravail)
* Décisif : pour les différents types de demandes et expressions de besoin
* un Wiki DevOps avec réponses aux questions fréquemment posées sur les PCDev
* etc.

Le marque page **DevOps** amène à la page d'accueil de l'équipe DevOps avec la liste des différents services proposés.

## Thunderbird

Le client mail Thunderbird est entièrement pré-configuré.
Seul le mot de passe utilisateur est à renseigner à la première utilisation.

## Gerrit

Gerrit est une application Web open source de revue de code pour le travail en équipe.

Il faut générer une paire de clés SSH pour pouvoir y envoyer ses commits sans avoir besoin de se ré-authentifier à chaque fois :

* Générer la paire de clé SSH en ECDSA :

```
ssh-keygen -t ecdsa
```

* ouvrir le fichier contenant la clé publique `~/.ssh/id_ecdsa.pub` et copier toute la ligne
* se connecter à Gerrit :
https://gerrit.bu-dsa.si.c-s.fr/
* aller dans **Settings** (l'engrenage en haut à droite)
* puis cliquer sur **SSH Keys**
* coller la ligne précédemment copiée dans le champ **New SSH key**
* valider en cliquant sur **ADD NEW SSH KEY**

La clé est alors ajoutée.

Vérifier que la connexion fonctionne :

```
ssh ${USER}@gerrit.bu-dsa.si.c-s.fr -p 29418

  ****    Welcome to Gerrit Code Review    ****

  Hi <USER>, you have successfully connected over SSH.
```

## Windows VDI avec Remmina

Certains utilisateurs peuvent disposer d'un accès à un Windows distant virtualisé, dit Windows VDI :

* lancer le logiciel **Remmina**
* double cliquer sur **Windows-VDI**

Le mot de passe à renseigner est celui du domaine Windows.

L'utilisateur dispose alors :

* d'un espace de 20Go
* de la suite bureautique Microsoft Office 2010
* de Reqtify 2016
* et des outils habituels fournis sur un PC bureautique standard (Tortoise SVN, Reqtify,..)

## Tixeo

Tixeo est un outil de visio proposé chez CS GROUP.

Ce logiciel ne fonctionne que si la dernière version est installée, il faut donc le maintenir à jour manuellement :

```
dnf update tixeo
```

## Autres

D'autres outils sont aussi proposés par défaut sur le PC :

* **Atom :** IDE OpenSource, implémente Git Control et est aussi utilisé en tant qu’environnement de développement
* **Draw.io :** application de création de diagrammes, équivalent de Microsoft Visio
* **Podman :** moteur de conteneur développé par RedHat, équivalent à Docker
* **Toolbox :** surcouche de Podman pour simplifier le développement
* **Rabbitvcs :** frontal graphique pour les systèmes de contrôle de version disponibles sur Linux. Équivalent de TortoiseSVN

# Mises à jour

## Update du système

L'utilisateur est libre d'installer ou non les mises à jour correctives.

Pour effectuer les mises à jours correctives, exécuter :

```
dnf update
```

Les mises à jour de sécurité sont automatiquement déployées par le système par l'outil "dnf-automatic".
Une fois par jour ce dernier vérifie si une mise à jour de sécurité est disponible, et la déploit le cas échéant.

## Upgrade du système

Les montées de version majeure de la distribution sont assurées par l'équipe DevOps.
Lors de la sortie d'une nouvelle version majeure du système, celle-ci est d'abord testée par l'équipe DevOps.

L'utilisateur sera prévenu lors d'une montée de version. L'opération pourra nécessiter d'immobiliser le PC pendant 2h, d'où une planification nécessaire.

# Rôles DevOps et DSI/PAC

![pcdev_roles](img/pcdev_roles.png)

## Rôle de l'équipe DSI/PAC

La DSI gère la partie matérielle du PC.

Les demandes d'accès suivants sont aussi du ressort de la DSI :

* autorisation d'accès au VPN
* autorisation d'accès aux répertoires du domaine Windows (notamment les répertoires projets sur le **serveur bali**)
* autorisation d'accès aux services CS GROUP

**Remarque importante :**
Pour assurer le suivi des entrées et sorties du parc de PCDEV, il est important de prévenir l'équipe DevOps si un collaborateur devait rendre son PC au stock.

## Rôle de l'équipe DevOps

Le DevOps gère la partie système et logiciel du PC, à savoir :

* la dernière version de Fedora déployée
* les logiciels / outils proposés par défaut sur le PC :
  + Gnome
  + Mattermost
  + connexion au VPN
  + Firefox, Thunderbird
  + podman
  + etc.

Le support aux outils installés en supplément par l'utilisateur sont à sa charge, bien qu'il soit parfois possible d'en obtenir du support par les utilisateurs PCDEV qui en ont la connaissance.

Liens vers le support :

* le canal **PCDEV** de mattermost est un moyen privilégié pour l'entraide entre utilisateurs
* pour les autres services proposés par l'équipe DevOps, envoyer un mail à : <devops@csgroup.eu>.
