# Vagrant

Ce document décrit comment installer et configurer [Vagrant](https://www.vagrantup.com/) pour tester le playbook `Ansible` de bootstrap des PC de dev sur une `box` générée par [Packer](https://www.packer.io).


## Installation

Installer le paquet :

```
$ sudo dnf -y install vagrant
```

Installer [le plugin `libvirt`](https://github.com/vagrant-libvirt/vagrant-libvirt) :
```
$ vagrant plugin install vagrant-libvirt
```

Si nécessaire, démarrer `libvirtd` :
```
$ sudo systemctl start libvirtd
```


## Utilisation

**Se positionner dans le sous-répertoire `vagrant`.**

Importer la `box` générée par Packer :
```
$ vagrant box add --name pcdev ../packer/output/pcdev.box
```
*Note* : Si une ancienne version de la `box` avait déjà été importée auparavant, se reporter à la section [Nettoyage](#nettoyage).

Vérifier que la `box` a bien été importée :
```
$ vagrant box list
```

Instancier une VM à partir de la `box` :
```
$ vagrant up --no-provision
```

Vérifier que la VM est bien démarrée :
```
$ vagrant status
```

Vérifier que la VM est bien accessible en SSH :
```
$ vagrant ssh
```

Quitter la connexion SSH, puis démarrer le provisioning Ansible :
```
$ vagrant provision
```

Une fois les tests terminés, détruire la VM :
```
$ vagrant destroy
```


## Nettoyage

Lors de l'instanciation d'une VM, le plugin `libvirt` crée une image `qcow2` pour cette VM, plus une autre image `qcow2` pour la `box` si elle n'existe pas déjà :
```
$ virsh vol-list --pool default
 Name                            Path
----------------------------------------------------------------------------------------------------------
 pcdev_vagrant_box_image_0.img   /home/user/.local/share/libvirt/images/pcdev_vagrant_box_image_0.img          <=== image de la box
 vagrant_test.img                /home/user/.local/share/libvirt/images/vagrant_test.img                       <=== image de la VM
```

Lorsqu'une VM est détruite (`vagrant destroy`), son image est automatiquement supprimée, mais pas celle de la `box`.

Pour supprimer la `box` (dans le but de faire de la place ou pour en importer une nouvelle version) et nettoyer son image :
```
$ vagrant box remove pcdev
$ virsh vol-delete --pool default pcdev_vagrant_box_image_0.img
```


## Débogage

Pour activer les messages de debug de `Vagrant` , positionner la variable `VAGRANT_LOG`. Exemple :
```
$ VAGRANT_LOG=debug vagrant up
```

Pour activer les messages de debug d'`Ansible`, éditer le fichier `Vagrantfile`, et ajouter un élément `-vvv` au tableau `ansible.raw_arguments`. Exemple :
```ruby
ansible.raw_arguments = ["--inventory", "../ansible/inventory.ini", "-vvv"]
```


## GUI

Pour afficher l'interface graphique de la VM, le plus simple est d'utiliser un client VNC (Par exemple `Gnome Boxes` ou `TigerVNC Viewer` sous Fedora).

L'ip du serveur est `127.0.0.1`, et le port est le `5900`.

Il est également possible de choisir un autre protocole d'affichage en modifiant la valeur de l'option `graphics_type` dans le [`Vagrantfile`](Vagrantfile). Se reporter à [la documentation du plugin `libvirt`](https://github.com/vagrant-libvirt/vagrant-libvirt#domain-specific-options) pour plus d'informations.
