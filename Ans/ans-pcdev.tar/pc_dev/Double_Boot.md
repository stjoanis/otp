Installation en double boot
===========================

Cas de l'installation de Fedora en double boot avec Windows 10 sur un PC fixe de la DSI.

## Pré-requis

* Clé USB Ventoy avec :
  - System Rescue CD (pour l'outil GParted)
  - Fedora-Everything-netinst-x86_64
* PC fixe avec disque de 1000To, ou PC portable

## Préparation du disque dur

* Brancher la clé USB "ventoy"

* Démarrer la machine et appuyer sur la touche **F12** pour entrer dans le boot mode

* Démarrer en UEFI BOOT, sur la clé `UEFI: XXX`

* Choisir l'iso de System Rescue CD

* Une fois sur System Rescue CD :
  - passer en clavier fr : `loadkeys fr`
  - exécuter `startx` pour accéder au desktop
  - lancer GParted

* Redimensionner la plus grande partition (théoriquement : `/dev/sda4`) pour qu'elle fasse environ 150GiB (159 481 MiB) :
  - clic droit > Resize/Move
  - réduire la partition, "Free space following (MiB)" doit être > 550 000
  - appliquer

* Déplacer la dernière partition (/dev/sda5, avec pour Label "Recovery") à la suite de /dev/sda4
  - clic droit > Resize/Move
  - déplacer au tout début, "Free space preceding" doit être à 0
  - Resize/Move > OK
  - appliquer

* A la fin, une partition "unallocated" de plus de 200GiB doit suivre la partition `/dev/sda5`

## Cas double boot avec Windows 10

Sur les PCs portables installés en Windows 10 par la DSI, et comportant un disque SSD, le démarrage sur Windows 10 ne peut se faire qu'en mode SATA "RAID On".
Or Fedora ne peut démarrer qu'en mode SATA "AHCI".
Il faut donc passer les drivers Windows 10 en AHCI afin éviter d'avoir à switcher entre les deux modes pour démarrer soit sur Fedora, soit sur Windows.

Il faudra aussi passer par la DSI pour exécuter les commandes en mode administrateur (Malika).

Procédure à suivre :
* Démarrer sur Windows 10
* Lancer une invite de commande en tant qu'Administrateur
* Exécuter la commande suivante : `bcdedit /set safeboot minimal` pour passer le démarrage en mode sans échec
* Redémarrer le PC, et entrer sur le setup BIOS (touche F2 au tout début du démarrage), puis :
  - aller `Settings` > `System Configuration` > `SATA Operation`
  - changer le mode SATA de `RAID On` vers `AHCI`
  - appliquer, sortir du BIOS
* Démarrer sur Windows en mode sans échec
* Lancer de nouveau une invite de commande en tant qu'Administrateur
* Exécuter la commande suivante : `bcdedit /deletevalue safeboot` pour repasser le démarrage de Windows en mode normal
* Redémarrer à nouveau le PC, Windows 10 sera automatiquement passé sur les drivers AHCI.

## Installation de Fedora

* **/!\ NE PAS BRANCHER LE CABLE RESEAU TOUT DE SUITE /!\**
  Sinon, l'installeur va bloquer sur l'écran du choix de la langue d'installation

* Redémarrer sur la clé USB Ventoy et choisir l'iso `Fedora-Everything-netinst-x86_64`

* NE PAS charger le fichier pcdev.ks, mais choisir la méthode manuelle

* Choisir la langue d'installation, **puis seulement après**, brancher le cable réseau

* Configurer les **Sources d'installation** :
  - Sur le réseau : http://, Type d'URL : URL du dépôt
  - Dépôts supplémentaires :
    - updates : http//, Type d'URL : URL du dépôt
    - fedora-modular :
    - fedora-modular-updates

* Clavier : Français / Support langue : Français (France)

* Heure & Date :
  - cliquer sur le bouton des paramètres (roues dentées)
  - entrer le nom du serveur NTP CS GROUP : `jupiter1.si.c-s.fr`
  - cliquer sur le bouton **+** pour l'ajouter

* Sélection Logiciel :
  - environnement de base : Fedora Workstation
  - module complémentaires pour l'environnement sélectionné : LibreOffice

* Mot de passe administrateur : Le compte root est désactivé

* Création Utilisateur :
  - mot de passe : admin / admin
  - cocher `Faire de cet utilisateur un administrateur`
  - cliquer 2 fois sur **Fait** pour valider

* Nom du réseau & d'hôte :
  - nom d'hôte : `<PO|PC><barcode>.IDSI0.si.c-s.fr`, indiquer PO pour PC Portable, PC pour PC Fixe. Exemple : PO12456
  - appliquer

* Au partitionnement :
  - sélectionner le disque dur
  - cocher "Personnalisé" puis sur **Fait**
  - cliquer sur `Cliquez ici pour les créer automatiquement`. Ainsi, l'installeur reprendra automatiquement `/dev/sda1` pour `/boot/efi` (celui du Windows).

* Reprendre ensuite ce partitionnement automatique comme suit :
  - attribuer 50Gio pour `/`
  - attribuer 512Mio pour `/boot`
  - supprimer `/home` du partitionnement automatique, puis
  - créer `/data` en LVM avec 200Gio (100Gio pour un hdd de PC portable)
  - recrééer `/home` avec le reste de l'espace disponible (ne rien mettre à la capacité souhaitée, l'installateur prendra automatiquement tout l'espace restant)
  - cliquer sur **Fait**

* Cliquer sur le bouton **Commencer l'installation**

* Redémarrer sur Fedora une fois l'installation terminée, puis :
  - à **Confidentialité**, désactiver la géolocalisation et l'envoi de rapports
  - passer la connexion aux comptes en ligne
  - cliquer sur **Commencer à utiliser Fedora**

* La suite de l'installation se passe via les playbooks Ansible.
