# XDG_RUNTIME_DIR initialisation

export XDG_RUNTIME_DIR=/run/user/$(id -u)
