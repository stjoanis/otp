#!/bin/bash
#
# Script qui communique à AWX les informations suivantes à propos du PCDEV :
# * adresse IP
# * username
# * hostname
# * devops release
# * date de dernière remontée de ces informations
#
#===============================================================================

awxserver="https://awx.bu-dsa.si.c-s.fr"
ipbastion="172.25.54.21"

# Vérification permission exécution
[[ "$(id -u)" -ne "0" ]] && echo "Erreur : Ce script doit être lancé par root. Sortie." && exit 1

# Source apitoken
[[ ! -f ~/.token ]] && echo "Erreur : Pas de fichier token. Sortie." && exit 1
. /root/.token

# Source des variables du fichier devops-release
[[ ! -f /etc/devops-release ]] && echo "Erreur : Fichier /etc/devops-release absent. Sortie" && exit 1
. /etc/devops-release

# Vérification présence des variables du fichier devops-release
[[ -z ${cs_username} ]] && echo "Erreur : cs_username vide. Sortie." && exit 1
[[ -z ${cs_hostname} ]] && echo "Erreur : cs_hostname vide. Sortie." && exit 1
[[ -z ${devops_release} ]] && echo "Erreur : devops_release vide. Sortie." && exit 1

cs_hostname=$(echo "${cs_hostname}" | tr '[:upper:]' '[:lower:]')
awx_host_api=${awxserver}/api/v2/hosts/${cs_hostname}++pc_dev_inventory++ciaas_org

# Test connexion API AWX
res=$(curl -k -L -H "Authorization: Bearer ${apitoken}" -s -o /dev/null -I -w "%{http_code}" "${awx_host_api}"/)
[[ ${res} -ne "200" ]] && echo "Erreur : API ${awx_host_api}/  non joignable. Sortie." && exit 1

# Calcul myip + test code retour commande
myip=$(ip -o route get ${ipbastion} | awk -F "src" '{print $2}' | awk '{print $1}') ; rc=$?
[[ ${rc} -ne "0" ]] && echo "Echec commande 'ip -o route get ${ipbastion}'. Sortie." && exit 1

# Test format adresse IP
! ipcalc -cs "${myip}" && echo "Erreur : ${myip} format IP invalide. Sortie." && exit 1


# Ajout ansible_host et devops_release à la structure variable_data
#-------------------------------------------------------------------------------
## Passage par une variable jsondata intermédiaire (nécessaire pour la commande jq qui suit)
jsondata=$(curl -k -L -s -H "Authorization: Bearer ${apitoken}" -H "Content-Type: application/json" -X GET "${awx_host_api}/variable_data/" | jq -c --arg myip "${myip}" --arg devops_release "${devops_release}" '. + {ansible_host: $myip} + {devops_release: $devops_release}')

## Envoi du dictionnaire json_data mis à jour
res=$(curl -k -L -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer ${apitoken}" -H "Content-Type: application/json" -X PUT -d "${jsondata}" "${awx_host_api}/variable_data/")

## Contrôle résultat
if [[ ${res} -ne "200" ]] ; then
    echo "Erreur : Echec API POST ${myip} vers ${awx_host_api}/variable_data/ Sortie."
    exit 1
else
    echo "@IP ${cs_hostname} = ${myip}"
    echo "DevOps Release = ${devops_release}"
fi


# Envoi cs_username, date, et devops_release dans le champ description
#-------------------------------------------------------------------------------
## Calcul de la date
datenow=$(TZ="Europe/Paris" date +"%Y-%m-%d %H:%M")

## Variable jsondata intermédiaire
jsondata="{\"description\": \"${cs_username} | ${datenow} | ${devops_release}\"}"

## Envoi du dictionnaire json_data mis à jour
res=$(curl -k -L -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer ${apitoken}" -H "Content-Type: application/json" -X PATCH -d "${jsondata}" "${awx_host_api}/")

## Contrôle résultat
if [[ ${res} -ne "200" ]] ; then
    echo "Erreur : Echec API POST description ${cs_username} vers ${awx_host_api}/ Sortie."
    exit 1
else
    echo "Assignation description = ${cs_username}"
fi
