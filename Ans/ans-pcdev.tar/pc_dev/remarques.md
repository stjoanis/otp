## Remarques

Le reboot après la configuration de l'utilisateur est il necessaire ?

## Fait:

* Suppression des références inutiles vers Nexus
  - Pointe directement sur les archives/rpm sur internet (liens en paramètres)

* Remplacement du module `package` par le module `dnf`

* Création automatique de la home utilisateur
    - via `mkhomedir_helper {{ username }}`

* Réorganistaion en role
    - Création des roles `postinstall` et `upgrade`

* Suppression des multi-occurence de `become` => Factorisation

* Ajout de la configuration NTP/Chrony
    - Désactivation du RTC
    - Pointe sur Jupiter1

* Suppression de la tache `gnome_admin`
    - Inutile de configurer gnome pour admin (compte ssh principalement et CIaaS n'est pas windows friendly)

* Fusion des documentation (README) pour une documentation à la racine du dépot.

* Adaptation des playbooks pour AWX

* Changement du mot de passe admin automatisé

## A Faire:

* Ranger le module Ansible en roles :
    - security -> Certifs + SeLinux + disable root + limit ssh ...
    - apps -> Draw.io + Atom + Kubectl  + Mattermost
    - container -> Podman + kubectl + helm + buildah ...

* Documenter la solution avec AWX

* Faire un prototype VM pour tester la postinstall from scratch
    - Sauvegarde du qcow2 post kickstart pour itérer (pour du debug/mise au point)
    - Proto physique pour beta tester la chain complète (lors de release candidate)

* Nettoyer le code mort/inutilisé
    - Code commenté dans les taches Thunderbird et Firefox

* Faire pointer les dépots Fedora, Updates, Modular et Modular-Updates sur le Miroir
    - Ajouter la directive `proxy=_none_` pour ces dépots

* Intégration VPN dans Network-Manager => Split tunneling
    - A remplacer par un script suid qui utilise `openconnect`

* Intégrer les applications tiers (Atom, Mattermost, Draw.io, K9s ...) dans DNF pour simplifier les MAJ
    - Dépot custom pour Atom et Draw.io
    - A packager pour Mattermost K9s ...

* Modification du mot de passe par défaut pour CUPS `<votre mot de passe Windows>`

* Autre :
    - Partition Data appartient à root => à modifier pour l'utilisateur
    - Ajouter Helm dans les applications
