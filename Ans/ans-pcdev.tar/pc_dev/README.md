Installation des PC de Développement Fedora
===========================================

## Introduction

Ce document décrit l'installation des postes de développement pour les équipes CSoIP.

## Architecture/Sommaire

Le dépôt `ciaas/pc_dev` contient :
* un Kickstart pour l'installation automatisée du système d'exploitation
* un module Ansible pour la configuration du système, et incluant plusieurs roles :
  - configuration : pour la configuration après installation ou migration du système
  - upgrade : pour la migration du système vers une nouvelle version
  - update : pour les updates sur la durée de vie d'une version
* la partie documentaire : DAT, installation, et cas du double boot.

Les documents :
* [README](README.md) : Document d'installation des PCs de Développement
* [Double Boot](Double_Boot.md) : Procédure d'installation en double Boot avec Windows
* [un Wiki](https://git.bu-dsa.si.c-s.fr/CIaaS/tools/wiki/Wiki-PCDEV) : FAQ pour les utilisateurs
* [Annexe](https://git.bu-dsa.si.c-s.fr/CIaaS/tools/wiki/PC-Dev---Proc%C3%A9dures-manuelles) : Procédures manuelles pour la migration des utilisateurs Windows vers Fedora
* [Documentation](docs/) : Rassemble les documents d'architecture


## Rôles Ansible, et lien avec les modèles AWX

Ce chapitre explique les liens entre les rôles Ansible, et les modèles présents dans AWX.

Pour la partie utilisation / exploitation technique, voir les chapitres suivants :
* [Installation d'un PC de Développement](#installation-dun-pc-de-développement)
* [Mises à jour de la version courante](#mises-à-jour-de-la-version-courante)
* [Mise à niveau vers une nouvelle version de Fedora](#mise-à-niveau-vers-une-nouvelle-version-de-fedora)

### Schéma liens rôles Ansible et modèles AWX

[Cycle de vie PCDev](docs/img/ansible-awx_links.png)

### Rôle configuration

Sauf constat d'un bug bloquant à la post-installation d'un nouveau poste, ce rôle n'est modifié qu'à l'arrivée d'une nouvelle version majeure de Fedora, c'est à dire lors d'une migration. Il est lié aux modèles suivants dans AWX :
* **pcdev_post-install**
* **pcdev_post-upgrade**

* Suite à l'installation d'un poste PC Dev, **pcdev_post-install** est lancé via AWX

* Suite à une migration de Fedora (voir flèches rouges du schéma précédent) :
  - les tâches Ansible qui étaient inclues dans le rôle **update** sont mergées dans les tâches liées au rôle **configuration**,
  - la version de l'update (`update_version` dans `groups_vars/pcdev.yaml`) est réinitialisée à **0**,
  - enfin, l'extract des tâches mises à jour suite au merge est joué via AWX avec le modèle **pcdev_post-upgrade**

### Rôle update

Ce rôle vie uniquement le temps d'une version de Fedora. Il sert de delta pour les mises à jour à effectuer entre deux migrations de Fedora, c'est à dire entre deux versions majeures de Fedora **CIaaS release**. Il est lié au modèle **pcdev_update** dans AWX.

* A chaque nouvel update, la version **CIaaS release** doit être incrémentée :
  - Editer `ansible/groups_vars/pcdev.yaml` et incrémenter la valeur de `update_version`, exemple :
  ```
  update_version: "1"  -->  update_version: "2"
  ```
  - Au lancement d'une tâche d'update, ceci aura pour effet de monter la version de **ciaas_release** sur le PC Dev, c'est à dire dans le fichier `/etc/ciaas_release` :
  ```
  ciaas_release=F33_20.11-1  -->  ciaas_release=F33_20.11-2
  ```

* Pour chaque nouvelle migration vers une nouvelle version majeure de Fedora :
  - les tâches du rôle **update** sont mergées dans celles du rôle **configuration**,
  - elles sont ensuite effacées du rôle **update** (sauf la tâche **CIaaS release update informations** qui reste persistante),
  - enfin, la valeur de `update_version` est réinitialisée à `0`, et le rôle repart sur un nouveau cycle.

Les tâches d'update doivent être idempotentes pour pouvoir être jouées plusieurs fois.

### Rôle upgrade

Ce rôle sert à lancer la migration du système Fedora vers une nouvelle version majeure, par exemple Fedora 32 vers Fedora 33. Il est lié au modèle **pcdev_upgrade** dans AWX.

Lors du lancement du modèle **pcdev_upgrade**, seul le système d'exploitation est mis à jour vers une version supérieure de Fedora. Le modèle AWX **pcdev_post-upgrade**, qui suit une migration, fait appel à un extract des tâches du rôle **configuration**.


## Installation d'un PC de Développement

L'installation se fait par clé USB. Cette clé USB va contenir les ISOs permettant de faire l'installation du PCD en natif, et en double boot.

### Préparation de la clé USB d'installation

* Télécharger l'ISO **netinst** de Fedora :
  - disponible sur le [miroir CS GROUP](http://miroir.si.c-s.fr/)
  - via le chemin suivant :
  `/fedora/linux/releases/$releasever/Everything/$basearch/iso/Fedora-Everything-netinst-x86_64-XX-X.X.iso`

* Télécharger Ventoy : https://www.ventoy.net/en/download.html

* Installer Ventoy sur la clé USB en suivant les instructions ici : https://www.ventoy.net/en/doc_start.html

* Copier le contenu du répertoire `kickstart/` du dépôt https://git.bu-dsa.si.c-s.fr/CIaaS/pc_dev, sur la clé Ventoy

Il doit donc y avoir 3 dossiers à la racine de la clé :
* `ISOs/` : pour y déposer les ISOs de Fedora et System Rescue CD, soit :
  - la version **netinst** du Fedora en cours, exple: `Fedora-Everything-netinst-x86_64-34-1.2.iso`
  - la version **amd64** de System Rescue CD (ne sert qu'en cas d'installation en double boot avec Windows), exple: `systemrescue-8.03-amd64.iso`
* `scripts/` : qui contient les fichiers kickstart (avec `<taille_min>`, la taille minimale requise pour l'installation), exemple :
  - pour installation offline sur un SSD : `nvme0n1_<taille_min>_miroircs.ks`
  - pour installation online sur un SSD : `nvme0n1_<taille_min>_online.ks`
  - pour installation offline sur un HDD : `sda_<taille_min>_miroircs.ks`
  - pour installation online sur un HDD : `sda_<taille_min>_online.ks`
* `ventoy/` : qui contient le fichier `ventoy.json`

La clé USB est prête pour l'installation du PCD.

### Installation de Fedora via Kickstart

Pré-requis :
* Le PCD raccordé au réseau CS
* Clé USB d'installation "Ventoy"
* Le mot de passe BIOS sur PC, le cas échéant

#### Réglages BIOS

Procédure pour les DELL LATITUDE en SSD (de 2020-2021).

Au démarrage de la machine, appuyer sur la touche **F2** pour entrer dans le BIOS, puis :
* dans "_General_" > "_Boot Sequence_", pour le "Boot List Option" sélectionner **UEFI**
* dans "_System Configuration_" > "_SATA Operation_", sélectionner **AHCI**
* dans "_System Configuration_" > "_USB Configuration_", **Enable USB Boot Support** doit être coché
* dans "_Secure Boot_" > "_Secure Boot Enable_", **Secure Boot Enable** doit être décoché
* cliquer sur le bouton **Apply**, puis **Exit**

*Note* : pour les modèles DELL Latitude 5420/7420/7520 un problème de CPU Throttling peut apparaitre régulièrement au démarrage de l'ordinateur. Pour le contourner, désactiver le paramètre "_Intel SpeedStep Technology_" dans l'onglet "_Performance_" du BIOS .

#### Installation en natif

Brancher la clé USB "Ventoy", puis :
* Redémarrer la machine et appuyer sur la touche **F12** pour entrer dans le boot mode
* Démarrer en UEFI BOOT, sur la clé `UEFI: XXX`
* Choisir l'iso de Fedora, puis sélectionner le [fichier kickstart](#préparation-de-la-clé-usb-dinstallation) souhaité
* Renseigner le nom de la machine en suivant les instructions du prompt
* Laisser l'installation se dérouler

Une fois l'installation terminée, le poste redémarre, débrancher la clé USB

#### Installation en double boot

Consulter la procédure du [Double Boot](Double_Boot.md)

### Post-Installation

La procédure de post-intallation est effectuée via AWX avec le modèle **pcdev_post-install**. Il est basé sur le rôle Ansible **configuration** (`configuration.yaml`).

#### Ajout de l'hôte dans l'inventaire

* Ajouter le nouvel hôte dans le fichier `ansible/inventory.ini` du dépôt `ciaas/pc_dev`, exemple :
```
po17592    username=bobama      fullname="OBAMA Barack"            usermail="barack.obama"                vdi="no"      dualboot=no      projet=""
```

* Commiter puis pousser la modification :
```
git add ansible/inventory.ini
git commit -m "Ajout hôte po17592"
git push
```

* Dans gerrit, valider la modification (Code Review +2), puis la Submitter.

* S'authentifier sur https://awx.bu-dsa.si.c-s.fr/
  - aller dans "Projets" et à la ligne "pcdev",
  - cliquer sur le bouton de rafraichissement **Obtenir la dernière révision SCM**

* Renseigner manuellement l'IP de la machine,
  - aller dans "Inventaires" > "pcdev_inventory" > cliquer sur "HÔTES"
  - modifier l'hôte pour ajouter la variable suivante `ansible_host: <ip_hote>`
  - cliquer sur "Enregistrer"

#### Déploiement de la clé SSH

* Se connecter sur le bastion Ansible (`bastion.bu-dsa.si.c-s.fr`) en tant qu'utilisateur **admin**

* Récupérer la paire de clés SSH dans le Keepass "CIaaS" (`Projets/CIaaS/CIaaS.kdbx`):
  - aller dans `Base_integration > General > PC_DEV > Clé SSH admin PCDEV`, les clés sont dans `Avancé > Pièces jointes`
  - déployer les clés sur le bastion Ansible dans `/home/admin/.ssh/`

* Depuis le bastion, copier la clé SSH publique vers le nouvel hôte :
```
ssh-copy-id -i /home/admin/.ssh/pcdev-id_rsa.pub admin@<ip_du_pcdev>
```

#### Déploiement de la post-installation

* S'authentifier sur https://awx.bu-dsa.si.c-s.fr/

* Dans "RESSOURCES" > "Modèles", lancer **pcdev_post-install** en cliquant sur le bouton en forme de fusée :
  - dans "LIMITE" entrer le nom de l'hôte (ex: po17592) et faire "SUIVANT"
  - entrer les informations qui peuvent être demandées, à récupérer dans le Keepass CIaaS :
    - le mot de passe de Bind pour le LDAP (pré-renseigné par défaut)
    - le token d'accès AWX pour la synchronisation des IPs (pré-renseigné par défaut)
    - le mot de passe du compte utilisateur admin (pré-renseigné par défaut)
    - faire "SUIVANT"
  - lancer le playbook

#### Configurations manuelles avec l'utilisateur

Certaines configurations ne peuvent être faites qu'avec l'utilisateur final du PC.
Demander à l'utilisateur de s'identifier (login / mot de passe annuaire CSNet).

Ouvrir un terminal, puis :
* Configurer **Firefox** :
  - exécuter Firefox via la commande `firefox --profilemanager`
  - choisir le profil "_ciaas_", puis cliquer sur "Start Firefox"
  - faire un clic droit sur la barre des onglets, et dans "Barre personnelle" cocher "Toujours afficher"
  - refermer Firefox
  - supprimer le fichier de chargement de la configuration : `$ rm -f ~/.mozilla/firefox/<*.ciaas-*>/user.js`
  - Firefox peut maintenant être lancé de manière classique
* Configurer **Thunderbird** :
  - exécuter Thunderbird via la commande `thunderbird --profilemanager`
  - choisir le profil "_ciaas_", puis cliquer sur "Start Thunderbird"
  - refermer Thunderbird
  - supprimer le fichier de chargement de la configuration : `$ rm -f ~/.thunderbird/<*.ciaas-*>/user.js`
  - Thunderbird peut maintenant être lancé de manière classique
* Configurer l'accès aux montages des répertoires Windows du domaine IDSI0 :
  - exécuter la commander `cs_mount.sh`
  - suivre les instructions pour monter les répertoires réseaux
  - le mot de passe du domaine Windows sera alors enregistré dans le fichier `~/.cifs-credentials`
  - vérifier que les répertoires (dans `/home/$USER/Montages_CS/`) montent bien

Vérifier avec l'utilisateur la connexion aux services suivants :
* Mattermost
* mails sous Thunderbird
* VPN
* Windows VDI avec Remmina

Enfin, penser à ajouter l'utilisateur sur le canal **PCDEV** du Mattermost BU-DSA.


## Mises à jour de la version courante

La procédure des mises à jour / update est effectuée via AWX avec le modèle **pcdev_update**. Il est basé sur le rôle Ansible **update** (`update.yaml`).

* A chaque nouvelle mise à jour à déployer via ce rôle, la release CIaaS doit être incrémentée :
  - dans le dépôt Ansible, éditer le fichier `ansible/group_vars/pcdev.yaml`
  - incrémenter la valeur de `update_version`
  - valider la mise à jour dans gerrit (Code Review +2), puis la Submitter.

* Sur AWX, obtenir la mise à jour :
  - aller dans "Projets" et à la ligne "pcdev",
  - cliquer sur le bouton de rafraichissement **Obtenir la dernière révision SCM**

* Toujours sur AWX, dans "RESSOURCES" > "Modèles", lancer **pcdev_update** en cliquant sur le bouton en forme de fusée :
  - entrer les informations qui peuvent être demandées, à récupérer dans le Keepass CIaaS :
    - le mot de passe de Bind pour le LDAP (pré-renseigné par défaut)
    - le token d'accès AWX pour la synchronisation des IPs (pré-renseigné par défaut)
    - le mot de passe du compte utilisateur admin (pré-renseigné par défaut)
    - faire "SUIVANT"
  - lancer le playbook


## Mise à niveau vers une nouvelle version de Fedora

La procédure de mise à niveau / upgrade est effectuée via AWX avec le modèle **pcdev_upgrade**. Il est basé sur le rôle Ansible **upgrade** (`upgrade.yaml`).

Il va d'abord falloir :
* merger les tâches du rôle **update** dans celles du rôle **configuration**;
* créer une nouvelle branche spécifique à l'upgrade dans le dépôt `ciaas/pc_dev`;
* "doubler" temporairement la configuration dans AWX pour faire la validation des modifications apportées par cette branche;
* et enfin, supprimer la configuration temporaire dans AWX une fois que les changements apportés par l'upgrade seront considérés comme valides.

Une fois ces étapes terminées, l'upgrade pourra être déployé sur les PC de développement des utilisateurs.

La procédure complète est décrite ci-après, en prenant pour exemple le passage vers Fedora 33.

### Test de validation de l'upgrade

* Sur le dépôt `ciaas/pc_dev`, créer une nouvelle branche dédiée à l'upgrade :
```
git checkout -b fedora33
```

* Éditer le fichier `ansible/group_vars/pcdev.yaml` du dépôt `ciaas/pc_dev`, et changer les valeurs suivantes :
  - `fedora_version` : par la nouvelle version de Fedora, ex : 33
  - `date_release` : par l'année et le mois en cours, au format AA.MM, ex : 20.11
  - `update_version` : réinitialiser la valeur sur **0**

* Commiter puis pousser la modification avec la nouvelle branche :
```
git add ansible/group_vars/pcdev.yaml
git commit -m "Changement version Fedora vers 33"
git push origin fedora33:refs/heads/fedora33
```

* S'authentifier sur https://awx.bu-dsa.si.c-s.fr/

* Doubler la configuration projet :
  - aller dans "Projets" et faire une copie de "pcdev"
  - éditer cette copie :
    - NOM : pcdev_33
    - BRANCHE SCM/BALISE/VALIDATION : fedora33
  - enregistrer

* Doubler la configuration de l'inventaire :
  - aller dans "Inventaires" et créer "pcdev_33_inventory" :
    - NOM : pcdev_33_inventory
    - ORGANISATION : ciaas_org
    - GROUPES D'INSTANCES : tower
  - enregistrer
  - cliquer sur SOURCES, et ajouter "pcdev_33_source" :
    - NOM: pcdev_33_source
    - SOURCE : Provenance d'un projet
    - PROJET : pcdev_33
    - FICHIER D'INVENTAIRE : ansible/inventory.ini
    - METTRE A JOUR LES OPTIONS : cocher "REMPLACER" et "METTRE A JOUR LORSQUE LE PROJET EST ACTUALISE"
  - enregistrer

* Enfin, doubler les modèles :
  - aller dans "Modèles", et faire une copie de "pcdev_upgrade"
  - éditer cette copie :
    - NOM : pcdev_33_upgrade
    - INVENTAIRE : pcdev_33_inventory
    - PROJET : pcdev_33
  - enregistrer
  - faire ensuite une copie de "pcdev_post-install"
  - éditer cette copie :
    - NOM : pcdev_33_post-install
    - INVENTAIRE : pcdev_33_inventory
    - PROJET : pcdev_33
  - enregistrer

* Retourner dans "Inventaires" pour ajouter l'adresse IP du PC qui servira à la validation de l'upgrade de Fedora :
  - aller dans "pcdev_33_inventory" > HÔTES
  - éditer par exemple "po17592" (PCDEV proto), et après avoir récupéré son IP, ajouter la ligne suivante :
```
ansible_host: 10.25.209.20
```
  - enregistrer

Lancer ensuite d'abord l'upgrade sur le PC qui servira à la validation :
  - aller dans "Modèles"
  - faire démarrer une tâche "pcdev_33_upgrade"
  - dans LIMITE indiquer "po17592"
  - faire SUIVANT > LANCEMENT

* Une fois l'upgrade terminé, valider/vérifier qu'il n'y a pas eu de régression (environnement de bureau, applications, etc)

### Déploiement généralisé de l'upgrade

L'upgrade est considéré comme validé. Il faut alors ramener la branche de l'upgrade (ex: fedora33), dans `master` du dépôt `ciaas/pc_dev`.

Puis, dans gerrit, valider la modification (Code Review +2), et la Submitter.

Faire prendre en compte ces changements dans AWX :
* S'authentifier sur https://awx.bu-dsa.si.c-s.fr/
  - aller dans "Projets",
  - à la ligne "pcdev", cliquer sur le bouton de rafraichissement **Obtenir la dernière révision SCM**

Lancer ensuite l'upgrade chaque PCs de développement :
* Commencer par prévenir l'utilisateur, il faut trouver un créneau horaire sur lequel son PC pourra être mis à jour.

* Puis lancer l'upgrade :
  - aller dans "Modèles"
  - faire démarrer une tâche "pcdev_33_upgrade"
  - dans LIMITE renseigner l'identifiant du PC
  - faire SUIVANT > LANCEMENT

* Enfin, lancer la post-installation : suivre la procédure décrite dans la partie **Déploiement de la post-installation** du présent document.

### Nettoyage d'AWX

Supprimer la configuration temporaire AWX du **Test de validation de l'upgrade**, soit dans l'ordre :
* "Inventaires" > "pcdev_33_inventory"
* "Modèles" > "pcdev_33_upgrade"
* "Modèles" > "pcdev_33_post-install"
* "Projets" > "pcdev_33"
