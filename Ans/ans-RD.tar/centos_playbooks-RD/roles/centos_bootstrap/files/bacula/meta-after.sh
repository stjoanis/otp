#!/bin/bash
#run this script as root

backup_scripts_dir=/usr/local/backup.d

SERVICE=$1

[[ $(id -u) -ne "0" ]] && echo "scripts avec droit root nécessaire.." && exit 1

[[ ! -e $backup_scripts_dir/devops-after.sh ]] && echo "Pas de scripts de post-sauvegarde.. Sortie" && exit 0
$backup_scripts_dir/devops-after.sh $SERVICE
