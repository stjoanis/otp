#!/bin/bash

URL="https://chat.sccoa.si.c-s.fr/hooks/bmbuucqh8pggp83jjxboxgrauy"

CLIENT="$1"  # %c
JOB="$2"     # %j
RESULT="$3"  # %e
LEVEL="$4"   # %l
ICON="http://raven.sccoa.si.c-s.fr/webhook/bacula_icon.png"

OK=":white_check_mark:"
ERR=":sos:"


if [[ $RESULT == *"OK"* ]]; then
	EMOJI=$OK
else
    EMOJI=$ERR
fi

msg="{\"username\": \"$CLIENT\",\"icon_url\": \"$ICON\",\"text\": \"$EMOJI $JOB\n$LEVEL completed with status : $RESULT\"}"

/usr/bin/curl -X POST -H 'Content-type: application/json' --data "$msg" "$URL"
