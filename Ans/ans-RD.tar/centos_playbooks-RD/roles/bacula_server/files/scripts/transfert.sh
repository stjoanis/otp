#!/bin/bash
scp /var/spool/bacula/bacula.sql root@virthead:/opt/backup
/opt/bacula/scripts/delete_catalog_backup
exit 0