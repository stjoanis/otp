Playbook bootstrap pour les serveurs DevOps
===========================================

## Préliminaires

Avant d'exécuter le playbook de bootstrap, il est nécessaire de réaliser les actions suivantes.

### Mise à jour de l'inventaire

* Ajouter l'hôte concerné à l'inventaire en complétant le fichier `hosts.ini`. Ne pas oublier de le renseigner dans les groupes auxquels il appartient.

* Créer et compléter le fichier `host_vars` associé à l'hôte concerné. Les variables attendues sont décrites dans le fichier.

* Pousser les changements sur Gogs.

Pour ajouter l'hôte comme client Bacula :

* Ajouter le client au groupe `[bacula-client]` dans l'inventaire Ansible. Il sera alors ajouté dans la liste des clients du serveur Bacula à la prochaine exécution de la tâche `clients.yaml`.

* Définir les paramètres de sauvegarde souhaités pour l'hôte. Par défaut, Bacula créé une tâche de sauvegarde et une tâche de restauration pour chaque hôte. La sauvegarde par défaut copie les fichiers présents dans `/etc` en suivant le planning `weekly`. Ces paramètres de sauvegarde, ainsi que les paramètres pour des sauvegardes spécifiques ou des sauvegardes dynamiques, doivent être précisés dans les variables de l'hôte Ansible.

### Préparation de l'hôte

* Rendre l'hôte concerné accessible par le réseau
  - raccorder le serveur,
  - configurer son interface,
  - configurer les serveurs DNS avec son adresse.

**Note**: Il est préférable d'effectuer la configuration de l'interface réseau depuis le menu prévu à cet effet à l'installation de CentOS.
Pour plus d'informations, consulter [la documentation](https://docs.centos.org/en-US/centos/install-guide/NetworkSpoke-x86/)

* S'assurer que le serveur SSH de l'hôte est démarré, et injecter la clé SSH d'administration dans les clés acceptées par l'utilisateur `admin` :

```bash
ssh-copy-id -i <path/to/public_key> admin@'<ip>'
```

* Le compte `admin` doit avoir les droits 'sudo', et le mot de passe du compte `admin` doit correspondre à la valeur de la variable `ansible_become_pass`.

## Exécution du bootstrap

Une fois les étapes préliminaires effectuées, le playbook de bootstrap peut être lancé depuis AWX.

Pour ce faire :

* se connecter à AWX ;
* depuis le menu `Modèles`, lancer `Infra - CentOS Bootstrap` ;
* dans le champ `LIMITE`, préciser l'hôte concerné par le déploiement puis renseigner le mot de passe du compte de bind LDAP ;
* exécuter le modèle.

**Si un client Bacula a été ajouté**, lancer le modèle `Infra - Synchronisation Serveur Bacula`.

Le playbook prend environ 10 minutes pour exécuter toutes les tâches. La plus longue tâche étant la mise à jour des paquets via YUM/DNF.

Toutes les actions doivent être **OK** ou **Changed** à la fin du script afin de garantir que le serveur considéré a bien été bootstrapé.

## Post-installation

### Changement du mot de passe admin

Une fois le playbook déployé sans erreur, modifier le mot de passe du compte `admin`. Ce dernier doit être sauvegardé dans une entrée du Keepass.
TODO : préciser où est le keepass.

* Générer un mot de passe pour le compte `admin` :

```bash
openssl rand -base64 12
```

* Se connecter en SSH au serveur concerné, et changer le mot de passe du compte `admin` depuis le compte root :

```bash
ssh <uid>@<server>
sudo -s
passwd admin
```

* Enfin, vérifier la bonne prise en compte du mot de passe en se connectant au compte `admin` depuis un compte utilisateur :

```bash
su - admin
```

## Résumé de la procédure d'ajout d'un client Nagios

![](deploiement_nagios.png)

## Procédure détaillée

La procédure détaillée d'utilisation de ce module est exposée dans le document [Details.md](Details.md). S'y référer pour plus d'informations sur le module de bootstrap.

Une documentation plus complète du module Nagios est présente dans le dossier [procedures](procedures/nagios/).
