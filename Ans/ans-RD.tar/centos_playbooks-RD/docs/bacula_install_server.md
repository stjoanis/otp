# Introduction

Ce document décrit la procédure à suivre pour la primo-installation d'un serveur Bacula avec Ansible. Avant de suivre cette procédure, il est fortement conseillé à l'utilisateur de consulter le playbook Ansible `centos_playbooks`, et le dossier `procedures` compris dans le dépôt.

# Préparation du serveur

* Rendre l'hôte concerné accessible par le réseau :

  - configurer son interface réseau
  - configurer le serveur DNS

* Injecter la clé SSH d'administration `adminkey` (cf : Keepass) dans les clés acceptées par l'utilisateur `admin`.

```bash
ssh-copy-id -i <path/to/public_key> admin@'<ip>'
```

* Le compte `admin` doit avoir les droits 'sudo' et le mot de passe du compte `admin` doit correspondre à la valeur de la variable `ansible_become_pass`.

# Modification du playbook Ansible

## Récupération du playbook

* Se rendre sur la page `https://gogs.sccoa.si.c-s.fr/infra/centos_playbooks` et cloner le dépôt.

## Ajout de la cible

* Ajouter la cible dans `hosts.ini` (suivre la nomenclature `<nom_court>   ansible_host=<adresse_dns>`). L'ajouter dans un groupe parmi `[virtual]`, `[physical]`, ou `[sccoa]`, **ET** l'ajouter dans les groupes `[bacula-server]` et `[bacula-client]`.

* Créer le fichier `<nom_court>.yaml` dans le dossier `host_vars`.

* S'inspirer des autres fichiers du dossier `host_vars` pour remplir les variables `centos`, `proxy`, `hostname`, `secure`, et `disable_selinux` (si nécessaire, copier-coller un autre fichier et l'adapter).

## Configuration des identifiants Bacula

* Dans le fichier `group_vars/bacula_server.yaml`, remplir les champs :

  - `bacula_pgsql_password` (mot de passe bacula pour la db bacula)
  - `bacula_dir_pass` (mot de passe du bacula-dir)
  - `bacula_sd_pass` (mot de passe pour contacter le bacula-sd)
  - `baculum_admin_pass` (mot de passe du compte admin créé par défaut)

Il est conseillé de mettre des mots de passe aléatoires et de les stocker dans le Keepass.

* Dans le même fichier, indiquer les utilisateurs autorisés à s'authentifier sur Baculum dans la liste `baculum_users`.

## Mot de passe bacula-fd et bacula-sd

* Dans le fichier `group_vars/bacula-server.yaml`, remplir le champ `bacula_storage_host` avec l'adresse du `bacula-sd`.

* Dans le fichier `group_vars/bacula-client`, indiquer dans le champ `bacula_server` l'adresse du nouveau serveur bacula, et indiquer dans le champ `bacula_fd_password` le mot de passe à utiliser pour contacter les clients Bacula. Le champ `bacula_mon_password` correspond au mot de passe du moniteur Bacula.

## Configuration des clients

Toutes les cibles du groupe `[bacula-client]` seront ajoutées comme clients Bacula dans la configuration du nouveau serveur.

Pour ajouter des cibles dans ce groupe, veuillez consulter le document d'ajout de cible.

# Ajout des modifications sur Gogs

* Une fois le playbook modifié, vérifier les modifications apportées avec les commandes `git status` et `git diff`.

* Pousser les changements sur gogs :

```bash
git add <fichier(s) modifie(s)>
git commit -m "<Message du commit>"
git push
```

* Vérifier les modifications sur gogs, les faire relire à un pair, puis les accepter (Submit).

# Déploiement sur AWX

* Se rendre sur le serveur de déploiment AWX (https://dr-lpr-intautomat-v.sccoa.si.c-s.fr), et se connecter via ses identifiants LDAP.

* Aller dans l'onglet "Projects" et mettre à jour le projet `centos_playbooks`.

* Aller dans l'onglet "Templates", et cliquer sur la fusée liée au modèle `Infra - Synchronisation Serveur Bacula` :

  - **Si la cible doit être boostrapée**, lancer le modèle avec les options suivantes :
  
    + LIMITE : `<nom_de_la_cible>`
    + BALISES DE TACHE : champ vide
    + BALISES DE SAUT : champ vide
	
  - **Si la cible n'a pas à être boostrapée**, lancer le modèle avec les options suivantes :
  
    + LIMITE : `<nom_de_la_cible>`
    + BALISES DE TACHE : `bacula-install bacula-client bacula-baculum`
    + BALISES DE SAUT : champ vide

Dans les deux cas, fournir dans les variables supplémentaires les valeurs suivantes :

```yaml
mysql_root_password: <Change_Me>
bacula_mysql_password: <Change_Me>
baculum_admin_pass: <Change_Me>
```

* Cliquer sur le bouton **LANCEMENT**.

Si la procédure s'est bien déroulée, toutes les actions devraient être "OK" ou "Changed" (vert ou orange) à la fin de l'exécution du playbook.

**Remarque :** Pour modifier la configuration des clients Bacula, se référer au document d'ajout d'une cible.

# Post-installation

* Ajouter les variables suivantes dans les variables Ansible du serveur :

```yaml
update: false
```

Cette variable garantie l'omnipotence de la configuration du serveur Bacula lors des ajouts des clients.

# Annexes

## Problèmes connus

### Bacula

* Si le `bacula-sd` ne parvient pas à contacter le robot de sauvegarde, ajouter l'utilisateur **bacula** au groupe "tape".

* Si l'exécution du playbook envoie une erreur après que le mot de passe mysql ait été changé, il faut relancer le playbook en ajoutant lors de l'exécution la variable `bacula_mysql_secure: false`. Cette variable permet de sauter les tâches de configuration de la base de données.

* Si les messages de fin de sauvegarde ne peuvent pas être envoyés à Mattermost, vérifier que l'autorité de certification SCCOA est présente dans le dossier `/etc/pki/ca-trust/source/anchors/`. Si ce n'est pas le cas, l'ajouter et exécuter la commande `update-ca-trust`.

### Baculum

* Si l'onglet Volumes indique une erreur liée à la `timezone` :

  - ouvrir le fichier `/usr/share/baculum/htdocs/protected/API/Class/VolumeManager.php`
  - au début de la fonction `setWhenExpire`, ajouter la ligne `date_default_timezone_set('Europe/Paris)`.

* Si le site indique qu'il a atteint sa limite de mémoire :

  - modifier le fichier `/etc/php.ini` pour augmenter la valeur de `memory_limit`
  - dans les settings de l'IHM Baculum, diminuer le nombre de jobs à afficher

* Pour la configuration du LDAP, baculum utilise les variables `ldap_bind_user` et `ldap_bind_pass`. Si cette dernière n'est pas configurée lors de l'installation de baculum, la tâche renvoie une erreur avec mot de passe invalide. Il faut alors relancer la tâche `bacula_baculum` en fournissant la variable `ldap_bind_pass: <mot_de_passe_de_bind>` lors de l'exécution.
