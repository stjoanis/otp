# Préparation de la cible

* Rendre l'hôte concerné accessible par le réseau :

  - configurer son interface réseau
  - configurer le serveur DNS

* Injecter la clé SSH d'administration `adminkey` (cf : Keepass) dans les clés acceptées par l'utilisateur `admin` :

```bash
ssh-copy-id -i <path/to/public_key> admin@'<ip>'
```

* Le compte `admin` doit avoir les droits 'sudo' et le mot de passe du compte `admin` doit correspondre à la valeur de la variable `ansible_become_pass`.

# Modification du playbook Ansible

## Récupération du playbook

* Aller sur la page `https://gogs.sccoa.si.c-s.fr/infra/centos_playbooks` et cloner le dépôt.

## Ajout de la cible

* Ajouter la cible dans `hosts.ini` (suivre la nomenclature `<nom_court>   ansible_host=<adresse_dns>`) :

  - si la cible est un client Bacula, l'ajouter au groupe `[bacula-client]`,
  - sinon, l'ajouter dans un groupe parmi `[virtual]`, `[physical]` ou `[sccoa]`.

* Créer le fichier `<nom_court>.yaml` dans le dossier `host_vars`.

* S'inspirer des autres fichiers du dossier `host_vars` pour remplir les variables `centos`, `proxy`, `hostname`, `secure`, `disable_selinux` (si nécessaire, copier-coller un autre fichier et l'adapter).

## Configuration Bacula

Par défaut, si la cible est dans le groupe `[bacula-client]`, une sauvegarde utilisant le fileset "Common" (le dossier `/etc`), et le schedule "weekly" est configurée.

* Modifier le fichier `<nom_court>.yaml` pour ajouter une sauvegarde, ou modifier la sauvegarde par défaut.

Trois types de sauvegardes sont possibles :

- les sauvegardes systèmes
- les sauvegardes dynamiques
- les sauvegardes additionnelles

Les configurations de ces trois sauvegardes se font **dans le fichier `<nom_court>.yaml`**

### Configuration d'une sauvegarde système

Il est possible de modifier les paramètres de sauvegarde par défaut via les variables suivantes :

- `bacula_save : [true/false]`, indique si une sauvegarde système doit être configurée
- `bacula_backup_fileset : [Common/system/...]`, le fileset à utiliser
- `bacula_schedule : [weekly/monthly/weekly-2nd/...]`, le schedule à utiliser
- `bacula_restore: [true/false]`, si une tâche de restauration doit être définie

Les valeurs par défaut pour ces variables sont indiquées dans le fichier `groups_vars/bacula-client.yaml`.

Deux variables optionnelles peuvent être ajoutées dans le cas où elles sont définies :

- `bacula_runbefore : [myscript.sh/...]`, script à exécuter sur le client avant la sauvegarde
- `bacula_runafter : [myscript.sh/...]`, script à exécuter sur le client après la sauvegarde

**Remarque:** Les listes des [filesets](#fileset) et [schedules](#schedule) sont disponibles en [Annexes](#annexes) de ce fichier.

### Configuration d'une sauvegarde dynamique

Les sauvegardes dynamiques utilisent des filesets spécifiques à un service. Les filesets liés à ces sauvegardes dynamiques doivent être directement définis dans les variables de l'hôte Ansible.

Un exemple de sauvegarde dynamique est donnée dans le fichier `group_vars/bacula_client.yaml`.

### Configuration d'une sauvegarde additionnelle

Les sauvegardes additionnelles sont généralement dédiées à des fichiers spécifiques (par exemple, la sauvegarde du NAS).

Un exemple de sauvegarde additionnelle est donnée dans le fichier `group_vars/bacula_client.yaml`.

# Ajout des modifications sur Gogs

* Une fois le playbook modifié, vérifier les documents modifiés avec les commandes `git status` et `git diff`.

* Pousser les changements sur gogs :

```bash
git add <fichier(s) modifies>
git commit -m "<Message du commit>"
git push
```

* Sur gogs : vérifier les modifications, les faire relire à un pair, puis accepter ces modifications (submit).

# Déploiement sur AWX

* Se rendre sur le serveur de déploiement AWX (https://dr-lpr-intautomat-v.sccoa.si.c-s.fr), et se connecter via ses identifiants LDAP

* Dans le menu "Projects", mettre à jour le projet `centos_playbooks`, puis aller dans le menu "Templates".

* **Si la cible doit être boostrapée**,

  - lancer le modèle `Infra - Bootstrap CentOS` avec les options suivantes :

    + LIMITE : `<nom_court>`
    + BALISES DE TACHE : champ vide
    + BALISES DE SAUT : champ vide

  - lancer ensuite le modèle `Infra - Synchronisation Serveur Bacula` (les options sont déjà pré-remplies)

* **Si la cible n'a pas à être boostrapée**,

  - lancer le modèle `Infra - Synchronisation Client Bacula` avec les options suivantes :

    + LIMITE : `<nom_court>`
    + BALISES DE TACHE : `bacula`
    + BALISES DE SAUT : champ vide

  - lancer ensuite le modèle `Infra - Synchronisation Serveur Bacula` (les options sont déjà pré-remplies)

* Cliquer sur le bouton **LANCEMENT**.

Si la procédure s'est bien déroulée, toutes les actions devraient être "OK" ou "Changed" (vert ou orange) à la fin de l'exécution du playbook.

**Remarque** :
Si la cible est déjà dans les clients du serveur Bacula, il n'est pas nécessaire de l'ajouter dans les limites du playbook pour modifier la configuration de sa sauvegarde. Seule la tâche `Infra - Synchronisation Serveur Bacula` doit être lancée.

# Décommissionnement de la cible

Pour retirer la cible de la liste des clients Bacula, il faut :

* supprimer toutes les lignes relatives à la cible dans le fichier `hosts.ini`
* supprimer le fichier `<nom_court>.yaml`
* pousser les modifications sur gogs
* enfin sur AWX, synchroniser le projet et la source, puis lancer le modèle `Infra - Synchronisation Serveur Bacula`

# Annexes

## Fileset

+-------------------+------------------------------------------------+-------------------------------------------------+
|      FileSet      |                     Include                    |                     Exclude                     |
+===================+================================================+=================================================+
| Default           |- /etc                                          |- /var/log                                       |
|                   |- /var                                          |- /var/lib/kvm                                   |
|                   |- /home                                         |- /var/lib/bacula-restores                       |
|                   |- /srv                                          |- /opt/dell                                      |
|                   |- /opt                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Tuleap            |- /etc                                          |- /var/log                                       |
|                   |- /var                                          |- /var/lib/kvm                                   |
|                   |- /home                                         |- /var/lib/bacula-restores                       |
|                   |- /srv                                          |- /opt/dell                                      |
|                   |- /opt                                          |                                                 |
|                   |- /vol0                                         |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Tarly             |- /etc                                          |- /var/log                                       |
|                   |- /var                                          |- /var/lib/kvm                                   |
|                   |- /home                                         |- /var/lib/bacula-restores                       |
|                   |- /srv                                          |- /opt/dell                                      |
|                   |- /opt                                          |- /var/lib/gogs.OLD                              |
|                   |- /data                                         |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| windows-nc1-Caen  |- c:/Users/administrateur.NC1/VirtualBox VMs    |                                                 |
|                   |- d:/VMs                                        |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| windows-nc1-Toulon|- d:/Administration/VMs                         |                                                 |
|                   |- d:/NC1/VM                                     |                                                 |
|                   |- d:/NC1/VM Testlink                            |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| VMs               |- /var/lib/kvm                                  |- /var/lib/libvirt/images/NO_saved               |
|                   |- /var/lib/libvirt/images                       |- /var/lib/kvm/exclude                           |
|                   |- /vm1                                          |- /vm2/exclude                                   |
|                   |- /vm2                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Forge             |- /boot                                         |- /var/log                                       |
|                   |- /cvsroot                                      |- /var/lib/bacula-restores                       |
|                   |- /etc                                          |                                                 |
|                   |- /gfas_data                                    |                                                 |
|                   |- /home                                         |                                                 |
|                   |- /opt                                          |                                                 |
|                   |- /project                                      |                                                 |
|                   |- /projet                                       |                                                 |
|                   |- /tmp                                          |                                                 |
|                   |- /usr                                          |                                                 |
|                   |- /var                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Forge-gzip        |- /boot                                         |- /var/log                                       |
|                   |- /cvsroot                                      |- /var/lib/bacula-restores                       |
|(seule sauvegarde  |- /etc                                          |                                                 |
| au format gzip)   |- /gfas_data                                    |                                                 |
|                   |- /home                                         |                                                 |
|                   |- /opt                                          |                                                 |
|                   |- /project                                      |                                                 |
|                   |- /projet                                       |                                                 |
|                   |- /tmp                                          |                                                 |
|                   |- /usr                                          |                                                 |
|                   |- /var                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Jazz2             |- /boot                                         |- /var/log                                       |
|                   |- /etc                                          |- /var/lib/bacula-restores                       |
|                   |- /export/home.test                             |                                                 |
|                   |- /export/project                               |                                                 |
|                   |- /opt                                          |                                                 |
|                   |- /project                                      |                                                 |
|                   |- /tmp                                          |                                                 |
|                   |- /usr                                          |                                                 |
|                   |- /var                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Mercury           |- c:/temp/                                      |- c:/windows                                     |
|                   |- c:/ProgramData/KasperskySC/SC_Backup          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Ovirt             |- /export                                       | - /var/lib/libvirt/images                       |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Ses               |- c:/sauvegarde                                 |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| simsrv            |- /etc                                          |- /var/lib/libvirt/images                        |
|                   |- /var                                          |                                                 |
|                   |- /home.local                                   |                                                 |
|                   |- /srv                                          |                                                 |
|                   |- /opt                                          |                                                 |
|                   |- /usr                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Tully             |- /cvs.exports                                  |- /var/log                                       |
|                   |- /cvs.home                                     |- /var/lib/kvm                                   |
|                   |- /etc                                          |- /var/lib/bacula-restores                       |
|                   |- /home                                         |- /opt/dell                                      |
|                   |- /opt                                          |- /cvs.home/mouv20190703                         |
|                   |- /srv                                          |                                                 |
|                   |- /var                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| windows-nc1       |- c:/                                           |- c:/Users/administrateur.NC1/VirtualBox VMs/    |
|                   |- d:/                                           |- c:/windows                                     |
|                   |- d:/NC1/VM Testlink                            |- d:/Administration/VMs                          |
|                   |                                                |- d:/NC1/VM                                      |
|                   |                                                |- d:/NC1/VM Testlink                             |
|                   |                                                |- d:/VMs                                         |
+-------------------+------------------------------------------------+-------------------------------------------------+
| winterfell        |- c:/                                           |- c:/windows                                     |
|                   |- e:/                                           |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| NAS-SPARTE        |- /mnt/nas-sparte                               |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Full Set          |- /etc                                          |- /share/Milad/Echange                           |
|                   |- /var                                          |- /share/vm                                      |
|                   |- /home                                         |- /share/repo                                    |
|                   |- /usr                                          |                                                 |
|                   |- /opt                                          |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| VM Set            |- /share/vm                                     |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+
| Catalog           |- /var/spool/bacula/bacula.sql                  |                                                 |
+-------------------+------------------------------------------------+-------------------------------------------------+

## Schedule

+------------------------+---------------------------------------+
| Schedule               | Description                           |
+========================+=======================================+
| Default                | Full sun at 2:05\                     |
|                        | Incremental mon-sat at 2:05           |
+------------------------+---------------------------------------+
| WeeklyCycle            | Full 1st sat at 03:05\                |
|                        | Differential 2nd-5th sat at 13:05\    |
|                        | Incremental mon-fri at 21:05          |
+------------------------+---------------------------------------+
| OnceAMonthOvirtVM      | Full 2nd wed at 02:30                 |
+------------------------+---------------------------------------+
| OnceAMonth             | Full 1st sat at 03:05                 |
+------------------------+---------------------------------------+
| WeeklyCycleAfterBackup | Full sun-sat at 23:10                 |
+------------------------+---------------------------------------+
| OnlyJazz2              | Full 2nd sat at 03:05\                |
|                        | Differential 1st sat at 13:05\        |
|                        | Differential 3rd-5th sat at 13:05\    |
|                        | Incremental mon-fri at 21:05          |
+------------------------+---------------------------------------+
| BackupCopy             | Full tue-sun at 01:00                 |
+------------------------+---------------------------------------+
